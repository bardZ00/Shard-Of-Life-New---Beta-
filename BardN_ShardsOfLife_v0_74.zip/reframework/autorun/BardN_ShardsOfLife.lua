-- ============================================================================
-- BardN_ShardsOfLife v0.74 — Shards of Life (Dragon's Dogma 2)
-- v0.74 : la voyante ne soigne plus QUE les Traumatismes (un par un, contre ingrédients et or). Plus de soin des Séquelles chez elle
--         (auberge et Pierre de faille s'en chargent) et le bouton « Soigner tout » gratuit est supprimé.
--         Réglages « prix niveau I / II » des Séquelles retirés (restent ceux des Traumatismes).
-- v0.73 : CORRECTIF ingrédients de la voyante (séquelles ET traumatismes). La page de soin n'affichait pas la liste des
--         ingrédients (seulement un bouton grisé) et le sac était mal lu (getStorageList : tout paraissait manquer).
--         Reprise du fonctionnement de BardN_New_Death_System : lecture du sac par getHaveNum / deleteItem (stock relu chaque
--         seconde, jamais pendant la construction du menu), une ligne par ingrédient « n× nom — tu en as N » (grisée ou colorée
--         quand il manque), « Donner les ingrédients » qui dit ce qu'il manque ou demande confirmation, or vérifié avant le soin.
--         Les remèdes manquants (séquelles ou traumatismes nés pendant la partie) sont tirés automatiquement.
-- v0.72 : CORRECTIF voyante. Le menu de la voyante était branché mais aucune voyante n'était désignée (voy_pnj vide, aucun bouton
--         pour en désigner une) : le menu de discussion ne proposait donc rien. Reprise du fonctionnement de BardN_New_Death_System :
--         Ursula désignée d'origine, import des voyantes d'Économie dynamique, bouton « Ce PNJ est une voyante » et liste avec
--         « Retirer » dans le menu REFramework, avertissement quand aucune voyante n'est désignée.
-- v0.71 : couleurs par défaut : Séquelles #709BAA, Traumatismes #3C4B96 (barre, annonce, menu pause).
-- v0.70 : la barre d'icônes Séquelles / Traumatismes (bas gauche) est un élément HUD Controls à part
--         (règles, touches, bascule globale). L'option « label Traumatisme » fonctionne enfin.
-- v0.69 : couleurs indépendantes (Séquelle / Traumatisme) pour l'annonce centre-haut et pour le panneau du menu pause ;
--         « couleur des Séquelles / Traumatismes » ne règle plus que la barre d'icônes.
-- v0.68 : prix (or) réglable pour le soin des Traumatismes par la voyante (niveau I / II).
-- v0.67 : la voyante soigne aussi les Traumatismes un par un (sous-menu, recette et prix comme les séquelles).
-- v0.67 : « couleur des Séquelles » / « couleur des Traumatismes » s'appliquent aussi à l'annonce
--         centre-haut (selon le type) et aux titres du panneau du menu pause. Bouton d'aperçu traumatisme.
-- v0.66 : Correctif annonces : les traumatismes et guérisons groupées sont annoncés un par un
--         (au lieu de "_tr_new" / "_all" bruts). Guérison affiche "Guérie : nom".
-- v0.65 : Fond de l'annonce remplacé par l'image de fumée (fond_annonce.png), réglable
--         en taille (%), décalage vertical (px) et opacité. Pause entre annonces réglable.
-- v0.64 : File d'attente pour les annonces de séquelles : quand plusieurs séquelles
--         arrivent en même temps, elles s'affichent l'une après l'autre avec 1,5 s
--         de pause entre chaque, au lieu de ne montrer que la dernière.
-- v0.63 : Restauration des éléments d'UI de Death System :
--         - Panneau de détail au menu pause (icônes, noms, effets, jours, remèdes),
--           affiché uniquement sur l'écran principal du menu pause, déplaçable à la souris.
--         - Annonce des séquelles en haut d'écran passée en d2d.text (Palatino Linotype)
--           avec fond aux bords adoucis, au lieu de draw.text (illisible).
--         - Barre d'icônes : rang romain et jours restants en d2d.text (Palatino Linotype).
--         - Polices Palatino Linotype (tailles 8–60), créées une seule fois au démarrage.
-- v0.62 : Correctif des annonces (bannière en haut d'écran avec fond fumée) qui
--         n'apparaissaient jamais — appels directs à R.sx_annoncer ajoutés dans
--         seq_appliquer, seq_guerir, tr_guerir, guerir_sequelles, guerir_tout et
--         transformer_sequelles_en_traumas. Ajout d'outils de test (Séquelles et
--         Traumatismes) : séquelle puissante aléatoire (rang max), séquelle au
--         choix (par nom, 1 rang ou rang max), transformer en Traumatisme, tout
--         nettoyer.
-- v0.48 : REFONTE SURVIE — Second Breath (1/2/3 éclats → 2/1/0 Séquelles), Traumatismes
--         (ex-Séquelles devenues permanentes lors d'une nouvelle résurrection punitive), voyante
--         (soigne Séquelles ET Traumatismes), guérison des Séquelles seules par l'auberge et la
--         Pierre de faille. Breath of Life reste dans son mod séparé BardN_UltimateBreathOfLife
--         (facultatif, se branche toujours sur la jauge de SoL).
--         ATTENTION : à installer, désinstaller BardN_New_Death_System (effets doubles sinon).
-- v0.47 : COMPATIBILITÉ « BardN Death System » à la place de « BardN Death System ».
--         « Non » à l'écran de mort (éclats, écran unique ou question native de la Pierre de Réveil)
--         → _G.BardN_DeathSystem.trigger_death("Shards of Life") : réapparition à la dernière pierre
--         de faille. Garde des phases 28/29/40 et de la Pierre éternelle pendant la séquence via
--         _G.BardN_DeathSystem.is_active(). Nouvelle fonction api.ds_compat() (Death System sait que
--         nous gérons les « Non »). Plus aucune référence à l'ancien mod.
--         (Base : v0.45 — le fichier de la v0.46, retrait de styles/formes, n'a pas été retrouvé.)
-- v0.45 : STYLES D'INTERFACE, FORMES ET REMPLISSAGE LIQUIDE (moteur intégré, aucun autre mod requis),
--         optimisations du dessin et de la boucle d'image, retrait du code mort (décroissance,
--         variables doublons). Nouveau style par défaut « Kingdom Hearts 2 - Drive (doré) ».
-- v0.44 : LE MOD EST SÉPARÉ EN DEUX.
--   * BardN Shards of Life (CE FICHIER, autonome) : la jauge d'« Éclats de vie » (gain en relevant les pions),
--     la seconde vie (écran de la Pierre de Réveil), les remises à zéro (repos, Transpierre, voyage),
--     la compatibilité « BardN Death System », l'interface de BardN_KH_HUD (orbes),
--     la jauge à l'écran + HUD Controls, les presets, le journal.
--   * BardN Ultimate Breath of Life (autre fichier, REQUIERT celui-ci) : les ultimes qui dépensent les éclats
--     (Breath of Life, Slow Time), leur chorégraphie, caméra, effets visuels, barre d'incantation.
-- Shards of Life peut être joué seul. Il offre à Ultimate Breath of Life (via _G.BardN_ShardsOfLife) :
--   get_unites / get_energie_max / est_en_combat / changer_unites / ajuster / marquer_reanimation /
--   jauge (position de la jauge à l'écran) / incantation (drapeau) / abonnes_seconde_vie (rappels).
-- Réglages : reframework/data/BardN_ShardsOfLife/config.json
--   (l'ancien fichier commun est copié en config_avant_separation.json pour BardN Ultimate Breath of Life)
-- ============================================================================

local NOM    = "BardN Shards of Life v0.74"
local CONFIG = "BardN_ShardsOfLife/config.json"
local ANCIEN = "BardN_Savior/"            -- reprise des réglages et presets de l'ancien nom
local ANCIEN2 = "BardN_BreathOfLife/"     -- nom provisoire du 28/10 (si déjà lancé)

-- ----------------------------------------------------------------------------
-- Réglages
-- ----------------------------------------------------------------------------
local defauts = {
    actif = true,
    -- énergie
    langue = "",                             -- v0.11 : "fr", "en" ou "auto" (langue du jeu)
    energie_max = 3,                         -- éclats de vie (segments) ; 1 segment = 1 éclat
    -- jauge de flux : sources d'unités (v0.12)
    gain_reanimation = 1,                    -- v0.10 : éclats par pion réanimé (imposé à 1)
    reanimation_combat_seul = true,
    compter_alerte_comme_combat = false,
    fenetre_anti_doublon = 2.0,
    -- v0.44 : remise à zéro du flux, coopération, nouvelle séquence de résurrection
    raz_repos = true,                        -- nuit à l'auberge / feu de camp (temps qui passe)
    raz_transpierre = true,                  -- utilisation d'une Transpierre
    raz_voyage = true,                       -- voyage (char à bœufs, téléportation)
    raz_repos_heures = 0.5,                  -- v0.62 : heures de jeu minimales pour un repos hors camp
    jauge_message_perte = true,              -- v0.62 : message sous la jauge à chaque perte                  -- v0.62 : heures de jeu minimales pour un vrai repos
    raz_distance = 300.0,                    -- m parcourus d'un coup = voyage (v0.48 : 300)
    jauge_delai_pause = 0.8,                 -- s avant le retour de la jauge après une pause
    seconde_vie = true,                      -- v0.62 : jauge pleine = une seconde vie
    seconde_vie_delai = 1.0,                 -- s après la mort (animation de chute)
    sv_ecran_unique = true,                  -- v0.73 : un seul écran Éclats / Pierre de Réveil (N) / Non
    respawn_compat = true,                   -- v0.47 : « Non » à l'écran de mort = réapparition de « BardN Death System »
    mort_auberge = true,                     -- v0.62 : écran de mort = retour direct à la dernière auberge (sans choix)
    sb_zero = true,                          -- v0.62 : Second Breath possible à 0 éclat (au prix de 3 Séquelles)
    sv_puis_pierre = true,                   -- v0.68 : « Non » aux éclats → Pierre de Réveil classique proposée
    -- jauge de test
    jauge_visible = true,
    use_hud_controls = true,
    hud_opacite = 1.0,                       -- v0.42 : réglage de groupe (tous les éléments à l'écran)
    hud_dx = 0.0,                            -- décalage horizontal (fraction de l'écran) : jauge, barre, textes
    hud_dy = 0.0,
    hud_echelle = 1.0,                       -- échelle de la jauge et de la barre
    jauge_texte_pret = true,                 -- v0.12 : texte « Éclats de vie prêts » au-dessus de la jauge
    jauge_visible_incantation = true,        -- toujours visible pendant l'incantation
    jauge_x = 0.79,
    jauge_y = 0.89,
    jauge_largeur = 182,
    jauge_hauteur = 12,
    -- v0.6 : apparence complète de la jauge classique
    jauge_espacement = 4,                    -- écart entre les segments (px)
    jauge_contour = 1.0,                     -- épaisseur du contour (px, 0 = aucun)
    jauge_opacite = 0.94,                     -- opacité générale
    jauge_avec_kh = false,                   -- garder la jauge classique même quand KH HUD affiche les orbes
    jauge_col_fond = 0xE0101010,             -- couleurs au format du jeu d'affichage : 0xAABBGGRR
    jauge_col_partiel = 0xFF2AFCFD,
    jauge_col_pret = 0xFF46F954,
    jauge_col_contour = 0xFF000000,
    -- v0.13 : 2e couleur (bas) de chaque élément → dégradé vertical (haut = couleur ci-dessus)
    jauge_col_fond2 = 0xE0000000,
    jauge_col_partiel2 = 0xFF2AA0FE,
    jauge_col_pret2 = 0xFF2AA02E,
    jauge_col_contour2 = 0xFF000000,
    -- v0.45 : style d'interface (apparence seulement), forme de la jauge, remplissage liquide
    style = "Kingdom Hearts 2 - Drive (doré)",
    fl_version = 0,                          -- 45 = le style doré a déjà été appliqué une fois
    jauge_forme = "segments",                -- segments / eclats / orbes / lames / barre
    jauge_biais = 0.35,                      -- inclinaison de la forme « lames »
    fl_actif = true,
    fl_qualite = 2,                          -- 1 élevée, 2 moyenne, 3 basse
    fl_finesse = 2.4,
    fl_bandes = 0,                           -- 0 = automatique (selon la hauteur)
    fl_pret_palette = true,
    fl_mult_vitesse = 1.0,
    fl_couleur_1 = 0xFF128AFE, fl_couleur_2 = 0xFF2AC7FE,
    fl_couleur_3 = 0xFF2AFCFD, fl_couleur_4 = 0xFF2AB4FE,
    fl_couleur_pret_1 = 0xFF1E8B2E, fl_couleur_pret_2 = 0xFF46F954,
    fl_couleur_pret_3 = 0xFFC8FF9E, fl_couleur_pret_4 = 0xFF34C23F,
    fl_vitesse = 30.0, fl_longueur_onde = 230.0, fl_turbulence = 0.30,
    fl_volume = 0.92, fl_vernis = 0.80,
    fl_reflets = 3, fl_reflet_vitesse = 0.38, fl_reflet_largeur = 55.0,
    fl_reflet_intensite = 0.55, fl_reflet_couleur = 0xFFE8FFFF,
    fl_scintillements = 5, fl_scint_taille = 0.15, fl_scint_vitesse = 0.45,
    fl_scint_opacite = 0.75, fl_scint_couleur = 0xFFC8FFFF,
    fl_crete = true, fl_crete_largeur = 13.0, fl_crete_intensite = 0.85,
    fl_crete_couleur = 0xFFD0F8FF, fl_ondulation = 0.5, fl_ondulation_vitesse = 1.8,
    fl_halo = true, fl_halo_couleur = 0xFF2AC7FE, fl_halo_vitesse = 0.60,
    fl_halo_taille = 13.0, fl_halo_intensite = 0.50, fl_halo_min = 0.35,
    fl_halo_traversant = 0.22,
    -- ------------------------------------------------------------------------
    -- v0.48 : Second Breath + Séquelles + Traumatismes
    -- ------------------------------------------------------------------------
    second_breath = true,                    -- v0.48 : résurrection par les éclats avec séquelles
    sb_rang2_seuil = 2,                      -- nb de séquelles de ce rang avant d'en tirer en rang 2
    seq_actif = true,                        -- séquelles activées (mécanique principale)
    seq_jours = 7,                           -- durée (jours de jeu) avant expiration naturelle
    -- Puissance par séquelle — mêmes valeurs par défaut que BardN_New_Death_System preset Default
    met_on = true, met_n1 = 40, met_n2 = 75,         -- Métabolisme perturbé (−% soins)
    dou_on = true, dou_n1 = 25, dou_n2 = 40,         -- Douleur persistante (+% coût endurance)
    com_on = true,                                   -- Commotion cérébrale (ordres pions muets)
    vit_on = true, vit_n1 = 400, vit_n2 = 1000,      -- Vitalité diminuée (×jauge blanche /1000)
    fra_on = true, fra_n1 = 25, fra_n2 = 40,         -- Fragilité (+% dégâts subis)
    res_on = true,                                   -- Lien perdu (pions non réanimables)
    fai_on = true, fai_n1 = 25, fai_n2 = 40,         -- Faiblesse (−% dégâts infligés)
    ins_on = true, ins_n1 = 3, ins_n2 = 10,          -- Instabilité (×déséquilibre subi)
    epu_on = true, epu_n1 = 25, epu_n2 = 40,         -- Épuisement (−% endurance max)
    ess_on = true, ess_n1 = 3, ess_n2 = 5,           -- Essoufflement (conso endu ×, Stamina Fatigue requis)
    gar_on = true, gar_n1 = 2, gar_n2 = 4,           -- Garde défaillante (casse équipement ×, EnemyBreak requis)
    dys_on = true,                                   -- Dysphagie (consommables bloqués)
    sur_on = true, sur_n1 = 20, sur_n2 = 35,         -- Surcharge (−% charge max, RPG Level Up requis)
    -- Voyante — mêmes valeurs par défaut que BardN_New_Death_System (recettes niveau I = 2×1-2, niveau II = 3×2-3)
    voy_actif = true,
    voy_vide = false,                                 -- v0.73 : ligne « rien à soigner » chez la voyante
    voy_couleur_on = true, voy_gris = 0xFF8C8C8C, voy_complet = 0xFFFFFFFF,   -- v0.73 : couleurs des lignes d'ingrédients (AABBGGRR)
    voy_prix_tr1 = 0, voy_prix_tr2 = 0,              -- v0.67 : prix (or) du soin d'un Traumatisme, niveau I / II (seul soin de la voyante)
    voy_n1_ingr = 2, voy_n1_min = 1, voy_n1_max = 2, voy_val1 = 600,
    voy_n2_ingr = 3, voy_n2_min = 2, voy_n2_max = 3, voy_val2 = 1000,
    voy_pnj = {},                                     -- CharacterID string → nom (PNJ désignés comme voyants)
    voy_retires = {},                                 -- CharacterID string → true (jamais réajoutés)
    -- HUD panneau des Séquelles / Traumatismes (barre d'icônes en bas d'écran)
    sx_actif = true, sx_x = 0.015, sx_y = 0.926, sx_taille = 44, sx_ecart = 6, sx_opacite = 0.6,
    sx_jours = true, sx_texte = 100,
    sx_annonce = true, sx_annonce_taille = 133, sx_annonce_y = 0.16, sx_annonce_texte = 100,
    sx_annonce_duree = 8, sx_annonce_fond = true, sx_annonce_fond_opacite = 55,
    sx_annonce_fond_couleur = 0xFF0A0806,
    sx_annonce_fond_echelle = 120,           -- v0.65 : taille du fond de fumée (% du bloc icône+texte)
    sx_annonce_fond_dy = 0,                  -- v0.65 : décalage vertical du fond (px, négatif = monte)
    sx_annonce_pause = 1.5,                  -- v0.65 : pause entre deux annonces successives (secondes)
    sx_couleur = 0xFFAA9B70,                          -- teinte des Séquelles (clair)
    sx_couleur_tr = 0xFF964B3C,                       -- teinte des Traumatismes (plus sombre, cuivré sombre)
    -- v0.69 : couleurs séparées pour l'annonce centre-haut et pour le panneau du menu pause
    sx_an_couleur = 0xFFAA9B70, sx_an_couleur_tr = 0xFF964B3C,     -- annonce (Séquelle / Traumatisme)
    det_seq_couleur = 0xFFAA9B70, det_tr_couleur = 0xFF964B3C,     -- panneau menu pause (Séquelle / Traumatisme)
    sx_libelle_tr = true,                             -- texte « Traumatisme : … » dans le panneau
    -- v0.63 : panneau de détail au menu pause (porté de BardN_New_Death_System)
    det_actif = true, det_x = 0.46, det_y = 0.63, det_echelle = 95, det_icone = 100, det_texte = 103,
    det_opacite = 1.0, det_espace = 8, det_entete = true, det_fond = true, det_fond_couleur = 0xC0080808,
    det_titre_couleur = 0xFFE8DCC8, det_texte_couleur = 0xFFB8A890, det_vide = false,
    det_delai = 0.1, det_fondu_in = 0.14, det_fondu_out = 0.16, det_remede = false,
    det_jours = true, det_souris = true,
}
local cfg = {}
for k, v in pairs(defauts) do cfg[k] = v end
local version_lue = nil
local function charger()
    local ok, data = pcall(json.load_file, CONFIG)
    if not (ok and type(data) == "table") then
        ok, data = pcall(json.load_file, ANCIEN2 .. "config.json")
        if not (ok and type(data) == "table") then
            ok, data = pcall(json.load_file, ANCIEN .. "config.json")  -- 1er lancement : réglages de BardN_Savior
        end
    end
    if ok and type(data) == "table" then
        version_lue = tonumber(data.cfg_version) or 0
        for k, v in pairs(data) do
            if defauts[k] ~= nil and type(v) == type(defauts[k]) then
                if math.type(defauts[k]) == "integer" then v = math.tointeger(v) or defauts[k] end
                cfg[k] = v
            end
        end
    end
end
local function sauver() pcall(json.dump_file, CONFIG, cfg) end
-- v0.44 : séparation en deux mods. L'ancien fichier commun contenait aussi les réglages de Breath of Life :
-- on en garde une copie intacte (config, presets) pour BardN Ultimate Breath of Life, qui les reprend à son 1er lancement.
pcall(function()
    local d = json.load_file(CONFIG)
    if type(d) == "table" and d.capacite_active ~= nil then
        local deja = json.load_file("BardN_ShardsOfLife/config_avant_separation.json")
        if type(deja) ~= "table" then json.dump_file("BardN_ShardsOfLife/config_avant_separation.json", d) end
    end
    for _, nom in ipairs({ "preset_1", "preset_2", "preset_3", "avant_reset" }) do
        local p = json.load_file("BardN_ShardsOfLife/" .. nom .. ".json")
        if type(p) == "table" and p.capacite_active ~= nil then
            local deja = json.load_file("BardN_ShardsOfLife/" .. nom .. "_avant_separation.json")
            if type(deja) ~= "table" then json.dump_file("BardN_ShardsOfLife/" .. nom .. "_avant_separation.json", p) end
        end
    end
end)
-- v0.75 : presets de réglages (copies complètes de la config)
local PRESETS = {}
function PRESETS.chemin(nom) return "BardN_ShardsOfLife/" .. nom .. ".json" end
-- reprise des presets de BardN_Savior (une seule fois, sans écraser)
for _, nom in ipairs({ "preset_1", "preset_2", "preset_3", "avant_reset" }) do
    pcall(function()
        local deja = json.load_file(PRESETS.chemin(nom))
        if type(deja) ~= "table" then
            local vieux = json.load_file(ANCIEN2 .. nom .. ".json")
            if type(vieux) ~= "table" then vieux = json.load_file(ANCIEN .. nom .. ".json") end
            if type(vieux) == "table" then json.dump_file(PRESETS.chemin(nom), vieux) end
        end
    end)
end
function PRESETS.info(nom)
    local c = PRESETS.cache and PRESETS.cache[nom]
    if c == nil or os.clock() - c.t > 2 then
        local ok, d = pcall(json.load_file, PRESETS.chemin(nom))
        c = { t = os.clock(), txt = (ok and type(d) == "table") and tostring(d._preset_date or "sauvé") or false }
        PRESETS.cache = PRESETS.cache or {}
        PRESETS.cache[nom] = c
    end
    return c.txt or nil
end
function PRESETS.sauver(nom, libelle)
    local copie = {}
    for k, v in pairs(cfg) do copie[k] = v end
    local quand = "sauvé"
    pcall(function() quand = os.date("%d/%m %H:%M") end)
    copie._preset_date = quand
    local ok = pcall(json.dump_file, PRESETS.chemin(nom), copie)
    if PRESETS.cache then PRESETS.cache[nom] = nil end
    return ok, libelle
end
function PRESETS.charger(nom)
    local ok, d = pcall(json.load_file, PRESETS.chemin(nom))
    if not (ok and type(d) == "table") then return false end
    for k, v in pairs(d) do
        if k ~= "langue" and defauts[k] ~= nil and type(v) == type(defauts[k]) then
            if math.type(defauts[k]) == "integer" then v = math.tointeger(v) or defauts[k] end
            cfg[k] = v
        end
    end
    sauver()
    return true
end
charger()
-- réglages imposés (appliqués APRÈS la lecture de la config)
cfg.gain_reanimation = 1               -- v0.10 : un pion réanimé = un éclat (plus d'unités)
if cfg.raz_distance < 300 then cfg.raz_distance = 300.0 end   -- v0.48

-- ----------------------------------------------------------------------------
-- État et outils
-- ----------------------------------------------------------------------------
local R = {}   -- v0.28 : état et fonctions de la Rupture (limite de 200 variables locales)

-- v0.72 : voyantes connues (CharacterID → nom), comme dans BardN_New_Death_System.
-- Ursula d'origine (relevée par Économie dynamique) + celles marquées dans Économie dynamique (lecture seule de son fichier).
-- Une voyante retirée à la main n'est jamais réajoutée.
R.VOY_ORIGINE = { ["590080768"] = "Ursula" }
R.voy_import = 0
do
    if type(cfg.voy_pnj) ~= "table" then cfg.voy_pnj = {} end
    if type(cfg.voy_retires) ~= "table" then cfg.voy_retires = {} end
    local function ajouter(k, nom)
        k = tostring(k)
        if cfg.voy_pnj[k] == nil and not cfg.voy_retires[k] then
            cfg.voy_pnj[k] = tostring(nom or "?"); R.voy_import = R.voy_import + 1
        end
    end
    for k, nom in pairs(R.VOY_ORIGINE) do ajouter(k, nom) end
    local ok, eco = pcall(json.load_file, "BardN_Economie_Dynamique/reglages.json")
    if ok and type(eco) == "table" and type(eco.voyantes) == "table" then
        for k, nom in pairs(eco.voyantes) do ajouter(k, nom) end
    end
    if R.voy_import > 0 then sauver() end
end

-- ----------------------------------------------------------------------------
-- v0.11 : LANGUE — français / English (bouton en haut du menu : Français, English, Auto)
-- Le script est écrit en français ; en anglais, chaque texte affiché (menu, écran, journal) passe par
-- R.T() : traduction exacte du texte entier, sinon traduction des morceaux connus (dictionnaire R.EN).
-- Les textes du jeu eux-mêmes (dialogue de la Pierre de Réveil) suivent la langue du jeu.
-- ----------------------------------------------------------------------------
R.EN = {
    ["illisible"] = "unreadable",
    ["aucun"] = "none",
    ["Couleur du haut"] = "Top colour",
    ["Couleur du bas (dégradé)"] = "Bottom colour (gradient)",
    ["Même couleur en bas (pas de dégradé)"] = "Same colour at the bottom (no gradient)",
    ["Remettre par défaut"] = "Reset to default",
    ["  message rouge sous la jauge à chaque perte d'éclat"] = "  red message under the gauge each time a shard is lost",
    ["  texte « Éclats de vie prêts » au-dessus de la jauge"] = "  \"Shards of Life ready\" text above the gauge",
    ["  texte de décroissance (« -N dans Xs », seulement si la décroissance est active)"] = "  decay text (\"-N in Xs\", only when decay is active)",
    ["Choisir la couleur"] = "Pick the colour",
    ["Transparence (0 = invisible, 255 = opaque)"] = "Transparency (0 = invisible, 255 = opaque)",
    ["Rouge"] = "Red",
    ["Vert"] = "Green",
    ["Bleu"] = "Blue",
    ["(couleur du haut + couleur du bas = dégradé vertical ; visibles seulement si la jauge classique est affichée : voir les cases plus haut)"] = "(top colour + bottom colour = vertical gradient; only visible while the classic gauge is displayed: see the checkboxes above)",
    ["(sélecteur de couleur indisponible : curseurs Rouge / Vert / Bleu)"] = "(colour picker unavailable: Red / Green / Blue sliders)",
    ["vide"] = "empty",
    [" » : "] = "\": ",
    ["Pion "] = "Pawn ",
    ["aucun"] = "none",
    ["début"] = "start",
    ["lancé"] = "launched",
    ["sauvé"] = "saved",
    ["ÉCHEC"] = "FAILED",
    ["Sauver"] = "Save",
    ["appelé"] = "called",
    ["aucune"] = "none",
    ["chargé"] = "loaded",
    ["relevé"] = "revived",
    ["sauvés"] = "saved",
    ["Charger"] = "Load",
    ["Contour"] = "Outline",
    ["ERREUR "] = "ERROR ",
    ["Journal"] = "Journal",
    ["Preset "] = "Preset ",
    ["Presets"] = "Presets",
    ["Rupture"] = "Rupture",
    ["affiché"] = "shown",
    ["demandé"] = "requested",
    [" réanimé"] = " revived",
    ["méthode "] = "method ",
    ["toujours"] = "always",
    ["  état : "] = "  state: ",
    ["+ 1 éclat"] = "+ 1 shard",
    ["- 1 éclat"] = "- 1 shard",
    ["Mod actif"] = "Mod enabled",
    ["Restaurer"] = "Restore",
    ["désactivé"] = "disabled",
    ["en combat"] = "in combat",
    ["illisible"] = "unreadable",
    [" en combat"] = " in combat",
    ["IMPOSSIBLE"] = "IMPOSSIBLE",
    ["Sauver##ps"] = "Save##ps",
    ["par le jeu"] = "by the game",
    ["par le mod"] = "by the mod",
    ["Charger##pc"] = "Load##pc",
    ["SECONDE VIE"] = "SECOND LIFE",
    ["coup mortel"] = "fatal blow",
    ["feu de camp"] = "campfire",
    ["hors combat"] = "outside combat",
    ["transition "] = "transition ",
    ["-%d dans %ds"] = "-%d in %ds",
    ["Restaurer##pr"] = "Restore##pr",
    ["déjà en cours"] = "already running",
    ["fin du combat"] = "combat ended",
    ["Outils de test"] = "Test tools",
    ["  revenir à la vie même à 0 éclat"] = "  come back to life even at 0 shard",
    ["Afficher le panneau dans le menu pause (nouveau en v0.63)"] = "Show the panel in the pause menu (new in v0.63)",
    ["Aperçu du panneau (hors pause)"] = "Panel preview (outside pause)",
    ["[aperçu actif]"] = "[preview active]",
    ["Aucune séquelle"] = "No affliction",
    ["  ligne « rien à soigner » chez la voyante quand aucun traumatisme"] = "  \"nothing to cure\" line at the seer when there is no trauma",
    ["  remède sous chaque traumatisme (une fois révélé par une voyante)"] = "  remedy under each trauma (once revealed by a seer)",
    ["  Soins : Voyante (Traumatismes seulement) ; les Séquelles guérissent à l'auberge ou à la Pierre de faille."] = "  Cures: Seer (Traumas only); Afflictions heal at the inn or at a Riftstone.",
    ["Traumatismes : rien à soigner"] = "Traumas: nothing to cure",
    ["Aucune voyante désignée : un traumatisme subi ne pourrait pas être soigné."] = "No seer set: a trauma you pick up could not be cured.",
    ["ATTENTION : %d traumatisme(s) actif(s) et aucune voyante désignée."] = "WARNING: %d active trauma(s) and no seer set.",
    ["AUCUNE VOYANTE DÉSIGNÉE : tes traumatismes ne peuvent pas être soignés."] = "NO SEER SET: your traumas cannot be cured.",
    ["Qui soigne tes traumatismes"] = "Who cures your traumas",
    ["Il te manque : "] = "You are missing: ",
    ["Il te manque encore :"] = "You are still missing:",
    ["%d× %s — tu en as %d"] = "%d× %s — you have %d",
    ["Donner à la voyante, pour apaiser %s :"] = "Give the seer, to soothe %s:",
    ["Donner les ingrédients"] = "Give the ingredients",
    ["%d pièces"] = "%d coins",
    ["  — prêt"] = "  — ready",
    ["voyante : retrait incomplet de "] = "seer: incomplete removal of ",
    ["voyante (%s) : %s donné%s"] = "seer (%s): %s given%s",
    ["  ligne « rien à soigner » chez la voyante quand tout va bien"] = "  \"nothing to cure\" line at the seer when all is well",
    ["  couleurs personnalisées pour les ingrédients (sinon : grisé du jeu pour ce qui manque)"] = "  custom colours for the ingredients (otherwise: the game's grey for what is missing)",
    ["  ingrédient qui manque##voy_gris_c"] = "  missing ingredient##voy_gris_c",
    ["  ingrédient complet##voy_complet_c"] = "  complete ingredient##voy_complet_c",
    ["Qui soigne tes séquelles et traumatismes"] = "Who cures your afflictions and traumas",
    ["AUCUNE VOYANTE DÉSIGNÉE : rien ne peut être soigné."] = "NO SEER SET: nothing can be cured.",
    ["  Parle à un PNJ en jeu (ouvre son menu de discussion), reviens ici, puis clique sur le bouton ci-dessous."] = "  Talk to an NPC in game (open their talk menu), come back here, then click the button below.",
    ["  Dernier PNJ à qui tu as parlé : %s (menu %s)"] = "  Last NPC you talked to: %s (menu %s)",
    ["Ce PNJ est une voyante##voy_add"] = "This NPC is a seer##voy_add",
    ["  C'est une voyante : les soins s'affichent dans son menu."] = "  She is a seer: the cures show up in her menu.",
    ["  Aucun PNJ relevé pour l'instant : va parler à quelqu'un en jeu."] = "  No NPC recorded yet: go and talk to someone in game.",
    ["  Voyantes connues : %d"] = "  Known seers: %d",
    ["  %d voyante(s) ajoutée(s) au lancement (d'origine ou depuis Économie dynamique)."] = "  %d seer(s) added at launch (built-in or from Dynamic Economy).",
    ["ATTENTION : %d séquelle(s) / traumatisme(s) actif(s) et aucune voyante désignée."] = "WARNING: %d active affliction(s) / trauma(s) and no seer set.",
    ["Aucune voyante désignée : ni séquelle ni traumatisme ne pourrait être soigné."] = "No seer set: no affliction or trauma could be cured.",
    ["  Ouvre « Voyante active » plus bas pour en désigner une."] = "  Open the seer option below to set one.",
    ["Remède : "] = "Remedy: ",
    ["Remède : à demander à une voyante"] = "Remedy: ask a seer",
    ["Traumatisme"] = "Trauma",
    ["Guérie"] = "Healed",
    ["    0 éclat → 3 Séquelles rang I : la survie reste possible, mais elle coûte cher."] = "    0 shard -> 3 rank I Afflictions: survival stays possible, but it costs dearly.",
    ["    À 0 éclat, aucun recours : l'écran de mort reprend la main."] = "    At 0 shard, no recourse: the death screen takes over.",
    ["    Dans tous les cas, les Séquelles déjà subies deviennent des Traumatismes."] = "    In every case, Afflictions already suffered become Traumas.",
    ["MORT SANS RECOURS"] = "DEATH WITHOUT RECOURSE",
    ["  retour direct à la dernière auberge (plus de choix de chargement)"] = "  load straight from the last inn (no loading choice)",
    ["  Sinon, l'écran « Cette histoire est terminée » et ses 4 options restent."] = "  Otherwise the \"This tale is ended\" screen and its 4 options remain.",
    ["Écran de mort"] = "Death screen",
    ["Accrochage pose : "] = "Hook installed: ",
    ["Appels du hook : "] = "Hook calls: ",
    ["Phase du jeu : "] = "Game phase: ",
    ["FlowNow : "] = "FlowNow: ",
    ["Dernière action : "] = "Last action: ",
    ["Ret (choix validé) : "] = "Ret (confirmed choice): ",
    ["Preset %d : %s"] = "Preset %d: %s",
    ["bouton de test"] = "test button",
    ["chute ou autre"] = "fall or other",
    ["lumière finale"] = "final light",
    ["Éclats maximum"] = "Maximum shards",
    ["début du combat"] = "combat started",
    ["jauge classique"] = "classic gauge",
    ["%s : réglages %s"] = "%s: settings %s",
    ["Vider les éclats"] = "Empty the shards",
    ["preset « %s » %s"] = "preset \"%s\" %s",
    ["remise à zéro : "] = "reset: ",
    ["Contour##jauge_c4"] = "Outline##jauge_c4",
    ["Fond des segments"] = "Segment background",
    ["   |   INCANTATION"] = "   |   CASTING",
    ["Position verticale"] = "Vertical position",
    ["Remplir les éclats"] = "Fill the shards",
    ["Revenir à la vie ?"] = "Return to life?",
    ["Affichage actuel : "] = "Current display: ",
    ["bouton de test (+1)"] = "test button (+1)",
    ["bouton de test (-1)"] = "test button (-1)",
    ["Éclats de vie prêts"] = "Shards of Life ready",
    ["Longueur totale (px)"] = "Total length (px)",
    ["Position horizontale"] = "Horizontal position",
    ["Réglages par défaut…"] = "Default settings…",
    ["Transpierre utilisée"] = "Wakestone used",
    ["  seulement en combat"] = "  only in combat",
    [" (aucun éclat de vie)"] = " (no Shard of Life)",
    [" — retirée par le mod"] = " — removed by the mod",
    ["Breath of Life réussi"] = "Breath of Life succeeded",
    ["auberge / temps passé"] = "inn / time passed",
    [", relevé natif demandé"] = ", native revival requested",
    ["erreur HUD Controls : "] = "HUD Controls error: ",
    ["Avant remise par défaut"] = "Before reset to defaults",
    ["Éclats de vie perdus : "] = "Shards of Life lost: ",
    ["HUD Controls non détecté"] = "HUD Controls not detected",
    ["REMISE À ZÉRO DES ÉCLATS"] = "SHARD RESET",
    ["décroissance hors combat"] = "decay outside combat",
    ["voyage (%.0f m d'un coup)"] = "travel (%.0f m at once)",
    ["Utiliser les Éclats de vie"] = "Use Shards of Life",
    ["COMPATIBILITÉ « BardN Death System »"] = "COMPATIBILITY \"BardN Death System\"",
    ["  « Non » à l'écran de mort = réapparition à la dernière pierre de faille (au lieu du menu de chargement)"] = "  \"No\" on the death screen = respawn at the last Riftstone (instead of the loading menu)",
    ["  état : BardN Death System détecté"] = "  status: BardN Death System detected",
    ["  état : BardN Death System non détecté (« Non » ouvre le menu de chargement)"] = "  status: BardN Death System not detected (\"No\" opens the loading menu)",
    ["COMPATIBILITÉ « BardN Death System » (nouveau en v0.47)"] = "COMPATIBILITY \"BardN Death System\" (new in v0.47)",
    ["RESPAWN : blocage %s n°%d, %.0f s après le respawn (joueur mort : %s)"] = "RESPAWN: block %s #%d, %.0f s after the respawn (player dead: %s)",
    ["RESPAWN : nouvelle mort — garde levée"] = "RESPAWN: new death — guard lifted",
    ["RESPAWN : séquence déjà en cours"] = "RESPAWN: sequence already running",
    ["RESPAWN : déclenchement annulé (l'Insurgé est vivant)"] = "RESPAWN: trigger cancelled (the Arisen is alive)",
    ["RESPAWN : la mort est prise en charge par BardN Death System"] = "RESPAWN: the death is handled by BardN Death System",
    ["RESPAWN : déclenchement IMPOSSIBLE — menu de chargement"] = "RESPAWN: trigger IMPOSSIBLE — loading menu",
    ["SECONDE VIE : « Non » aux éclats — retour au jeu, respawn de BardN Death System"] = "SECOND LIFE: \"No\" to the shards — back to the game, respawn by BardN Death System",
    ["RESPAWN : « Non » au dialogue du jeu — retour au jeu, respawn de BardN Death System"] = "RESPAWN: \"No\" on the game's dialogue — back to the game, respawn by BardN Death System",
    ["ÉCRAN UNIQUE : « Non » choisi — retour au jeu "] = "SINGLE SCREEN: \"No\" chosen — back to the game ",
    [", respawn de BardN Death System"] = ", respawn by BardN Death System",
    ["après une Pierre de Réveil"] = "after a Wakestone",
    ["repos (%s, %.1f h passées)"] = "rest (%s, %.1f h passed)",
    ["Afficher la jauge classique"] = "Show the classic gauge",
    ["Fond des segments##jauge_c1"] = "Segment background##jauge_c1",
    ["éclats de vie %d -> %d (%s)"] = "Shards of Life %d -> %d (%s)",
    ["HUD Controls : jauge déclarée"] = "HUD Controls: gauge registered",
    ["BardN Shards of Life — Séquelles et Traumatismes (barre d'icônes)"] = "BardN Shards of Life — Sequelae and Traumas (icon bar)",
    ["Écart entre les segments (px)"] = "Gap between segments (px)",
    ["NON sauvés (erreur d'écriture)"] = "NOT saved (write error)",
    ["ÉCRAN UNIQUE : le jeu appelle "] = "SINGLE SCREEN: the game calls ",
    ["Éclats de vie (Shards of Life)"] = "Shards of Life",
    ["IMPOSSIBLE (texte du jeu gardé)"] = "IMPOSSIBLE (game text kept)",
    ["éclats de vie déjà au maximum ("] = "Shards of Life already at maximum (",
    ["Éclats de vie consommés : relevé"] = "Shards of Life spent: revival",
    ["Utiliser une Pierre de Réveil (%d)"] = "Use a Wakestone (%d)",
    ["Éclats de vie : %d / %d   |   %s%s"] = "Shards of Life: %d / %d   |   %s%s",
    ["Remplissage (tous les éclats prêts)"] = "Fill (all shards ready)",
    ["Remplissage (éclats pas tous prêts)"] = "Fill (shards not all ready)",
    [" réanimé hors combat : pas d'énergie"] = " revived outside combat: no shard",
    ["BardN Shards of Life — Éclats de vie"] = "BardN Shards of Life — Shards of Life",
    ["Épaisseur du contour (px, 0 = aucun)"] = "Outline thickness (px, 0 = none)",
    ["après une nuit (auberge, feu de camp)"] = "after a night (inn, campfire)",
    ["Épaisseur / hauteur des segments (px)"] = "Segment thickness / height (px)",
    ["Avant la dernière remise par défaut : "] = "Before the last reset to defaults: ",
    ["ÉCRAN UNIQUE : essai %d/%d « %s » : %s"] = "SINGLE SCREEN: attempt %d/%d \"%s\": %s",
    ["Breath of Life (résurrection des pions)"] = "Breath of Life (pawn resurrection)",
    ["ÉCRAN UNIQUE : signature non essayée : "] = "SINGLE SCREEN: signature not tried: ",
    ["  toujours visible pendant l'incantation"] = "  always visible during the incantation",
    [" réanimé par la capacité : pas d'énergie"] = " revived by the ability: no shard",
    ["SECONDE VIE : dialogue « Éclats de vie » "] = "SECOND LIFE: \"Shards of Life\" dialogue ",
    ["SECONDE VIE : mort avec la jauge pleine ("] = "SECOND LIFE: death with a full gauge (",
    ["Remettre l'apparence de la jauge par défaut"] = "Reset the gauge appearance to default",
    ["repos / temps passé (heure du jeu illisible)"] = "rest / time passed (game time unreadable)",
    ["Remplissage (tous les éclats prêts)##jauge_c3"] = "Fill (all shards ready)##jauge_c3",
    ["Remplissage (éclats pas tous prêts)##jauge_c2"] = "Fill (shards not all ready)##jauge_c2",
    ["après un voyage (char à bœufs, téléportation)"] = "after travelling (ox-cart, teleport)",
    ["SECONDE VIE : retrait de la Pierre de Réveil annulé"] = "SECOND LIFE: Wakestone removal cancelled",
    ["réglages remis par défaut (anciens réglages sauvés)"] = "settings reset to defaults (old settings saved)",
    ["SECONDE VIE : état abandonné (relevé terminé) après l'écran à 3 choix"] = "SECOND LIFE: state dropped (revival finished) after the 3-choice screen",
    ["SECONDE VIE : état abandonné (relevé par autre chose) après l'écran à 3 choix"] = "SECOND LIFE: state dropped (revived by something else) after the 3-choice screen",
    ["SECONDE VIE : état abandonné (délai de 120 s dépassé) après l'écran à 3 choix"] = "SECOND LIFE: state dropped (120 s timeout) after the 3-choice screen",
    ["ÉCRAN UNIQUE : fenêtre fermée %.1f s après son ouverture"] = "SINGLE SCREEN: window closed %.1f s after opening",
    ["ÉCRAN UNIQUE : « Non » choisi — menu de chargement "] = "SINGLE SCREEN: \"No\" chosen — loading menu ",
    ["  heures de jeu minimales passées (hors feu de camp)"] = "  minimum game hours elapsed (without a campfire)",
    ["ÉCRAN UNIQUE : %d vraie(s) Pierre(s) avant le relevé"] = "SINGLE SCREEN: %d real Wakestone(s) before the revival",
    ["ÉCRAN UNIQUE : Insurgé relevé par la Pierre de Réveil"] = "SINGLE SCREEN: Arisen revived by the Wakestone",
    ["ÉCRAN UNIQUE : Pierre de Réveil consommée (%d → %d)%s"] = "SINGLE SCREEN: Wakestone consumed (%d → %d)%s",
    ["Remettre l'apparence de la jauge par défaut##jauge_raz"] = "Reset the gauge appearance to default##jauge_raz",
    ["Utiliser les règles de HUD Controls (s'il est installé)"] = "Use HUD Controls rules (if installed)",
    ["ÉCRAN UNIQUE : Pierre de Réveil choisie — retour au jeu "] = "SINGLE SCREEN: Wakestone chosen — back to the game ",
    ["ÉCRAN UNIQUE : relevé natif par la Pierre, essai %d : %s"] = "SINGLE SCREEN: native revival by the Wakestone, attempt %d: %s",
    ["toujours"] = "always",
    ["GAIN : un éclat de vie chaque fois que tu relèves un pion"] = "GAIN: one Shard of Life each time you revive a pawn",
    ["ÉCRAN UNIQUE : retrait de la Pierre de Réveil demandé (%s)"] = "SINGLE SCREEN: Wakestone removal requested (%s)",
    ["  un seul écran : Éclats de vie / Pierre de Réveil (N) / Non"] = "  a single screen: Shards of Life / Wakestone (N) / No",
    [") — Éclats de vie proposés à la place de la Pierre de Réveil"] = ") — Shards of Life offered in place of the Wakestone",
    ["ERREUR : Hit_ReviveHandler introuvable, détection impossible"] = "ERROR: Hit_ReviveHandler not found, detection impossible",
    ["orbes de lumière dans BardN_KH_HUD (jauge classique masquée)"] = "light orbs in BardN_KH_HUD (classic gauge hidden)",
    ["  si je refuse les éclats, proposer ensuite la Pierre de Réveil"] = "  if I refuse the shards, then offer the Wakestone",
    ["relevé par une vraie Pierre de Réveil : éclats de vie conservés"] = "revived by a real Wakestone: Shards of Life kept",
    ["remise à zéro de l'Insurgé (%s) : annulation %s, haut du corps %s"] = "Arisen reset (%s): cancellation %s, upper body %s",
    ["ÉCRAN UNIQUE : relevé par la Pierre IMPOSSIBLE — menu de chargement"] = "SINGLE SCREEN: revival by the Wakestone IMPOSSIBLE — loading menu",
    ["SECONDE VIE : impossible de reproposer la Pierre (menu de chargement)"] = "SECOND LIFE: unable to offer the Wakestone again (loading menu)",
    ["ÉCRAN UNIQUE : retrait de la Pierre IMPOSSIBLE — envoie-moi le journal"] = "SINGLE SCREEN: Wakestone removal IMPOSSIBLE — send me the journal",
    ["temps passé de %.1f h seulement (pas de camp) : éclats de vie conservés"] = "only %.1f h passed (no camp): Shards of Life kept",
    ["  (orbes : menu BardN_KH_HUD > Wakestone Counter > Show Life Shard Orbs)"] = "  (orbs: BardN_KH_HUD menu > Wakestone Counter > Show Life Shard Orbs)",
    ["connecté à HUD Controls (élément « BardN Shards of Life — Éclats de vie »)"] = "connected to HUD Controls (element \"BardN Shards of Life — Shards of Life\")",
    ["SECONDE VIE : « Non » aux éclats — Pierre de Réveil classique proposée (%d)"] = "SECOND LIFE: \"No\" to the shards — classic Wakestone offered (%d)",
    [">>> CONFIRMER : tout remettre par défaut (réglages actuels sauvés avant) <<<"] = ">>> CONFIRM: reset everything to defaults (current settings saved first) <<<",
    ["ÉCRAN UNIQUE : aucune vraie Pierre comptée avant le relevé — rien à vérifier"] = "SINGLE SCREEN: no real Wakestone counted before the revival — nothing to check",
    ["Tous les éclats = une seconde vie (écran et relevé natifs de la Pierre de Réveil)"] = "All shards = a second life (the game's native Wakestone screen and revival)",
    ["SECONDE VIE : « Non » aux éclats — éclats conservés, pas de vraie Pierre de Réveil"] = "SECOND LIFE: \"No\" to the shards — shards kept, no real Wakestone",
    ["SECONDE VIE : relevé natif par la Pierre de Réveil — jauge vidée, vraies pierres conservées"] = "SECOND LIFE: native revival by the Wakestone — gauge emptied, real Wakestones kept",
    ["  l'afficher même quand BardN_KH_HUD affiche déjà les orbes (pour la régler / avoir les deux)"] = "  show it even when BardN_KH_HUD already shows the orbs (to adjust it / have both)",
    ["ÉCRAN UNIQUE : la Pierre n'a PAS été retirée par le jeu (%d pierres, retrait vu : %d, appels vus : %d) → retrait par le mod"] = "SINGLE SCREEN: the game did NOT remove the Wakestone (%d stones, removal seen: %d, calls seen: %d) → removal by the mod",
}
R.cache_t, R.cache_n = {}, 0
-- réglage initial : config déjà existante → français (comme avant), sinon automatique
if cfg.langue ~= "fr" and cfg.langue ~= "en" and cfg.langue ~= "auto" then
    cfg.langue = (version_lue ~= nil) and "fr" or "auto"
end
function R.en_actif()
    local l = cfg.langue
    if l == "en" then return true end
    if l == "fr" then return false end
    return R.langue_jeu ~= "fr"            -- auto : anglais tant que le jeu n'a pas dit « français »
end
-- une lettre (ASCII ou lettre accentuée du français) : sert à ne pas couper un mot
function R.lettre_avant(s, i)              -- dernier octet du caractère précédent, en position i
    local b = s:byte(i)
    if b == nil then return false end
    if (b >= 48 and b <= 57) or (b >= 65 and b <= 90) or (b >= 97 and b <= 122) then return true end
    if b >= 0x80 and b <= 0xBF then
        local p = s:byte(i - 1)
        return p == 0xC3 or (p == 0xC5 and b == 0x93)
    end
    return false
end
function R.lettre_apres(s, i)              -- premier octet du caractère suivant, en position i
    local b = s:byte(i)
    if b == nil then return false end
    if (b >= 48 and b <= 57) or (b >= 65 and b <= 90) or (b >= 97 and b <= 122) then return true end
    return b == 0xC3 or (b == 0xC5 and s:byte(i + 1) == 0x93)
end
function R.traduire(s)
    local EN = R.EN
    local e = EN[s]
    if e then return e end
    local a, b = s:match("^(.-)(##.*)$")        -- « texte##identifiant » : on traduit le texte seulement
    if a then return R.traduire(a) .. b end
    local lead, core, trail = s:match("^(%s*)(.-)(%s*)$")
    if (lead ~= "" or trail ~= "") and core ~= "" then
        e = EN[core]
        if e then return lead .. e .. trail end
    end
    if R.EN_CLES == nil then
        local l = {}
        for k in pairs(EN) do if #k >= 2 then l[#l + 1] = k end end
        table.sort(l, function(x, y) if #x ~= #y then return #x > #y end return x < y end)
        R.EN_CLES = l
    end
    local rempl, out = {}, s
    for _, k in ipairs(R.EN_CLES) do
        if out:find(k, 1, true) then
            local parts, init = {}, 1
            local k1, k2 = k:byte(1), k:byte(#k)
            local debut_mot = R.lettre_apres(k, 1)
            local fin_mot = R.lettre_avant(k, #k)
            while true do
                local i, j = out:find(k, init, true)
                if not i then break end
                local ok = true
                if debut_mot and i > 1 and R.lettre_avant(out, i - 1) then ok = false end
                if fin_mot and R.lettre_apres(out, j + 1) then ok = false end
                if ok then
                    parts[#parts + 1] = out:sub(init, i - 1)
                    rempl[#rempl + 1] = EN[k]
                    parts[#parts + 1] = "\1" .. #rempl .. "\2"
                    init = j + 1
                else
                    parts[#parts + 1] = out:sub(init, i)
                    init = i + 1
                end
            end
            parts[#parts + 1] = out:sub(init)
            out = table.concat(parts)
        end
    end
    if #rempl > 0 then out = out:gsub("\1(%d+)\2", function(n) return rempl[tonumber(n)] end) end
    out = out:gsub("«%s?", '"'):gsub("%s?»", '"'):gsub(" : ", ": ")
    return out
end
function R.T(s)
    if type(s) ~= "string" or s == "" or not R.en_actif() then return s end
    local c = R.cache_t[s]
    if c then return c end
    if R.cache_n > 4000 then R.cache_t, R.cache_n = {}, 0 end
    local ok, r = pcall(R.traduire, s)
    if not ok or type(r) ~= "string" then r = s end
    R.cache_t[s] = r
    R.cache_n = R.cache_n + 1
    return r
end
function R.fmt(f, ...) return string.format(R.T(f), ...) end
-- v0.62 : diagnostic de l'ecran de mort, cree tot pour que le menu puisse
-- l'afficher meme si l'accrochage echoue plus bas.
R.mort_diag = { hooks = 0, phase = "-", idx = "-", ret = "-", scl = "-",
                maj = "-", decl = "-", voie_lec = "-" }
function R.dtext(t, ...) return draw.text(R.T(t), ...) end
-- étiquette de widget : le texte change avec la langue, l'identifiant ImGui reste celui du français
function R.etiquette(s)
    if type(s) ~= "string" or not R.en_actif() then return s end
    local t = R.T(s)
    if t ~= s and not s:find("##", 1, true) then return t .. "##" .. s end
    return t
end
-- v0.11 : langue du jeu (réglage « Auto »)
function R.changer_langue(l)
    cfg.langue = l
    R.cache_t, R.cache_n = {}, 0
    sauver()
end
function R.detecter_langue()
    R.langue_essais = (R.langue_essais or 0) + 1
    local trouve, notes = nil, 0
    for _, nom in ipairs({ "app.OptionManager", "app.GuiManager", "app.GameManager", "app.SaveDataManager" }) do
        local obj, td = nil, nil
        pcall(function() obj = sdk.get_managed_singleton(nom); td = sdk.find_type_definition(nom) end)
        if obj and td then
            local ms = {}
            pcall(function() ms = td:get_methods() end)
            for _, m in ipairs(ms) do
                local n = m:get_name()
                local lis = false
                pcall(function()
                    lis = n:sub(1, 3) == "get" and n:lower():find("language", 1, true) ~= nil
                          and #m:get_param_types() == 0 and not m:is_static()
                end)
                if lis then
                    local ok, v = pcall(function() return m:call(obj) end)
                    if ok and type(v) == "number" then
                        local nomE = nil
                        pcall(function()
                            for _, f in ipairs(m:get_return_type():get_fields()) do
                                if f:is_static() and f:get_data(nil) == v then nomE = f:get_name() end
                            end
                        end)
                        if notes < 4 then
                            notes = notes + 1
                            R.evenement(string.format("langue du jeu : %s.%s = %s (%s)", nom, n, tostring(v), tostring(nomE)))
                        end
                        if nomE and not trouve then trouve = nomE:lower():find("french", 1, true) and "fr" or "en" end
                    end
                end
            end
        end
        if trouve then break end
    end
    if trouve then
        if R.langue_jeu ~= trouve then R.cache_t, R.cache_n = {}, 0 end
        R.langue_jeu = trouve
    end
    return trouve
end
function R.suivre_langue()
    if cfg.langue ~= "auto" or R.langue_jeu ~= nil then return end
    local now = os.clock()
    if (R.langue_essais or 0) >= 4 or now < (R.langue_prochain or 0) then return end
    R.langue_prochain = now + 4.0
    if not R.detecter_langue() and (R.langue_essais or 0) >= 4 then
        R.evenement("langue du jeu non détectée : anglais (choisis Français / English en haut du menu)")
    end
end
-- le menu et l'écran passent par ces enveloppes : les textes sont traduits au moment de l'affichage
local imgui = setmetatable({}, { __index = function(t, k)
    local f = rawget(_G, "imgui")[k]
    if type(f) ~= "function" then return f end
    local texte = (k == "text" or k == "text_colored" or k == "text_wrapped" or k == "bullet_text")
    local widget = (k == "button" or k == "small_button" or k == "checkbox" or k == "slider_float" or k == "slider_int"
        or k == "drag_float" or k == "drag_int" or k == "tree_node" or k == "color_edit4" or k == "color_edit3" or k == "color_picker"
        or k == "collapsing_header" or k == "selectable" or k == "radio_button" or k == "input_text"
        or k == "combo")
    local w = f
    if texte then
        w = function(...)
            local n = select("#", ...)
            local a = { ... }
            for i = 1, n do if type(a[i]) == "string" then a[i] = R.T(a[i]) end end
            return f(table.unpack(a, 1, n))
        end
    elseif widget then
        w = function(...)
            local n = select("#", ...)
            local a = { ... }
            if type(a[1]) == "string" then a[1] = R.etiquette(a[1]) end
            if (k == "slider_float" or k == "slider_int") and type(a[5]) == "string" then a[5] = R.T(a[5]) end
            return f(table.unpack(a, 1, n))
        end
    end
    rawset(t, k, w)
    return w
end })
local t0 = os.clock()
local function maintenant() return os.clock() - t0 end

local unites = 0           -- éclats de vie : entier 0 .. energie_max (v0.10 : plus d'unités)
local en_combat = false

local membres = {}                -- adresse Character -> {nom, chr}
local dernier_rafraichissement = -10
local dernier_gain_par_pion = {}
local reanimations_du_mod = {}

local evenements = {}
local journal_sale = false
local dbg_seq_sel = 1  -- v0.62 : index choisi dans le combo « Outils de test » (séquelles/traumas)
local function evenement(txt)
    table.insert(evenements, 1, string.format("[%7.1f] %s", maintenant(), R.T(txt)))
    if #evenements > 250 then table.remove(evenements) end
    journal_sale = true
end
R.evenement = evenement

-- v0.45 : plus de table ni de fermeture créées à chaque appel (c'était le
-- premier poste d'allocations de la boucle d'image).
local function APPEL(o, n, ...) return o:call(n, ...) end
local function appeler(obj, nom, ...)
    if obj == nil then return nil end
    local ok, v = pcall(APPEL, obj, nom, ...)
    if ok then return v end
end
local function adresse(obj)
    if obj == nil then return nil end
    local ok, a = pcall(function() return obj:get_address() end)
    if ok then return a end
end
local function elements(obj)
    if obj == nil then return {} end
    local ok, t = pcall(function() return obj:get_elements() end)
    if ok and type(t) == "table" and #t > 0 then return t end
    local res = {}
    local n = appeler(obj, "get_Count")
    if type(n) == "number" then
        for i = 0, n - 1 do
            local e = appeler(obj, "get_Item", i)
            if e ~= nil then res[#res + 1] = e end
        end
    end
    return res
end

-- v0.45 : une seule lecture de l'Insurgé par image (elle était faite 4 à 6 fois).
R.cadre = { ok = false, pj = nil }
local function joueur()
    local c = R.cadre
    if c.ok then return c.pj end
    c.ok = true
    c.pj = appeler(sdk.get_managed_singleton("app.CharacterManager"), "get_ManualPlayer")
    return c.pj
end

local function rafraichir_groupe()
    local nouv = {}
    local pm = sdk.get_managed_singleton("app.PawnManager")
    for i, pw in ipairs(elements(appeler(pm, "getAllPartyPawn"))) do
        local c = appeler(pw, "get_CachedCharacter")
        local a = adresse(c)
        if a then nouv[a] = { nom = "Pion " .. i, chr = c } end
    end
    membres = nouv
    -- v0.45 : purge des repères d'anti-doublon (ils ne grossissent plus sans fin)
    local t = maintenant()
    for a, v in pairs(dernier_gain_par_pion) do if t - v > 60 then dernier_gain_par_pion[a] = nil end end
    for a, v in pairs(reanimations_du_mod) do if t - v > 60 then reanimations_du_mod[a] = nil end end
end

local function position(chr)
    local tr = appeler(appeler(chr, "get_GameObject"), "get_Transform")
    local p = appeler(tr, "get_Position")
    if p == nil then return nil end
    local ok, x, y, z = pcall(function() return p.x, p.y, p.z end)
    if ok and type(x) == "number" then return { x = x, y = y, z = z } end
end
local function distance(a, b)
    if a == nil or b == nil then return math.huge end
    local dx, dy, dz = a.x - b.x, a.y - b.y, a.z - b.z
    return math.sqrt(dx * dx + dy * dy + dz * dz)
end

local function noeud_fsm(chr)
    local am = appeler(chr, "get_ActionManager")
    if am == nil then return "" end
    local ok, fsm = pcall(function() return am:get_field("Fsm") end)
    if not ok or fsm == nil then return "" end
    return appeler(fsm, "getCurrentNodeName", 0) or ""
end

-- ----------------------------------------------------------------------------
-- API publique (interface séparée, autres mods)
-- ----------------------------------------------------------------------------
_G.BardN_ShardsOfLife = _G.BardN_ShardsOfLife or {}
local api = _G.BardN_ShardsOfLife
api.version = "0.62"
api.api_niveau = 2                      -- v0.48 : interface étendue (Séquelles, Traumatismes, voyante)
api.get_energie = function() return unites end
api.get_energie_max = function() return cfg.energie_max end
api.est_en_combat = function() return en_combat end

-- v0.10 : la jauge compte directement des éclats de vie (1 segment = 1 éclat)
local function changer_unites(delta, raison, discret)
    local avant_u = unites
    if delta < 0 and unites > 0 and cfg.jauge_message_perte then   -- v0.62 : message sous la jauge
        local txt = tostring(raison or ""):gsub("^remise à zéro : ", "")
        R.message = { txt = "Éclats de vie perdus : " .. txt, fin = os.clock() + 3.0 }
    end
    unites = math.floor(math.max(0, math.min(cfg.energie_max, unites + delta)) + 1e-6)
    if not discret then
        if unites ~= avant_u then
            evenement(R.fmt("éclats de vie %d -> %d (%s)", avant_u, unites, raison))
        elseif delta > 0 then
            evenement("éclats de vie déjà au maximum (" .. raison .. ")")
        end
    end
end
api.changer_unites = changer_unites
api.get_unites = function() return unites end

-- compatibilité : ajuster en éclats
local function ajuster(delta, raison) changer_unites(delta, raison) end
api.incantation = false                  -- v0.44 : vrai pendant une incantation d'Ultimate Breath of Life (posé par ce mod)
api.abonnes_seconde_vie = api.abonnes_seconde_vie or {}   -- v0.44 : nom -> fonction appelée quand la seconde vie relève l'Insurgé
-- v0.44 : une réanimation faite par un autre mod (Breath of Life) ne rapporte pas d'éclat
api.marquer_reanimation = function(adr) reanimations_du_mod[adr or -1] = maintenant() end
-- v0.44 : position de la jauge à l'écran (mise à jour à chaque image) : x, y, w (largeur totale), h, ech, sw, sh, alpha
R.geo = { x = 0, y = 0, w = 0, h = 0, ech = 1, sw = 1920, sh = 1080, alpha = 0.0 }
api.jauge = R.geo
api.jauge_rect = function() return R.geo end
for k, v in pairs({
    ["Interface à l'écran (HUD)"] = "On-screen interface (HUD)",
    ["Aperçu en direct de tous les éléments tant que ce tiroir est ouvert"] = "Live preview of every element while this drawer is open",
    ["L'aperçu montre la jauge, la barre d'incantation, la frange d'écran, l'anneau et le cercle de portée, même sans lancer de sort."] = "The preview shows the gauge, cast bar, screen fringe, ring and range circle even without casting a spell.",
    ["RÉGLAGE DE GROUPE (tous les éléments d'un coup)"] = "GROUP SETTINGS (all elements at once)",
    ["Décalage horizontal de la jauge et de la barre (fraction de l'écran)"] = "Horizontal offset of the gauge and bar (fraction of the screen)",
    ["Décalage vertical de la jauge et de la barre (fraction de l'écran)"] = "Vertical offset of the gauge and bar (fraction of the screen)",
    ["Échelle de la jauge et de la barre"] = "Scale of the gauge and bar",
    ["Remettre le réglage de groupe par défaut"] = "Reset group settings to default",
    ["HUD CONTROLS"] = "HUD CONTROLS",
    ["1. JAUGE D'ÉCLATS"] = "1. SHARDS GAUGE",
    ["Opacité de la jauge"] = "Gauge opacity",
    ["  couleurs (couleur du haut + couleur du bas = dégradé vertical) :"] = "  colours (top colour + bottom colour = vertical gradient):",
    ["(La jauge à l'écran se règle dans le tiroir « Interface à l'écran (HUD) ».)"] = "(The on-screen gauge is set in the \"On-screen interface (HUD)\" drawer.)",
    ["BardN Shards of Life — Barre d'incantation"] = "BardN Shards of Life — Cast bar",
    ["BardN Shards of Life — Frange d'écran"] = "BardN Shards of Life — Screen fringe",
    ["BardN Shards of Life — Cercles au sol"] = "BardN Shards of Life — Ground circles",
}) do R.EN[k] = v end
api.ajuster = ajuster

-- v0.44 : textes propres à ce mod
for k, v in pairs({
    ["Ultimate Breath of Life détecté (v%s)"] = "Ultimate Breath of Life detected (v%s)",
    ["Ultimate Breath of Life non installé (facultatif)"] = "Ultimate Breath of Life not installed (optional)",
    ["Aperçu en direct de la jauge tant que ce tiroir est ouvert"] = "Live preview of the gauge while this drawer is open",
    ["L'aperçu montre la jauge d'éclats même hors combat."] = "The preview shows the shards gauge even out of combat.",
    ["Opacité de la jauge (réglage de groupe)"] = "Gauge opacity (group setting)",
    ["Décalage horizontal de la jauge (fraction de l'écran)"] = "Horizontal offset of the gauge (fraction of the screen)",
    ["Décalage vertical de la jauge (fraction de l'écran)"] = "Vertical offset of the gauge (fraction of the screen)",
    ["Échelle de la jauge (la barre d'incantation d'Ultimate Breath of Life la suit)"] = "Gauge scale (the Ultimate Breath of Life cast bar follows it)",
    ["  toujours visible pendant une incantation d'Ultimate Breath of Life"] = "  always visible while casting an Ultimate Breath of Life spell",
    ["(La barre d'incantation, la frange et les cercles se règlent dans BardN Ultimate Breath of Life.)"] = "(The cast bar, fringe and circles are set in BardN Ultimate Breath of Life.)",
    ["(Les ultimes — Breath of Life, Slow Time — sont dans le mod BardN Ultimate Breath of Life.)"] = "(The ultimates — Breath of Life, Slow Time — are in the BardN Ultimate Breath of Life mod.)",
}) do R.EN[k] = v end
-- ----------------------------------------------------------------------------
local function sur_reanimation(adr)
    if not cfg.actif then return end
    local m = membres[adr]
    if m == nil then
        rafraichir_groupe()
        m = membres[adr]
        if m == nil then return end
    end
    local t = maintenant()
    local tm = reanimations_du_mod[adr]
    if tm and t - tm < 10.0 then
        reanimations_du_mod[adr] = nil
        evenement(m.nom .. " réanimé par la capacité : pas d'énergie")
        return
    end
    local tg = dernier_gain_par_pion[adr]
    if tg and t - tg < cfg.fenetre_anti_doublon then return end
    dernier_gain_par_pion[adr] = t
    if en_combat or not cfg.reanimation_combat_seul then
        changer_unites(1, m.nom .. " réanimé" .. (en_combat and " en combat" or ""))
    else
        evenement(m.nom .. " réanimé hors combat : pas d'énergie")
    end
end

do
    local td = sdk.find_type_definition("app.Character")
    local m = td and td:get_method("Hit_ReviveHandler")
    if m then
        sdk.hook(m, function(args)
            local ok, a = pcall(function() return sdk.to_int64(args[2]) end)
            if ok then pcall(sur_reanimation, a) end
            return sdk.PreHookResult.CALL_ORIGINAL
        end, function(r) return r end)
    else
        evenement("ERREUR : Hit_ReviveHandler introuvable, détection impossible")
    end
end

-- ============================================================================
-- v0.48 : SÉQUELLES ET TRAUMATISMES
-- ----------------------------------------------------------------------------
-- Deux couches de blessures :
--   * Séquelles (R.seq.actives) : blessures physiques infligées par Second Breath.
--     Durée en jours de jeu (cfg.seq_jours). Soignables par le repos à l'auberge
--     (incl. feu de camp), par une Pierre de faille, ou par une voyante.
--   * Traumatismes (R.tr.actives) : anciennes Séquelles devenues permanentes lors
--     d'une nouvelle résurrection punitive. Conservent le rang et les effets de
--     la Séquelle d'origine. Soignables UNIQUEMENT par une voyante.
--
-- Bibliothèque des 13 séquelles reprise de BardN_New_Death_System v1.01 (identique
-- afin que l'utilisateur retrouve les mêmes blessures en migrant).
-- Persistance : reframework/data/BardN_ShardsOfLife/{sequelles.json, traumatismes.json}
-- ============================================================================
math.randomseed(os.time())
local SEQ_FICHIER = "BardN_ShardsOfLife/sequelles.json"
local TR_FICHIER  = "BardN_ShardsOfLife/traumatismes.json"

local function borne(v, mn, mx)
    v = tonumber(v) or mn
    if v < mn then return mn elseif v > mx then return mx end
    return v
end
local function niv(cle, n) return cfg[cle .. (n == 2 and "_n2" or "_n1")] end

R.FAMILLES = { "Combat", "Endurance", "Soins", "Pions", "Équipement" }
R.SEQ_LIB = {
    -- Combat
    { id = "fragilite", famille = "Combat", nom = "Fragilité", on = "fra_on", niveaux = 2,
      effet = function(n) return R.fmt("+%d %% de dégâts subis", math.floor(niv("fra", n))) end },
    { id = "faiblesse", famille = "Combat", nom = "Faiblesse", on = "fai_on", niveaux = 2,
      effet = function(n) return R.fmt("−%d %% de dégâts infligés", math.floor(niv("fai", n))) end },
    { id = "instabilite", famille = "Combat", nom = "Instabilité", on = "ins_on", niveaux = 2,
      effet = function(n) return R.fmt("déséquilibre subi ×%d", math.floor(niv("ins", n))) end },
    { id = "vitalite", famille = "Combat", nom = "Vitalité diminuée", on = "vit_on", niveaux = 2,
      effet = function(n) return R.fmt("jauge blanche ×%.1f", 1 + (tonumber(niv("vit", n)) or 0) / 100) end },
    -- Endurance
    { id = "douleur", famille = "Endurance", nom = "Douleur persistante", on = "dou_on", niveaux = 2,
      effet = function(n) return R.fmt("+%d %% de coût d'endurance", math.floor(niv("dou", n))) end },
    { id = "epuisement", famille = "Endurance", nom = "Épuisement", on = "epu_on", niveaux = 2,
      effet = function(n) return R.fmt("−%d %% d'endurance max", math.floor(niv("epu", n))) end },
    { id = "essoufflement", famille = "Endurance", nom = "Essoufflement", on = "ess_on", niveaux = 2,
      condition = function() return R.ess_dispo() end,
      effet = function(n) return R.fmt("consommation max d'endurance ×%d", math.floor(niv("ess", n))) end },
    -- Soins
    { id = "metabolisme", famille = "Soins", nom = "Métabolisme perturbé", on = "met_on", niveaux = 2,
      effet = function(n) return R.fmt("−%d %% de soins reçus", math.floor(niv("met", n))) end },
    { id = "dysphagie", famille = "Soins", nom = "Dysphagie", on = "dys_on", niveaux = 1,
      effet = function() return R.T("impossible d'utiliser des consommables") end },
    -- Pions
    { id = "commotion", famille = "Pions", nom = "Commotion cérébrale", on = "com_on", niveaux = 1,
      effet = function() return R.T("les 4 ordres aux pions ne répondent plus") end },
    { id = "resurrection", famille = "Pions", nom = "Lien perdu", on = "res_on", niveaux = 1,
      effet = function() return R.T("impossible de ranimer ses pions") end },
    -- Équipement
    { id = "garde", famille = "Équipement", nom = "Garde défaillante", on = "gar_on", niveaux = 2,
      condition = function() return R.gar_dispo() end,
      effet = function(n) return R.fmt("chance de casse de l'équipement ×%d", math.floor(niv("gar", n))) end },
    { id = "surcharge", famille = "Équipement", nom = "Surcharge", on = "sur_on", niveaux = 2,
      effet = function(n) return R.fmt("−%d %% de charge maximale", math.floor(niv("sur", n))) end },
}
R.SEQ_PAR_ID = {}
for _, d in ipairs(R.SEQ_LIB) do R.SEQ_PAR_ID[d.id] = d end
local ROMAIN = { "I", "II", "III" }

-- Mods partenaires (publiés avec api_niveau ≥ 2)
R.gar_dispo = function()
    local a = rawget(_G, "BardN_EnemyBreak")
    return type(a) == "table" and (tonumber(a.api_niveau) or 0) >= 2
end
R.ess_dispo = function()
    local a = rawget(_G, "BardN_StaminaFatigue")
    return type(a) == "table" and (tonumber(a.api_niveau) or 0) >= 2
end

-- État
R.seq = { actives = {}, journal = {} }
R.tr  = { actives = {}, journal = {} }

local function seq_sauver() pcall(json.dump_file, SEQ_FICHIER, R.seq) end
local function tr_sauver()  pcall(json.dump_file, TR_FICHIER,  R.tr)  end
-- Chargement depuis le disque
do
    local ok, c = pcall(json.load_file, SEQ_FICHIER)
    if ok and type(c) == "table" and type(c.actives) == "table" then
        for id, a in pairs(c.actives) do
            if R.SEQ_PAR_ID[id] and type(a) == "table" then
                a.niveau = math.floor(borne(a.niveau, 1, R.SEQ_PAR_ID[id].niveaux))
                R.seq.actives[id] = a
            end
        end
        R.seq.journal = type(c.journal) == "table" and c.journal or {}
    end
    ok, c = pcall(json.load_file, TR_FICHIER)
    if ok and type(c) == "table" and type(c.actives) == "table" then
        for id, a in pairs(c.actives) do
            if R.SEQ_PAR_ID[id] and type(a) == "table" then
                a.niveau = math.floor(borne(a.niveau, 1, R.SEQ_PAR_ID[id].niveaux))
                R.tr.actives[id] = a
            end
        end
        R.tr.journal = type(c.journal) == "table" and c.journal or {}
    end
end

-- Accès rapide
function R.seq_niveau(id) local a = R.seq.actives[id]; return a and a.niveau or nil end
function R.tr_niveau(id)  local a = R.tr.actives[id];  return a and a.niveau or nil end
-- Niveau effectif (le plus sévère entre Séquelle et Trauma du même id)
function R.effet_niveau(id)
    local s, t = R.seq.actives[id], R.tr.actives[id]
    if s and t then return math.max(s.niveau, t.niveau) end
    if s then return s.niveau end
    if t then return t.niveau end
    return nil
end

local function seq_nom_niveau(d, n) return R.T(d.nom) .. (d.niveaux > 1 and (" " .. ROMAIN[n or 1]) or "") end
R.seq_nom_niveau = seq_nom_niveau
function R.seq_texte(id)
    local d, a = R.SEQ_PAR_ID[id], R.seq.actives[id]
    if not (d and a) then return id end
    return string.format("%s (%s)", seq_nom_niveau(d, a.niveau), d.effet(a.niveau))
end
function R.tr_texte(id)
    local d, a = R.SEQ_PAR_ID[id], R.tr.actives[id]
    if not (d and a) then return id end
    return string.format("%s (%s)", seq_nom_niveau(d, a.niveau), d.effet(a.niveau))
end
function R.seq_restant(a)
    local h = R.heure_jeu()
    if not (h and tonumber(a.fin)) then return "?" end
    local r = math.max(0, a.fin - h)
    return R.fmt("%d j %d h", math.floor(r / 24), math.floor(r % 24))
end

local function seq_journal(t)
    R.seq.journal[#R.seq.journal + 1] = os.date("%d/%m %H:%M") .. " — " .. t
    while #R.seq.journal > 60 do table.remove(R.seq.journal, 1) end
    evenement("SÉQUELLE : " .. t)
end
R.seq_journal = seq_journal
local function tr_journal(t)
    R.tr.journal[#R.tr.journal + 1] = os.date("%d/%m %H:%M") .. " — " .. t
    while #R.tr.journal > 60 do table.remove(R.tr.journal, 1) end
    evenement("TRAUMATISME : " .. t)
end
R.tr_journal = tr_journal

-- Annonce d'écran (bannière temporaire, visible 2–30 s)
R.annonce = nil
local function seq_annoncer(id, titre, ligne, est_trauma)
    R.annonce = { id = id, titre = titre, ligne = ligne or "", est_trauma = est_trauma == true,
                  debut = os.clock(), fin = os.clock() + borne(cfg.sx_annonce_duree, 2, 30) }
end
R.seq_annoncer = seq_annoncer

-- Ajoute une Séquelle (nouvelle ou aggravée). Rang = 1 par défaut ; le second
-- tirage de la même séquelle pousse au rang 2.
-- La voyante (Batch 3) écrira ici une recette d'ingrédients ; en v0.48 (Batch 1)
-- la table « recette » reste vide et sera remplie quand la voyante sera branchée.
function R.seq_appliquer(id, source)
    local d = R.SEQ_PAR_ID[id]
    if not d then return nil end
    local h = R.heure_jeu() or 0
    local a = R.seq.actives[id]
    local verbe, titre
    if not a then
        a = { niveau = 1, recette = {}, revele = false }
        R.seq.actives[id] = a
        verbe, titre = R.T("nouvelle séquelle"), R.T("Séquelle")
    elseif a.niveau < d.niveaux then
        a.niveau = a.niveau + 1
        a.recette, a.revele = {}, false
        verbe, titre = R.T("séquelle aggravée"), R.T("Séquelle aggravée")
    else
        verbe, titre = R.T("séquelle prolongée"), R.T("Séquelle prolongée")
    end
    local jours = math.floor(borne(cfg.seq_jours, 1, 60))
    a.fin = h + jours * 24
    a.depuis = h
    seq_journal(R.fmt("%s : %s (%s), jusqu'au jour %d",
        verbe, R.seq_texte(id), R.T(source or "?"), math.floor(a.fin / 24)))
    seq_sauver()
    seq_annoncer(id, titre .. " : " .. seq_nom_niveau(d, a.niveau),
                 d.effet(a.niveau) .. " — " .. R.fmt("%d jours", jours), false)
    pcall(R.sx_annoncer, id, a.niveau, false)
    return verbe .. " : " .. R.seq_texte(id)
end

-- Liste des séquelles éligibles au tirage (celles cochées dans le menu + condition satisfaite)
local function seq_candidates()
    local l = {}
    for _, d in ipairs(R.SEQ_LIB) do
        if cfg[d.on] ~= false and (not d.condition or d.condition()) then l[#l + 1] = d end
    end
    return l
end
-- Tire n séquelles aléatoires distinctes (si moins de n candidates, tire ce qui est dispo).
function R.seq_tirage(n, source)
    n = math.max(0, math.floor(n or 0))
    if n == 0 then return 0 end
    local l = seq_candidates()
    if #l == 0 then seq_journal(R.T("aucune séquelle activée dans le tirage")); return 0 end
    -- Mélange des candidates (Fisher-Yates)
    for i = #l, 2, -1 do local j = math.random(1, i); l[i], l[j] = l[j], l[i] end
    local n_appliquees = 0
    for i = 1, math.min(n, #l) do
        R.seq_appliquer(l[i].id, source or "Second Breath")
        n_appliquees = n_appliquees + 1
    end
    return n_appliquees
end

-- Guérit une seule séquelle par id (par la voyante, plus tard — cas utile dès maintenant
-- pour les outils de test). `raison` apparaît au journal.
function R.seq_guerir(id, raison)
    if not R.seq.actives[id] then return end
    local t = R.seq_texte(id)
    R.seq.actives[id] = nil
    seq_journal(R.fmt("guérison : %s (%s)", t, R.T(raison or "?")))
    seq_sauver()
    local nom = R.SEQ_PAR_ID[id] and R.T(R.SEQ_PAR_ID[id].nom) or id
    seq_annoncer(id, R.T("Guéri : ") .. nom, "", false)
    pcall(R.sx_annoncer, id, 0, false)
end
function R.tr_guerir(id, raison)
    if not R.tr.actives[id] then return end
    local t = R.tr_texte(id)
    R.tr.actives[id] = nil
    tr_journal(R.fmt("guérison : %s (%s)", t, R.T(raison or "?")))
    tr_sauver()
    local nom = R.SEQ_PAR_ID[id] and R.T(R.SEQ_PAR_ID[id].nom) or id
    seq_annoncer(id, R.T("Trauma guéri : ") .. nom, "", true)
    pcall(R.sx_annoncer, id, 0, true)
end

-- Vide toutes les Séquelles (Pierre de faille ou repos à l'auberge).
-- Les Traumatismes sont conservés.
function R.guerir_sequelles(raison)
    local ids = {}
    for id in pairs(R.seq.actives) do ids[#ids + 1] = id end
    if #ids == 0 then return 0 end
    for _, id in ipairs(ids) do
        local nom = R.SEQ_PAR_ID[id] and R.T(R.SEQ_PAR_ID[id].nom) or id
        R.seq.actives[id] = nil
        seq_journal(R.fmt("guérison : %s (%s)", nom, R.T(raison or "?")))
    end
    seq_sauver()
    seq_annoncer("_all", R.T("Séquelles soignées"),
                 R.fmt("%d blessure(s) guérie(s) — %s", #ids, R.T(raison or "?")), false)
    -- v0.66 : annonce chaque guérison individuellement
    for _, id in ipairs(ids) do pcall(R.sx_annoncer, id, 0, false) end
    return #ids
end

-- Guérit tout (outils de test seulement depuis la v0.74 : la voyante ne propose plus de soin gratuit). Séquelles ET Traumatismes.
function R.guerir_tout(raison)
    local ns = R.guerir_sequelles(raison)
    local ids = {}
    for id in pairs(R.tr.actives) do ids[#ids + 1] = id end
    if #ids > 0 then
        for _, id in ipairs(ids) do
            local nom = R.SEQ_PAR_ID[id] and R.T(R.SEQ_PAR_ID[id].nom) or id
            R.tr.actives[id] = nil
            tr_journal(R.fmt("guérison : %s (%s)", nom, R.T(raison or "?")))
        end
        tr_sauver()
        seq_annoncer("_tr_all", R.T("Traumatismes soignés"),
                     R.fmt("%d blessure(s) guérie(s) — %s", #ids, R.T(raison or "?")), true)
        -- v0.66 : annonce chaque guérison de trauma individuellement
        for _, id in ipairs(ids) do pcall(R.sx_annoncer, id, 0, true) end
    end
    return ns + #ids
end

-- Transforme TOUTES les Séquelles existantes en Traumatismes (conserve rang).
-- Cette fonction est appelée AU MOMENT d'un nouveau Second Breath, AVANT que les
-- nouvelles Séquelles soient tirées : règle de la spec v0.48 §5.
function R.transformer_sequelles_en_traumas()
    local ids = {}
    for id in pairs(R.seq.actives) do ids[#ids + 1] = id end
    if #ids == 0 then return 0 end
    for _, id in ipairs(ids) do
        local a = R.seq.actives[id]
        local nom = R.SEQ_PAR_ID[id] and R.T(R.SEQ_PAR_ID[id].nom) or id
        -- Si la même séquelle existe déjà en trauma, on garde le rang le plus sévère
        local prev = R.tr.actives[id]
        local nv = (prev and math.max(prev.niveau or 1, a.niveau or 1)) or a.niveau or 1
        R.tr.actives[id] = { niveau = nv, depuis = a.depuis, recette = {}, revele = false }
        R.seq.actives[id] = nil
        tr_journal(R.fmt("Séquelle devenue Traumatisme : %s (rang %d)", nom, nv))
    end
    seq_sauver()
    tr_sauver()
    -- v0.66 : annonce chaque traumatisme individuellement (file d'attente)
    for _, id in ipairs(ids) do
        local nv = R.tr.actives[id] and R.tr.actives[id].niveau or 1
        pcall(R.sx_annoncer, id, nv, true)
    end
    return #ids
end

-- Expiration naturelle : vérifie toutes les 5 s si une séquelle a dépassé sa
-- date de fin (cfg.seq_jours jours de jeu depuis sa création ou son aggravation).
-- Les Traumatismes n'expirent jamais naturellement.
R.seq_t = -1e9
function R.seq_tick()
    local now = os.clock()
    if now - R.seq_t < 5 then return end
    R.seq_t = now
    local h = R.heure_jeu()
    if not h then return end
    for id, a in pairs(R.seq.actives) do
        if tonumber(a.fin) and h >= a.fin then R.seq_guerir(id, "durée écoulée") end
    end
end

-- Interface pour les autres mods (lecture seule)
api.get_sequelles = function() return R.seq.actives end
api.get_traumas   = function() return R.tr.actives end
api.seq_rang      = function(id) return R.effet_niveau(id) end

-- ============================================================================
-- v0.48 / v0.63 — HUD Séquelles / Traumatismes
-- 1) Barre d'icônes en jeu (hors pause)
-- 2) Annonce au centre-haut (d2d.text, Palatino Linotype, fond aux bords adoucis)
-- 3) Panneau de détail au menu pause (icônes, noms, effets, jours, remèdes)
-- v0.63 : port intégral de l'interface de BardN_New_Death_System.
-- ============================================================================

-- Chargement paresseux des icônes d2d (une seule tentative par id).
R.sx_icones = {}
local function sx_icone(id)
    local im = R.sx_icones[id]
    if im == nil then
        local ok, img = pcall(function()
            return d2d.Image.new("BardN_ShardsOfLife/" .. id .. ".png")
        end)
        im = (ok and img) or false
        R.sx_icones[id] = im
    end
    return im or nil
end
local function sx_fond_img(cle, fichier)
    if R.sx_icones[cle] == nil then
        local ok, img = pcall(function()
            return d2d.Image.new("BardN_ShardsOfLife/" .. fichier)
        end)
        R.sx_icones[cle] = (ok and img) or false
    end
    return R.sx_icones[cle] or nil
end

local function sx_alpha(c, a)
    local al = math.floor(((c >> 24) & 0xFF) * math.max(0, math.min(1, a)))
    return (al << 24) | (c & 0x00FFFFFF)
end

local SX_ROM = { "I", "II", "III", "IV", "V" }

-- Annonce d'une nouvelle séquelle / trauma : FILE D'ATTENTE.
-- v0.64 : les annonces s'enchaînent une par une avec 1,5 s de pause entre chaque.
-- R.sx_annonce = l'annonce en cours d'affichage (nil = rien à l'écran).
-- R.sx_file = les annonces en attente (FIFO).
R.sx_annonce = nil
R.sx_file = {}
R.sx_annonces = {}   -- gardé pour compatibilité
R.sx_pause_fin = 0       -- os.clock() de fin de la pause en cours
function R.sx_annoncer(id, rang, est_trauma)
    local t = R.T
    local seq_d = R.SEQ_PAR_ID and R.SEQ_PAR_ID[id]
    local nom = seq_d and t(seq_d.nom) or id
    local guerison = rang == 0 or rang == nil
    local titre, ligne
    if guerison then
        titre = t("Guérie") .. " : " .. nom
        ligne = ""
    else
        local lib = est_trauma and t("Traumatisme") or t("Séquelle")
        titre = lib .. " : " .. nom .. " " .. (SX_ROM[rang] or tostring(rang))
        ligne = ""
        if seq_d and seq_d.effet then
            local ok_e, eff = pcall(seq_d.effet, rang)
            if ok_e and eff then ligne = t(eff) end
        end
    end
    local entry = { id = id, titre = titre, ligne = ligne, trauma = est_trauma }
    -- Si rien n'est affiché et pas en pause entre deux annonces, afficher tout de suite.
    if R.sx_annonce == nil and os.clock() >= R.sx_pause_fin then
        entry.debut = os.clock()
        entry.fin   = os.clock() + borne(tonumber(cfg.sx_annonce_duree) or 8, 2, 30)
        R.sx_annonce = entry
    else
        -- Sinon, mettre en file d'attente.
        R.sx_file[#R.sx_file + 1] = entry
    end
end
-- Appelé à chaque image dans le callback d2d : passe à l'annonce suivante quand la précédente expire.
local function sx_file_tick()
    local now = os.clock()
    if R.sx_annonce then
        if now > R.sx_annonce.fin then
            R.sx_annonce = nil
            R.sx_pause_fin = now + borne(tonumber(cfg.sx_annonce_pause) or 1.5, 0.5, 5.0)
        end
    elseif #R.sx_file > 0 and now >= R.sx_pause_fin then
        local entry = table.remove(R.sx_file, 1)
        entry.debut = now
        entry.fin   = now + borne(tonumber(cfg.sx_annonce_duree) or 8, 2, 30)
        R.sx_annonce = entry
    end
end

-- ---------------------------------------------------------------------------
-- Polices Palatino Linotype (d2d) — créées une seule fois au démarrage.
-- ---------------------------------------------------------------------------
R.d2d_ok = false
R.sx_fp_t, R.sx_fp_d = nil, nil   -- tables indexées par taille [8..60]
R.sx_font_g, R.sx_font_p = nil, nil
local SX_POLICE_MIN, SX_POLICE_MAX = 8, 60
local function sx_police(liste_f, taille)
    if not liste_f then return nil end
    return liste_f[math.floor(borne(taille + 0.5, SX_POLICE_MIN, SX_POLICE_MAX))]
end
local function sx_mesure(font, t, defaut)
    local ok, w = pcall(function() return font:measure(t) end)
    if ok and tonumber(w) then return tonumber(w) end
    return #t * (defaut or 8)
end

-- Fond aux bords adoucis : 5 rectangles superposés (opacités additives → dégradé doux au bord).
local function sx_fond_doux(x, y, lg, ht, doux, rayon, c)
    local a = (c >> 24) & 0xFF
    if a <= 0 then return end
    local n = 5
    local ac = math.floor(255 * (1 - (1 - a / 255) ^ (1 / n)))
    local cc = (ac << 24) | (c & 0x00FFFFFF)
    for k = n - 1, 0, -1 do
        local e = doux * k / (n - 1)
        if d2d.fill_rounded_rect then
            pcall(d2d.fill_rounded_rect, x - e, y - e, lg + e * 2, ht + e * 2, rayon + e, rayon + e, cc)
        else
            pcall(d2d.fill_rect, x - e, y - e, lg + e * 2, ht + e * 2, cc)
        end
    end
end

-- ---------------------------------------------------------------------------
-- Visibilité : en jeu seulement (joueur présent, heure > 0, pas pendant la mort).
-- ---------------------------------------------------------------------------
R.sx_vis_t, R.sx_vis = -1e9, { jeu = false, pause = false }
local function sx_maj_visibilite()
    local now = os.clock()
    if now - R.sx_vis_t < 0.1 then return R.sx_vis end
    R.sx_vis_t = now
    local en_jeu = joueur() ~= nil
    local pause = false
    pcall(function() pause = sdk.get_managed_singleton("app.PauseManager"):call("isPausedAny()") == true end)
    R.sx_vis = { jeu = en_jeu, pause = pause }
    return R.sx_vis
end

-- ---------------------------------------------------------------------------
-- Détection de l'écran principal du menu pause (re.on_pre_gui_draw_element).
-- Le panneau de détail ne s'affiche que sur l'écran principal (pas sur Objets,
-- Carte, Missions, etc.). Même mécanique que BardN_New_Death_System.
-- ---------------------------------------------------------------------------
R.sx_gui_img, R.sx_gui_cadre, R.sx_gui_noms, R.sx_gui_t = 0, {}, {}, -1e9
R.sx_ecran_racine = nil   -- nil = rien relevé ; true = écran principal ; false = autre
R.sx_ecran_intrus = nil
R.SX_ECRAN_SIGNATURE = { "ui060101", "ui010901_00" }
local function sx_sous_menu(n)
    if n == "ui060101" then return false end
    return n:sub(1, 4) == "ui06" or n:sub(1, 8) == "ui040205" or n == "ui010101" or n == "ui01360601" or n == "ui010301_00"
end
local function sx_ecran_du_jeu(n) return type(n) == "string" and n:match("^ui%d") ~= nil end
if re.on_pre_gui_draw_element then
    re.on_pre_gui_draw_element(function(el)
        if not (R.sx_vis and R.sx_vis.pause) then return true end
        local ok, adr = pcall(function() return el:get_address() end)
        if not ok or not adr then return true end
        local n = R.sx_gui_noms[adr]
        if n == nil then
            local okn, nom = pcall(function() return el:call("get_GameObject"):call("get_Name") end)
            n = (okn and type(nom) == "string" and nom ~= "") and nom or false
            R.sx_gui_noms[adr] = n
        end
        if n then R.sx_gui_cadre[n] = R.sx_gui_img end
        return true
    end)
end
local function sx_racine_maj()
    R.sx_gui_img = R.sx_gui_img + 1
    if not (R.sx_vis and R.sx_vis.pause) then
        R.sx_ecran_racine, R.sx_ecran_intrus = nil, nil
        if next(R.sx_gui_noms) ~= nil then R.sx_gui_noms, R.sx_gui_cadre = {}, {} end
        return
    end
    local now = os.clock()
    if now - R.sx_gui_t < 0.1 then return end
    R.sx_gui_t = now
    local jeu, ici = 0, {}
    for n, t in pairs(R.sx_gui_cadre) do
        if t >= R.sx_gui_img - 3 and sx_ecran_du_jeu(n) then jeu = jeu + 1; ici[n] = true end
    end
    if jeu == 0 then R.sx_ecran_racine, R.sx_ecran_intrus = nil, nil; return end
    local intrus = nil
    for _, n in ipairs(R.SX_ECRAN_SIGNATURE) do
        if not ici[n] then intrus = R.fmt("%s absent", n); break end
    end
    if not intrus then
        for n in pairs(ici) do
            if sx_sous_menu(n) then intrus = n; break end
        end
    end
    R.sx_ecran_intrus = intrus
    R.sx_ecran_racine = (intrus == nil)
end

-- ---------------------------------------------------------------------------
-- Panneau de détail (menu pause) — porté de BardN_New_Death_System.
-- ---------------------------------------------------------------------------
R.det_apercu = false
R.det_rect = nil
R.det_alpha, R.det_t, R.det_debut = 0, nil, nil

local function det_mesures()
    local e = borne(cfg.det_echelle, 30, 300) / 100
    local ei, et = e * borne(cfg.det_icone, 30, 300) / 100, e * borne(cfg.det_texte, 30, 300) / 100
    local pt, pd = 21 * et, 15 * et
    return { ic = math.floor(52 * ei + 0.5), pad = math.floor(12 * e + 0.5), gap = math.floor(10 * e + 0.5),
             esp = math.floor(borne(cfg.det_espace, 0, 60) * e + 0.5),
             lt = math.floor(pt * 1.33 + 0.5), ld = math.floor(pd * 1.45 + 0.5), pt = pt, pd = pd }
end

local function det_lignes(hj)
    local l = {}
    local seq_a = R.seq and R.seq.actives or {}
    local tr_a  = R.tr  and R.tr.actives  or {}
    for _, d in ipairs(R.SEQ_LIB) do
        local a = seq_a[d.id]
        local at = tr_a[d.id]
        if a then l[#l + 1] = { d = d, a = a, trauma = false }
        elseif at then l[#l + 1] = { d = d, a = at, trauma = true } end
    end
    if #l == 0 and R.det_apercu then
        for i, d in ipairs(R.SEQ_LIB) do
            l[#l + 1] = { d = d, a = { niveau = 1, fin = (hj or 0) + 7 * 24, revele = i == 1,
                                        recette = { { id = 184, n = 2 }, { id = 41, n = 1 } } }, trauma = false, exemple = true }
        end
    end
    return l
end

local function det_recette_txt(recette)
    if type(recette) ~= "table" then return "?" end
    local parts = {}
    for _, r in ipairs(recette) do
        local nom = R.VOY_NOM and R.VOY_NOM[r.id] or tostring(r.id)
        parts[#parts + 1] = R.fmt("%d× %s", r.n or 1, nom)
    end
    return table.concat(parts, ", ")
end

local function dessiner_panneau(w, h, hj, al)
    local sc = det_mesures()
    local ft = sx_police(R.sx_fp_t, sc.pt)
    local fd = sx_police(R.sx_fp_d, sc.pd)
    al = al * borne(cfg.det_opacite, 0.05, 1)
    local lignes = det_lignes(hj)
    if #lignes == 0 and not cfg.det_vide then R.det_rect = nil; return end
    local larg_txt = 0
    for _, x in ipairs(lignes) do
        x.t1 = R.seq_nom_niveau(x.d, x.a.niveau or 1)
        if x.trauma then x.t1 = R.T("Traumatisme") .. " — " .. x.t1 end
        local j = (cfg.det_jours and hj and hj > 0 and tonumber(x.a.fin) and not x.trauma) and math.ceil(math.max(0, x.a.fin - hj) / 24) or nil
        local ok_e, eff = pcall(x.d.effet, x.a.niveau or 1)
        x.t2 = (ok_e and eff or "?") .. (j and ("  —  " .. R.fmt("encore %d j", j)) or "")
        x.t3 = nil
        if cfg.det_remede and cfg.voy_actif and x.trauma then   -- v0.74 : la voyante ne soigne que les traumatismes
            x.t3 = (x.a.revele and type(x.a.recette) == "table") and (R.T("Remède : ") .. det_recette_txt(x.a.recette))
                   or R.T("Remède : à demander à une voyante")
        end
        x.hl = math.max(sc.ic, sc.lt + sc.ld * (x.t3 and 2 or 1))
        if ft then larg_txt = math.max(larg_txt, sx_mesure(ft, x.t1, 11)) end
        if fd then larg_txt = math.max(larg_txt, sx_mesure(fd, x.t2, 7)) end
        if fd and x.t3 then larg_txt = math.max(larg_txt, sx_mesure(fd, x.t3, 7)) end
    end
    local entete_h = cfg.det_entete and (sc.lt + 10) or 0
    local larg = sc.pad * 2 + (#lignes > 0 and (sc.ic + sc.gap) or 0) + math.max(larg_txt, 120 * sc.pt / 21)
    local h_lignes = 0
    for _, x in ipairs(lignes) do h_lignes = h_lignes + x.hl + sc.esp end
    local haut = sc.pad * 2 + entete_h + (#lignes > 0 and (h_lignes - sc.esp) or sc.ld)
    local x0 = math.max(0, math.min(w * cfg.det_x, w - larg))
    local y0 = math.max(0, math.min(h * cfg.det_y, h - haut))
    local c_titre = sx_alpha(tonumber(cfg.det_titre_couleur) or 0xFFE8DCC8, al)
    local c_texte = sx_alpha(tonumber(cfg.det_texte_couleur) or 0xFFB8A890, al)
    if cfg.det_fond then pcall(d2d.fill_rect, x0, y0, larg, haut, sx_alpha(tonumber(cfg.det_fond_couleur) or 0xC0080808, al)) end
    if al >= 1 and (R.sx_drag or R.sx_det_survol) then pcall(d2d.outline_rect, x0, y0, larg, haut, 2, R.sx_drag and 0xFFFFFF80 or 0x80FFFFFF) end
    local y = y0 + sc.pad
    if cfg.det_entete and ft then
        d2d.text(ft, R.T("Séquelles"), x0 + sc.pad, y, c_titre)
        pcall(d2d.fill_rect, x0 + sc.pad, y + sc.lt + 2, larg - sc.pad * 2, 1, sx_alpha(tonumber(cfg.det_texte_couleur) or 0xFFB8A890, 0.6 * al))
        y = y + entete_h
    end
    if #lignes == 0 then
        if fd then d2d.text(fd, R.T("Aucune séquelle"), x0 + sc.pad, y, c_texte) end
    end
    local c_remede = sx_alpha(tonumber(cfg.det_texte_couleur) or 0xFFB8A890, 0.75 * al)
    local c_seq_pause = sx_alpha(tonumber(cfg.det_seq_couleur) or 0xFFAA9B70, al)
    local c_tr_pause  = sx_alpha(tonumber(cfg.det_tr_couleur)  or 0xFF964B3C, al)
    for _, x in ipairs(lignes) do
        local img = sx_icone(x.d.id)
        local xx = x0 + sc.pad
        local hl = x.hl
        local yt = y + math.max(0, (hl - sc.lt - sc.ld * (x.t3 and 2 or 1)) / 2)
        if img then d2d.image(img, xx, y + (hl - sc.ic) / 2, sc.ic, sc.ic, (x.exemple and 0.5 or 1) * al) end
        -- v0.69 : titres du panneau pause = couleurs propres au panneau (Séquelle / Traumatisme)
        if ft then d2d.text(ft, x.t1, xx + sc.ic + sc.gap, yt, x.trauma and c_tr_pause or c_seq_pause) end
        if fd then d2d.text(fd, x.t2, xx + sc.ic + sc.gap, yt + sc.lt, c_texte) end
        if fd and x.t3 then d2d.text(fd, x.t3, xx + sc.ic + sc.gap, yt + sc.lt + sc.ld, c_remede) end
        y = y + hl + sc.esp
    end
    R.det_rect = (al >= 1) and { x0 = x0 / w, y0 = y0 / h, x1 = (x0 + larg) / w, y1 = (y0 + haut) / h } or nil
end

local function det_panneau_alpha(voulu)
    local now = os.clock()
    local dt = R.det_t and math.min(0.1, math.max(0, now - R.det_t)) or 0
    R.det_t = now
    if R.det_apercu then R.det_debut = nil; R.det_alpha = 1; return 1 end
    local cible = 0
    if voulu then
        R.det_debut = R.det_debut or now
        if now - R.det_debut >= (tonumber(cfg.det_delai) or 0) then cible = 1 end
    else
        R.det_debut = nil
    end
    local a = R.det_alpha
    if cible > a then
        local d = tonumber(cfg.det_fondu_in) or 0
        a = d <= 0 and 1 or math.min(1, a + dt / d)
    elseif cible < a then
        local d = tonumber(cfg.det_fondu_out) or 0
        a = d <= 0 and 0 or math.max(0, a - dt / d)
    end
    R.det_alpha = a
    return a
end

-- ---------------------------------------------------------------------------
-- Souris : cliquer-glisser le panneau (menu pause ou aperçu).
-- ---------------------------------------------------------------------------
R.sx_drag = nil
R.sx_det_survol = false
local function sx_souris_panneau()
    if not cfg.det_souris then return end
    local r = R.det_rect
    if not r then R.sx_det_survol = false; return end
    local ok_m, mx, my = pcall(function()
        local sz = imgui.get_display_size()
        local p = imgui.get_mouse_pos()
        return p.x / sz.x, p.y / sz.y
    end)
    if not ok_m then R.sx_det_survol = false; return end
    R.sx_det_survol = mx >= r.x0 and mx <= r.x1 and my >= r.y0 and my <= r.y1
    if R.sx_drag then
        if imgui.is_mouse_down(0) then
            cfg.det_x = borne(mx - R.sx_drag.dx, 0, 0.98)
            cfg.det_y = borne(my - R.sx_drag.dy, 0, 0.98)
        else
            R.sx_drag = nil; sauver()
        end
    elseif R.sx_det_survol and imgui.is_mouse_clicked(0) then
        R.sx_drag = { dx = mx - r.x0, dy = my - r.y0 }
    end
end

-- ---------------------------------------------------------------------------
-- d2d.register : point d'entrée unique pour le dessin d2d (polices, barre, panneau, annonce).
-- ---------------------------------------------------------------------------
if type(d2d) == "table" and d2d.register then
    pcall(function()
        d2d.register(function()
            -- Création des polices Palatino Linotype (une seule fois)
            R.sx_font_g = d2d.Font.new("Palatino Linotype", 24, true)
            R.sx_font_p = d2d.Font.new("Palatino Linotype", 15)
            R.sx_fp_t, R.sx_fp_d = {}, {}
            for t = SX_POLICE_MIN, SX_POLICE_MAX do
                R.sx_fp_t[t] = d2d.Font.new("Palatino Linotype", t, true)
                R.sx_fp_d[t] = d2d.Font.new("Palatino Linotype", t)
            end
        end, function()
            local ok, motif = pcall(function()
                if not cfg.sx_actif then return end
                local w, h = d2d.surface_size()
                local vis = sx_maj_visibilite()
                pcall(sx_racine_maj)

                local hj = nil
                pcall(function()
                    local tm = sdk.get_managed_singleton("app.TimeManager")
                    hj = tm and tm:get_field("_InGameDays")
                end)

                local al = math.max(0, math.min(1, tonumber(cfg.sx_opacite) or 0.6))
                if al <= 0.01 then return end

                -- 1) panneau de détail : menu pause (ou aperçu)
                local voulu = cfg.det_actif and ((vis.jeu and vis.pause and R.sx_ecran_racine == true) or (R.det_apercu and joueur() ~= nil))
                local pal = det_panneau_alpha(voulu)
                if pal > 0 then dessiner_panneau(w, h, hj, pal) else R.det_rect = nil end
                pcall(sx_souris_panneau)

                -- 2) barre d'icônes (en jeu, hors pause)
                -- 2) barre d'icônes (en jeu, hors pause) — v0.66 : deux lignes (traumas au-dessus, séquelles en dessous)
                -- v0.70 : visibilité pilotée par HUD Controls (élément « Séquelles et Traumatismes »)
                local hc_barre = (vis.jeu and not vis.pause and not R.det_apercu and R.det_alpha <= 0) and R.hcs_alpha() or 0
                if hc_barre > 0.01 then
                    local al = al * hc_barre
                    local seq_a = R.seq and R.seq.actives or {}
                    local tr_a  = R.tr  and R.tr.actives  or {}
                    local l_seq, l_tr = {}, {}
                    for id, s in pairs(seq_a) do
                        if not tr_a[id] then
                            l_seq[#l_seq + 1] = { id = id, rang = s.rang, jours = s.jours }
                        end
                    end
                    for id, t in pairs(tr_a) do
                        l_tr[#l_tr + 1] = { id = id, rang = t.rang }
                    end
                    table.sort(l_seq, function(a, b) return a.id < b.id end)
                    table.sort(l_tr,  function(a, b) return a.id < b.id end)
                    if #l_seq > 0 or #l_tr > 0 then
                        local t_ic = math.max(16, math.floor(tonumber(cfg.sx_taille) or 44))
                        local gap  = math.max(0, math.floor(tonumber(cfg.sx_ecart) or 6))
                        local x0   = math.floor(w * (tonumber(cfg.sx_x) or 0.015))
                        local y0   = math.floor(h * (tonumber(cfg.sx_y) or 0.926))
                        local c_seq = tonumber(cfg.sx_couleur)    or 0xFFAA9B70
                        local c_tr  = tonumber(cfg.sx_couleur_tr) or 0xFF964B3C
                        local kt = borne(tonumber(cfg.sx_texte) or 100, 50, 300) / 100
                        local fb = sx_police(R.sx_fp_d, 15 * kt) or R.sx_font_p
                        -- Ligne du bas : séquelles (à la position y0)
                        local y_seq = y0
                        for i, e in ipairs(l_seq) do
                            local im = sx_icone(e.id)
                            local xx = x0 + (i - 1) * (t_ic + gap)
                            if im then pcall(d2d.image, im, xx, y_seq, t_ic, t_ic, al) end
                            if e.rang and e.rang > 1 and fb then
                                d2d.text(fb, SX_ROM[e.rang] or tostring(e.rang), xx + t_ic - 16 * kt, y_seq - 2, sx_alpha(0xFFE05A4A, al))
                            end
                            if cfg.sx_jours and e.jours and e.jours > 0 and fb then
                                d2d.text(fb, tostring(e.jours) .. "j", xx + 4, y_seq + t_ic, sx_alpha(c_seq, al * 0.75))
                            end
                        end
                        -- Ligne du haut : traumatismes (au-dessus, décalés de t_ic + écart + label)
                        if #l_tr > 0 then
                            -- v0.70 : le label « Traumatismes » respecte enfin l'option sx_libelle_tr
                            local lib_tr = fb and cfg.sx_libelle_tr ~= false
                            local y_tr = y_seq - t_ic - gap - (lib_tr and 18 or 0)
                            if lib_tr then d2d.text(fb, R.T("Traumatismes"), x0, y_tr - 2, sx_alpha(c_tr, al)) end
                            local y_tr_ic = y_tr + (lib_tr and 16 or 0)
                            for i, e in ipairs(l_tr) do
                                local im = sx_icone(e.id)
                                local xx = x0 + (i - 1) * (t_ic + gap)
                                local fi = sx_fond_img("_fond_tr", "fond_trauma.png")
                                if fi then
                                    local mg = math.floor(t_ic * 0.12)
                                    local fw = t_ic - mg * 2
                                    local fh = math.floor(fw * 0.55)
                                    pcall(d2d.image, fi, xx + mg, y_tr_ic + math.floor((t_ic - fh) * 0.5), fw, fh, al * 0.9)
                                end
                                if im then pcall(d2d.image, im, xx, y_tr_ic, t_ic, t_ic, al) end
                                if e.rang and e.rang > 1 and fb then
                                    d2d.text(fb, SX_ROM[e.rang] or tostring(e.rang), xx + t_ic - 16 * kt, y_tr_ic - 2, sx_alpha(0xFFE05A4A, al))
                                end
                            end
                        end
                    end
                end

                -- 3) annonce centre-haut (d2d.text, Palatino Linotype) — file d'attente v0.64
                pcall(sx_file_tick)
                local an = R.sx_annonce
                if an and cfg.sx_annonce and vis.jeu then
                    local now = os.clock()
                    if now > an.fin then pcall(sx_file_tick); an = R.sx_annonce end
                    if an and now <= an.fin then
                        local fade_al = math.min(1, (now - an.debut) / 0.4, (an.fin - now) / 0.8)
                        local t_an = math.floor(tonumber(cfg.sx_annonce_taille) or 133)
                        local cx, ay = w / 2, h * (tonumber(cfg.sx_annonce_y) or 0.16)
                        local img = an.id and sx_icone(an.id)
                        local ka = borne(tonumber(cfg.sx_annonce_texte) or 100, 50, 250) / 100
                        local ft = sx_police(R.sx_fp_t, 24 * ka) or R.sx_font_g
                        local fl = sx_police(R.sx_fp_d, 15 * ka) or R.sx_font_p
                        local tw = ft and sx_mesure(ft, an.titre, 11 * ka) or 0
                        local avec_ligne = fl and an.ligne ~= ""
                        local lw = avec_ligne and sx_mesure(fl, an.ligne, 7 * ka) or 0
                        -- v0.65 : fond = image de fumée (fond_annonce.png), réglable en taille, position et opacité
                        local fa = borne(tonumber(cfg.sx_annonce_fond_opacite) or 55, 0, 100) / 100
                        if cfg.sx_annonce_fond and fa > 0 then
                            local fi = sx_fond_img("_fond_an", "fond_annonce.png")
                            if fi then
                                local bloc_w = math.max(t_an, tw, lw) + math.floor(36 * ka)
                                local bloc_h = t_an + 6 + math.floor(32 * ka) + (avec_ligne and math.floor(24 * ka) or 0) + math.floor(36 * ka)
                                local fech = borne(tonumber(cfg.sx_annonce_fond_echelle) or 120, 50, 400) / 100
                                local fw = math.floor(bloc_w * fech)
                                local fh = math.floor(bloc_h * fech)
                                local fdy = math.floor(tonumber(cfg.sx_annonce_fond_dy) or 0)
                                local fx = math.floor(cx - fw / 2)
                                local fy = math.floor(ay + (bloc_h - fh) / 2 + fdy)
                                pcall(d2d.image, fi, fx, fy, fw, fh, fa * fade_al)
                            else
                                -- repli rectangle si l'image est introuvable
                                local pad = math.floor(18 * ka)
                                local bas = ay + t_an + 6 + math.floor(32 * ka) + (avec_ligne and math.floor(24 * ka) or 0)
                                local lg = math.max(t_an, tw, lw) + pad * 2
                                sx_fond_doux(cx - lg / 2, ay - pad, lg, bas - ay + pad * 2, math.floor(16 * ka),
                                             math.floor(14 * ka), sx_alpha(tonumber(cfg.sx_annonce_fond_couleur) or 0xFF0A0806, fa * fade_al))
                            end
                        end
                        if img then d2d.image(img, cx - t_an / 2, ay, t_an, t_an, fade_al) end
                        -- v0.69 : couleur propre à l'annonce (Séquelle ou Traumatisme selon le type)
                        local c_an = an.trauma
                            and (tonumber(cfg.sx_an_couleur_tr) or 0xFF964B3C)
                            or  (tonumber(cfg.sx_an_couleur)    or 0xFFAA9B70)
                        if ft then d2d.text(ft, an.titre, cx - tw / 2, ay + t_an + 6, sx_alpha(c_an, fade_al)) end
                        if avec_ligne then d2d.text(fl, an.ligne, cx - lw / 2, ay + t_an + 6 + math.floor(32 * ka), sx_alpha(0xFFB8A890, fade_al)) end
                    end
                end
            end)
            if not ok then R.d2d_err = (R.d2d_err or 0) + 1; R.d2d_derniere_err = tostring(motif) end
        end)
        R.d2d_ok = true
    end)
end

-- Ancienne fonction conservée pour l'appel dans on_frame (ne fait plus le dessin d2d).
function R.dessiner_panneau_sequelles()
    -- v0.63 : tout le dessin est dans le callback d2d.register ci-dessus.
    -- Cette fonction ne fait plus rien ; elle est gardée pour ne pas casser l'appel dans on_frame.
end

-- ============================================================================
-- v0.48 — VOYANTE (Batch 3)
-- Branché via BardN_Menu (priorité) ou IGO/GuildTalk (repli).
-- v0.74 : la voyante ne soigne QUE les Traumatismes, un à un, contre des ingrédients et de l'or.
-- Les Séquelles guérissent à l'auberge ou à la Pierre de faille.
-- v0.72 : seules les PNJ listées dans cfg.voy_pnj affichent le menu (désignation dans le menu REFramework).
-- ============================================================================

-- Pool de remèdes : consommables ordinaires (herbes, potions, fortifiants, séchés).
-- Données publiques du jeu, noms relevés en français dans la version de l'utilisateur.
R.VOY_POOL = {
    { 184, "Théraplante", 100 }, { 185, "Luisanlune", 400 }, { 186, "Herbonté", 50 }, { 187, "Marématin", 50 },
    { 191, "Fragrancia", 300 }, { 192, "Chardonor", 300 }, { 193, "Feuille de siruplante", 300 },
    { 505, "Luisansol", 200 }, { 510, "Midisol", 600 }, { 512, "Fleur séchée", 10 },
    { 59, "Décoction détoxifiante", 500 }, { 60, "Poudre d'éveil", 400 }, { 61, "Sirop désaltérant", 400 },
    { 62, "Baume réchauffant", 450 }, { 64, "Tonique dégrisant", 450 }, { 65, "Élixir ramollissant", 1000 },
    { 66, "Infusion apaisante", 500 }, { 68, "Philtre desséchant", 200 }, { 69, "Remède dégraissant", 200 },
    { 500, "Potion de salubrité", 250 }, { 708, "Cordial de vigueur", 2000 }, { 974, "Panacée fongique", 3000 },
    { 38, "Fortifiant de fruit", 600 }, { 39, "Fortifiant à la pulpe de fruit", 900 }, { 42, "Fortifiant à la viande", 700 },
    { 43, "Fortifiant à la viande raffiné", 1000 }, { 46, "Fortifiant au caviar", 600 }, { 47, "Fortifiant au caviar raffiné", 900 },
    { 56, "Fortifiant de rustipatate", 550 }, { 57, "Fortifiant de rustipatate cuite", 850 }, { 502, "Fortifiant enrichi", 3000 },
    { 37, "Fruit sec", 350 }, { 41, "Viande séchée", 400 }, { 45, "Poisson séché", 350 }, { 55, "Rustipatate séchée", 400 },
    { 114, "Viande séchée exquise", 600 }, { 115, "Poisson séché exquis", 500 }, { 116, "Rustipatate séchée exquise", 500 },
    { 501, "Fruit sec du nomade", 500 }, { 631, "Viande de lièvre séchée", 1500 },
}
R.VOY_NOM = {}
for _, o in ipairs(R.VOY_POOL) do R.VOY_NOM[o[1]] = o[2] end
R.VOY_NOM_JEU = {}   -- cache des noms en langue du jeu

local function voy_nom(id)
    if cfg.lang == "en" then
        local n = R.VOY_NOM_JEU[id]
        if n == nil then
            n = false
            pcall(function()
                local d = sdk.get_managed_singleton("app.ItemManager"):call("getItemData(System.Int32)", id)
                local v = d and d:call("get_Name()")
                if type(v) == "string" and v ~= "" and not v:find("^Invalid") then n = v end
            end)
            R.VOY_NOM_JEU[id] = n
        end
        if n then return n end
    end
    return R.VOY_NOM[id] or (R.T("objet ") .. tostring(id))
end

local function voy_recette(niveau)
    local n2 = (niveau or 1) >= 2
    local nb   = math.floor(borne(n2 and cfg.voy_n2_ingr or cfg.voy_n1_ingr, 1, 5))
    local qmin = math.floor(borne(n2 and cfg.voy_n2_min or cfg.voy_n1_min, 1, 10))
    local qmax = math.max(qmin, math.floor(borne(n2 and cfg.voy_n2_max or cfg.voy_n1_max, 1, 10)))
    local vmax = tonumber(n2 and cfg.voy_val2 or cfg.voy_val1) or 1000
    local l = {}
    for _, o in ipairs(R.VOY_POOL) do if o[3] <= vmax then l[#l + 1] = o end end
    if #l < nb then
        l = {}
        for _, o in ipairs(R.VOY_POOL) do l[#l + 1] = o end
        table.sort(l, function(x, y) return x[3] < y[3] end)
    end
    local r = {}
    for i = 1, math.min(nb, #l) do
        local j = math.random(i, #l)
        l[i], l[j] = l[j], l[i]
        r[#r + 1] = { id = l[i][1], n = math.random(qmin, qmax) }
    end
    return r
end

local function voy_recette_txt(rec)
    local t = {}
    for _, x in ipairs(rec or {}) do t[#t + 1] = x.n .. "× " .. voy_nom(x.id) end
    return table.concat(t, ", ")
end

local function voy_prix(niveau)
    return math.floor(borne((niveau or 1) >= 2 and cfg.voy_prix_tr2 or cfg.voy_prix_tr1, 0, 100000))
end

R.voy = { talk = nil, source = nil, statut = "non branché", essai = -100, essais = 0, dernier = nil, sauver = false,
          stock = {}, stock_t = -100 }   -- v0.73 : stock = exemplaires en sac des ingrédients, mis en cache (relu chaque seconde)

-- Nombre de voyantes désignées. Sans aucune, rien ne peut être soigné.
function R.voy_nb()
    local n = 0
    for _ in pairs(cfg.voy_pnj or {}) do n = n + 1 end
    return n
end
R.ROUGE_VOY, R.GRIS_VOY, R.CYAN_VOY = 0xFF4040FF, 0xFF909090, 0xFF3399FF   -- v0.72 : AABBGGRR

-- v0.73 : inventaire et or lus comme dans BardN_New_Death_System (getHaveNum / deleteItem, variante app.Character validée
-- par Item Wheel et Item Card ; repli app.CharacterID). Seul le sac de l'Insurgé compte.
-- Le fournisseur du menu ne lit que le stock en cache (R.voy.stock) : aucun accès au jeu pendant la construction du menu.
local function voy_compter(id)
    local im, p = sdk.get_managed_singleton("app.ItemManager"), joueur()
    if not (im and p) then return nil end
    local ok, n = pcall(function() return im:call("getHaveNum(System.Int32, app.Character)", id, p) end)
    if ok and tonumber(n) then return math.floor(tonumber(n)) end
    ok, n = pcall(function() return im:call("getHaveNum(System.Int32, app.CharacterID)", id, p:get_CharaID()) end)
    if ok and tonumber(n) then return math.floor(tonumber(n)) end
    return nil
end

local function voy_retirer(id, n)
    local im, p = sdk.get_managed_singleton("app.ItemManager"), joueur()
    if not (im and p) then return false end
    local avant = voy_compter(id) or 0
    pcall(function() im:call("deleteItem(System.Int32, System.Int32, app.Character)", id, n, p) end)
    local apres = voy_compter(id) or avant
    if apres > avant - n then   -- repli
        local reste = n - (avant - apres)
        pcall(function() im:call("deleteItem(System.Int32, System.Int32, app.CharacterID)", id, reste, p:get_CharaID()) end)
        apres = voy_compter(id) or apres
    end
    R.voy.stock[id] = apres
    return apres <= avant - n
end

function R.voy_or()
    local ok, v = pcall(function() return sdk.get_managed_singleton("app.ItemManager"):get_Version() end)
    return ok and type(v) == "number" and math.floor(v) or nil
end
function R.voy_retirer_or(n)
    return pcall(function() sdk.get_managed_singleton("app.ItemManager"):addVersion(-n, true, true) end)
end

-- Ce qui manque (texte) d'après le stock en cache ; vide = tout est là. Or compris.
local function voy_manque(a)
    local m = {}
    for _, x in ipairs(a.recette or {}) do
        local n = R.voy.stock[x.id] or 0
        if n < x.n then m[#m + 1] = (x.n - n) .. "× " .. voy_nom(x.id) end
    end
    local prix = voy_prix(a.niveau)
    if prix > 0 then
        local o = R.voy_or() or 0
        if o < prix then m[#m + 1] = R.fmt("%d pièces", prix - o) end
    end
    return m
end

-- Relève le stock des ingrédients toutes les secondes (Traumatismes). Tire aussi les remèdes manquants
-- (traumas nés à une résurrection) pour que le stock soit déjà en cache à l'ouverture du menu.
function R.voy_stock_tick()
    local now = os.clock()
    if now - R.voy.stock_t < 1.0 then return end
    R.voy.stock_t = now
    if not cfg.voy_actif then return end
    if next(R.tr.actives) == nil then return end
    local chg = false
    for _, a in pairs(R.tr.actives) do
        if type(a.recette) ~= "table" or #a.recette == 0 then a.recette = voy_recette(a.niveau); a.revele = false; chg = true end
        for _, x in ipairs(a.recette) do R.voy.stock[x.id] = voy_compter(x.id) end
    end
    if chg or R.voy.sauver then R.voy.sauver = false; tr_sauver() end
end

-- Soigne un traumatisme : prend les ingrédients, retire l'or, guérit.
local function voy_soigner(id, source)
    local a = R.tr.actives[id]
    if not a then return false, R.T("Traumatisme introuvable") end
    if type(a.recette) ~= "table" or #a.recette == 0 then a.recette = voy_recette(a.niveau); a.revele = false end
    for _, x in ipairs(a.recette) do R.voy.stock[x.id] = voy_compter(x.id) end   -- relevé frais avant de prendre
    local manque = voy_manque(a)
    if #manque > 0 then return false, R.T("Il te manque : ") .. table.concat(manque, ", ") .. "." end
    local pris = {}
    for _, x in ipairs(a.recette) do
        if voy_retirer(x.id, x.n) then pris[#pris + 1] = x.n .. "× " .. voy_nom(x.id)
        else evenement(R.T("voyante : retrait incomplet de ") .. voy_nom(x.id)) end
    end
    local prix = voy_prix(a.niveau)
    if prix > 0 then R.voy_retirer_or(prix) end
    evenement(R.fmt("voyante (%s) : %s donné%s", R.T(source or "?"), table.concat(pris, ", "),
        prix > 0 and (" + " .. R.fmt("%d pièces", prix)) or ""))
    local nom = R.T(R.SEQ_PAR_ID[id] and R.SEQ_PAR_ID[id].nom or id)
    R.tr_guerir(id, R.T("soignée par la voyante"))
    return true, R.T("Traumatisme guéri : ") .. nom
end

-- Couleur d'une ligne (ABGR des réglages → balise <COLOR RRGGBB> du jeu) ; blanc ou couleurs désactivées = texte normal.
function R.voy_colorer(t, c)
    if not cfg.voy_couleur_on then return t end
    local n = tonumber(c)
    c = n and math.tointeger(n) or 0xFFFFFFFF
    local r, g, b = c & 0xFF, (c >> 8) & 0xFF, (c >> 16) & 0xFF
    if r == 255 and g == 255 and b == 255 then return t end
    return string.format("<COLOR %02X%02X%02X>%s</COLOR>", r, g, b, t)
end

-- Page d'un traumatisme chez la voyante (comme New Death System) :
-- une ligne par ingrédient « n× nom — tu en as N », puis « Donner les ingrédients ».
function R.voy_page(id)
    return function()
        local d, a = R.SEQ_PAR_ID[id], R.tr.actives[id]
        if not (d and a) then return {} end      -- guéri : BardN Menu remonte à la liste
        local out = {}
        for _, x in ipairs(a.recette or {}) do
            local n = R.voy.stock[x.id] or 0
            local t = R.fmt("%d× %s — tu en as %d", x.n, voy_nom(x.id), n)
            out[#out + 1] = { text = R.voy_colorer(t, n >= x.n and cfg.voy_complet or cfg.voy_gris),
                              enabled = cfg.voy_couleur_on or n >= x.n, pick = function() end, stay = true }
        end
        local prix = voy_prix(a.niveau)
        local m = voy_manque(a)
        if #m > 0 then
            out[#out + 1] = { text = R.T("Donner les ingrédients"), gold = prix > 0 and prix or nil, enabled = true,
                ask = { notice = true, text = R.T("Il te manque encore :") .. "\n   " .. table.concat(m, "\n   ") } }
        else
            local l = { R.fmt("Donner à la voyante, pour apaiser %s :", R.seq_nom_niveau(d, a.niveau)) }
            for _, x in ipairs(a.recette or {}) do l[#l + 1] = string.format("   %d× %s", x.n, voy_nom(x.id)) end
            if prix > 0 then l[#l + 1] = "   " .. R.fmt("%d pièces", prix) end
            out[#out + 1] = { text = R.T("Donner les ingrédients"), gold = prix > 0 and prix or nil, enabled = true,
                ask = { text = table.concat(l, "\n"), back = true, yes = function()
                    local ok, msg = voy_soigner(id, R.T("menu de discussion"))
                    if not ok then seq_annoncer(id, R.T("La voyante"), msg, true); return "reopen" end
                end } }
        end
        return out
    end
end

-- Fournisseur de menu : liste les Traumatismes soignables (un par un). Rien pour les Séquelles ni de soin gratuit.
local function voy_fournisseur(type_menu)
    local t = R.voy.talk
    local cid = t and t.lastSpeakerId or nil
    if cid ~= nil then R.voy.dernier = { cid = tostring(cid), nom = t.lastSpeaker, type = type_menu } end
    if not (cfg.voy_actif and cid ~= nil and cfg.voy_pnj[tostring(cid)]) then return {} end

    local n_tr = 0
    for _ in pairs(R.tr.actives) do n_tr = n_tr + 1 end

    if n_tr == 0 then
        return cfg.voy_vide and { { text = R.T("Traumatismes : rien à soigner"), enabled = false } } or {}
    end

    return { { text = R.fmt(R.T("Soigner un traumatisme (%d)"), n_tr), quiet = true, submenu = function()
        local l = {}
        for _, d in ipairs(R.SEQ_LIB) do
            local a = R.tr.actives[d.id]
            if a then
                if type(a.recette) ~= "table" or #a.recette == 0 then a.recette = voy_recette(a.niveau); a.revele = false end
                if not a.revele then a.revele = true; R.voy.sauver = true end   -- le remède est révélé
                local prix = voy_prix(a.niveau)
                l[#l + 1] = {
                    text = R.seq_nom_niveau(d, a.niveau) .. (#voy_manque(a) == 0 and R.T("  — prêt") or ""),
                    gold = prix > 0 and prix or nil,
                    quiet = true,
                    submenu = R.voy_page(d.id)
                }
            end
        end
        return l
    end } }
end

function R.voy_brancher()
    if R.voy.talk ~= nil or R.voy.essais >= 30 then return end
    local now = os.clock()
    if now - R.voy.essai < 2.0 then return end
    R.voy.essai  = now
    R.voy.essais = R.voy.essais + 1
    local t, src
    local o, g = pcall(require, "BardN_Menu")
    if o and type(g) == "table" and type(g.register) == "function" then t, src = g, "BardN Menu" end
    if not t then
        g = package.loaded["BardN/Menu"]
        if type(g) == "table" and type(g.register) == "function" then t, src = g, "BardN Menu" end
    end
    if not t then
        o, g = pcall(require, "IGO/GuildTalk")
        if o and type(g) == "table" and type(g.register) == "function" then t, src = g, "Infamous Guild Overhaul" end
    end
    if not t then
        R.voy.statut = R.T("aucun menu de discussion trouvé (installe BardN Menu ou IGO)")
        return
    end
    R.voy.talk, R.voy.source = t, src
    local nb = 0
    for ty = 0, 60 do
        if ty ~= 4 and ty ~= 41 then
            if pcall(t.register, ty, voy_fournisseur) then nb = nb + 1 end
        end
    end
    R.voy.statut = R.fmt(R.T("branché sur %s (%d types de menus)"), src, nb)
    evenement("VOYANTE : " .. R.voy.statut)
end
pcall(R.voy_brancher)

-- Recette générée à l'initialisation pour les traumatismes déjà actifs sans recette (la voyante les soigne un par un).
do
    local chg = false
    for _, a in pairs(R.tr.actives) do
        if type(a.recette) ~= "table" or #a.recette == 0 then
            a.recette = voy_recette(a.niveau)
            a.revele  = false
            chg = true
        end
    end
    if chg then tr_sauver() end
end


-- ============================================================================
-- v0.48 — EFFETS DES SÉQUELLES (Batch 3)
-- Hooks gameplay indépendants : chaque effet lit R.effet_niveau(id) pour
-- cumuler Séquelles + Traumatismes (l'effet maximal des deux s'applique).
-- ============================================================================

-- Helpers de lecture d'adresse mémoire (pattern public SDK).
local function adr(args, i) local ok, v = pcall(function() return sdk.to_int64(args[i or 2]) & 0x1FFFFFFFFFF end); return ok and v or 0 end

-- Résolution dynamique des adresses du joueur (sans cache global — SoL n'a pas de système d'adresses fixe).
-- hit_joueur() : adresse du HitController de l'Insurgé
-- endu_joueur() : adresse du StaminaManager de l'Insurgé
-- Les pions sont filtrés en comparant l'adresse de l'objet aux membres du groupe.
local function hit_joueur()
    local ok, a = pcall(function() return joueur():get_Hit():get_address() end)
    return ok and a or 0
end
local function endu_joueur()
    local ok, a = pcall(function()
        return joueur():call("get_StaminaManager"):get_address()
    end)
    return ok and a or 0
end
local function joueur_adr()
    local ok, a = pcall(function() return joueur():get_address() end)
    return ok and a or 0
end

-- Facteurs d'effet : nil = séquelle/trauma inactif → aucun coût.
local function eff_soin()
    local n = R.effet_niveau("metabolisme"); if not n then return nil end
    return math.max(0, 100 - (tonumber(cfg[n >= 2 and "met_n2" or "met_n1"]) or 0)) / 100
end
local function eff_endu()
    local n = R.effet_niveau("douleur"); if not n then return nil end
    return 1 + (tonumber(cfg[n >= 2 and "dou_n2" or "dou_n1"]) or 0) / 100
end
local function eff_pv()
    local n = R.effet_niveau("vitalite"); if not n then return nil end
    return 1 + (tonumber(cfg[n >= 2 and "vit_n2" or "vit_n1"]) or 0) / 100
end
local function eff_fragilite()
    local n = R.effet_niveau("fragilite"); if not n then return nil end
    return 1 + (tonumber(cfg[n >= 2 and "fra_n2" or "fra_n1"]) or 0) / 100
end
local function eff_faiblesse()
    local n = R.effet_niveau("faiblesse"); if not n then return nil end
    return math.max(0.05, 1 - (tonumber(cfg[n >= 2 and "fai_n2" or "fai_n1"]) or 0) / 100)
end
local function eff_instabilite()
    local n = R.effet_niveau("instabilite"); if not n then return nil end
    return math.max(1, tonumber(cfg[n >= 2 and "ins_n2" or "ins_n1"]) or 1)
end
local function eff_commotion() return R.effet_niveau("commotion") ~= nil end
local function eff_resurrection() return R.effet_niveau("resurrection") ~= nil end

-- Hook HitController : soins réduits (Métabolisme) + invulnérabilité pendant Second Breath.
do
    local td = sdk.find_type_definition("app.HitController")
    local m_hp  = td and td:get_method("recoverHp")
    local m_dmg = td and td:get_method("damageProc")
    if m_hp then
        pcall(sdk.hook, m_hp, function(args)
            local a = adr(args)
            if a == 0 or a ~= hit_joueur() then return end
            local mult = eff_soin()
            if mult then
                local ok, v = pcall(function() return sdk.to_float(args[3]) end)
                if ok and v and v > 0 then pcall(function() args[3] = sdk.float_to_ptr(v * mult) end) end
            end
        end, nil)
    end
    if m_dmg then
        pcall(sdk.hook, m_dmg, function(args)
            if not R.sv then return end
            local a = adr(args)
            if a == 0 or a ~= hit_joueur() then return end
            return sdk.PreHookResult.SKIP_ORIGINAL
        end, nil)
    end
end

-- Hook StaminaManager : coût d'endurance augmenté (Douleur).
do
    local td = sdk.find_type_definition("app.StaminaManager")
    local m = td and td:get_method("add")
    if m then
        pcall(sdk.hook, m, function(args)
            local mult = eff_endu()
            if not mult then return end
            local a = adr(args)
            if a == 0 or a ~= endu_joueur() then return end
            local ok, v = pcall(function() return sdk.to_float(args[3]) end)
            if ok and v and v < 0 then pcall(function() args[3] = sdk.float_to_ptr(v * mult) end) end
        end, nil)
    end
end

-- Hook PawnOrderController : ordres aux pions bloqués (Commotion).
do
    local td = sdk.find_type_definition("app.PawnOrderController")
    local m = td and td:get_method("tryUpdatePawnOrder")
    if m then
        pcall(sdk.hook, m, function(args)
            if not eff_commotion() then return end
            local o = 0
            pcall(function() o = sdk.to_int64(args[3]) & 0xFFFFFFFF end)
            if o ~= 0 then return sdk.PreHookResult.SKIP_ORIGINAL end
        end, nil)
    end
end

-- Hook InteractiveObject : réanimation des pions bloquée (Lien perdu = Résurrection dans SEQ_LIB).
-- Détecte si l'objet appartient à un pion via <Owner>k__BackingField.
do
    local pion_go, pion_go_t, objet_cache = {}, -1e9, {}
    local function objet_de_pion(a)
        local now = os.clock()
        if now - pion_go_t > 1.0 then
            pion_go_t, pion_go, objet_cache = now, {}, {}
            for _, ch in ipairs(pions()) do
                local ok, g = pcall(function() return ch:call("get_GameObject"):get_address() end)
                if ok and g and g ~= 0 then pion_go[g] = true end
            end
        end
        local c = objet_cache[a]
        if c == nil then
            c = false
            pcall(function()
                local ow = sdk.to_managed_object(a):get_field("<Owner>k__BackingField")
                if ow and pion_go[ow:get_address()] then c = true end
            end)
            objet_cache[a] = c
        end
        return c
    end
    local td = sdk.find_type_definition("app.InteractiveObject")
    local m = td and td:get_method("checkInput(System.UInt32, app.Character)")
    if m then
        local refuser = false
        pcall(sdk.hook, m,
            function(args)
                refuser = false
                if not eff_resurrection() then return end
                local ja = joueur_adr()
                if ja == 0 or adr(args, 4) ~= ja then return end
                local a = adr(args)
                if a ~= 0 and objet_de_pion(a) then
                    refuser = true
                    evenement(R.T("Lien perdu : réanimation d'un pion refusée"))
                end
            end,
            function(r)
                if refuser then refuser = false; return sdk.to_ptr(false) end
                return r
            end)
    end
end

-- Fragilité / Faiblesse / Vitalité (DamageRate, MaxHpDamageRate) et Instabilité (LeanReactionRate).
-- Patron post-hook pour cohabiter avec Custom Difficulty Tweaks (CDT écrit en pré, on applique en post).
do
    local function accrocher_degats(sig, besoin, appliquer)
        local td = sdk.find_type_definition("app.HitController")
        local m = td and td:get_method(sig)
        if not m then return end
        local ctx = nil
        pcall(sdk.hook, m,
            function(args)
                ctx = nil
                if not besoin() then return end
                local a = adr(args)
                if a == 0 then return end
                local ok, di = pcall(function() return sdk.to_managed_object(args[3]) end)
                if ok and di then ctx = { a = a, di = di, hit_j = hit_joueur() } end
            end,
            function(r)
                local c = ctx; ctx = nil
                if c then pcall(appliquer, c.a, c.di, c.hit_j) end
                return r
            end)
    end

    -- Adresse du HitController de l'attaquant (relevé dans app.DamageInfo).
    local function attaquant_hit(di)
        for _, sig in ipairs({ "get_AttackOwnerHitController()", "get_AttackHitController()" }) do
            local ok, h = pcall(function() return di:call(sig) end)
            if ok and h then
                local oka, a = pcall(function() return h:get_address() end)
                if oka and a and a ~= 0 then return a end
            end
        end
        return 0
    end

    accrocher_degats("calcRegionDamageRate",
        function() return R.effet_niveau("vitalite") or R.effet_niveau("fragilite") or R.effet_niveau("faiblesse") end,
        function(a, di, hit_j)
            -- Vitalité : multiplie la part de PV max perdus (MaxHpDamageRate)
            local pv = eff_pv()
            if pv and a == hit_j then
                local m = di:get_field("MaxHpDamageRate")
                if type(m) == "number" and m > 0 then di:set_field("MaxHpDamageRate", m * pv) end
            end
            -- Fragilité / Faiblesse : multiplie les dégâts reçus / infligés
            local subi    = eff_fragilite()
            local inflige = eff_faiblesse()
            if not (subi or inflige) then return end
            local mult
            if subi and a == hit_j then
                mult = subi
            elseif inflige and attaquant_hit(di) == hit_j then
                mult = inflige
            end
            if not mult then return end
            local r = di:get_field("DamageRate")
            if type(r) == "number" and r > 0 then di:set_field("DamageRate", r * mult) end
        end)

    accrocher_degats("calcDamageValue",
        function() return R.effet_niveau("instabilite") end,
        function(a, di, hit_j)
            local mult = eff_instabilite()
            if not mult or a ~= hit_j then return end
            for _, champ in ipairs({ "LeanReactionRate", "BlownReactionRate" }) do
                local r = di:get_field(champ)
                if type(r) == "number" and r > 0 then di:set_field(champ, r * mult) end
            end
        end)
end

-- ============================================================================
-- v0.48 — HOOK PIERRE DE FAILLE (Batch 3)
-- L'interaction avec une Pierre de faille guérit les Séquelles (pas les Traumas).
-- Détection via app.ActionManager.requestActionCore, action "InteractRimStone".
-- ============================================================================
do
    local td = sdk.find_type_definition("app.ActionManager")
    local m = td and td:get_method("requestActionCore")
    if m then
        pcall(sdk.hook, m, function(args)
            if not (cfg.actif and cfg.seq_actif) then return end
            local ok, nom = pcall(function() return sdk.to_managed_object(args[4]):call("ToString()") end)
            if ok and nom == "InteractRimStone" then
                R.guerir_sequelles(R.T("Pierre de faille"))
            end
        end, nil)
    end
end

-- v0.48 : aliases d'adresses utilisés dans les hooks ci-dessus.
-- R.adr_hit, R.adr_endu, R.adr_joueur sont mis à jour par R.imposer().
R.adr_hit    = R.adr_hit    or 0
R.adr_endu   = R.adr_endu   or 0
R.adr_joueur = R.adr_joueur or 0

-- ----------------------------------------------------------------------------
-- Réanimation par le mod (validée en v0.2)
-- ----------------------------------------------------------------------------
-- v0.65 : SECONDE VIE NATIVE — jauge pleine = une Pierre de Réveil.
-- Flux du jeu relevé par la sonde Transpierre (v0.64) :
--   mort → ItemManager.isHave(77) → phase 28 : dialogue natif « Utiliser une Pierre
--   de Réveil ? » → Oui → phases 29, 27 → WakestoneUser.useWakestoneToRevivePlayer
--   → action ReviveFromWakestone (animation, son, lumière) → ReviveFromWakestone.revive
--   → Player.onReviveFromWakestone → WakestoneUser.deleteItem(77) → ItemManager.deleteItem.
-- Le mod fait seulement croire au jeu qu'une Pierre est là (isHave / nombre) et
-- empêche le retrait de l'objet : c'est la jauge qui est consommée à la place.
-- « Non » → phase 40 (menu de chargement) : la seconde vie n'est pas utilisée.
-- ----------------------------------------------------------------------------
R.sv = nil
R.SV_PIERRE = 77
-- v0.48 : Second Breath. Le nombre d'éclats détermine combien de nouvelles Séquelles
-- apparaissent à la résurrection (table 2/1/0). Les anciennes Séquelles — si présentes —
-- deviennent des Traumatismes AVANT que les nouvelles soient tirées (spec §5).
-- 0 éclat : Second Breath indisponible (mort classique, pas de transformation).
R.SB_NOUVELLES = { [0] = 3, [1] = 2, [2] = 1, [3] = 0 }   -- v0.62 : 0 éclat → 3 Séquelles
function R.sb_nouvelles_pour(n)
    local t = R.SB_NOUVELLES
    if t[n] ~= nil then return t[n] end
    if n >= 3 then return 0 end     -- par sécurité si energie_max > 3
    return 2
end
function R.sv_active() return R.sv ~= nil end
function R.sv_armer(source)
    if R.sv or R.st or not (cfg.actif and cfg.seconde_vie and cfg.second_breath) then return end
    -- v0.48 : 1 éclat suffit (au lieu de la jauge pleine).
    -- v0.62 : à 0 éclat, résurrection possible si « sb_zero » est coché — le prix
    -- est alors de 3 Séquelles (table R.SB_NOUVELLES), au lieu d'aucun recours.
    local mini = (cfg.sb_zero == true) and 0 or 1
    if unites < mini then return end
    R.sv = { t = os.clock(), releve = false, eclats_avant = unites }
    evenement(R.fmt("SECOND BREATH : mort avec %d éclat(s) (%s) — proposition de résurrection",
        unites, source))
end
function R.sv_releve()
    local sv = R.sv
    if sv == nil or sv.releve then return end
    sv.releve, sv.t = true, os.clock()
    local n_eclats = sv.eclats_avant or unites
    local n_nouvelles = R.sb_nouvelles_pour(n_eclats)
    -- v0.48 : règle de la spec §5 — on transforme D'ABORD les Séquelles existantes
    -- en Traumatismes, PUIS on consomme les éclats, PUIS on tire les nouvelles Séquelles.
    -- Les nouvelles Séquelles ne peuvent donc jamais être transformées lors de la même mort.
    local n_tr = R.transformer_sequelles_en_traumas()
    changer_unites(-n_eclats, R.fmt("Second Breath (%d éclat(s))", n_eclats))
    local n_seq = R.seq_tirage(n_nouvelles, R.fmt("Second Breath (%d éclat(s))", n_eclats))
    evenement(R.fmt("SECOND BREATH : résurrection (%d éclat(s) consommé(s), %d Séquelle(s) ajoutée(s), %d Trauma(s) nouveau(x))",
        n_eclats, n_seq, n_tr))
    for nom, f in pairs(api.abonnes_seconde_vie) do   -- v0.44 : Ultimate Breath of Life joue sa lumière finale s'il est là
        local ok, err = pcall(f)
        if not ok then evenement("ERREUR abonné seconde vie " .. tostring(nom) .. " : " .. tostring(err)) end
    end
end
-- v0.47 : compatibilité « BardN Death System » (expose _G.BardN_DeathSystem.trigger_death / is_active
-- et nous laisse la place quand api.respawn_differer() répond vrai) — remplace BardN Death System
-- v0.48 : Second Breath est proposé dès 1 éclat → BardN Death System défère si cfg.second_breath est coché.
api.respawn_differer = function()
    return cfg.respawn_compat == true and cfg.actif == true and cfg.seconde_vie == true
        and cfg.second_breath == true
        and unites >= ((cfg.sb_zero == true) and 0 or 1)
end
function R.respawn_present()
    local d = _G.BardN_DeathSystem   -- v0.47 : BardN Death System remplace BardN Death System
    return type(d) == "table" and type(d.trigger_death) == "function"
end
-- v0.47 : BardN Death System nous laisse gérer les « Non » (il ne réécrit pas la phase 40 lui-même)
api.ds_compat = function() return cfg.respawn_compat == true and cfg.actif == true end
function R.respawn_dispo() return cfg.respawn_compat == true and R.respawn_present() end
function R.respawn_planifier()
    R.resp_t = os.clock() + 0.3
end
-- v0.36 : diagnostic des blocages (compte, date, état du jeu au 1er blocage tardif)
function R.dump_champs(obj, etiq)
    if obj == nil then return end
    pcall(function()
        local td = obj:get_type_definition()
        local out = {}
        for _, f in ipairs(td:get_fields()) do
            if not f:is_static() then
                local okv, v = pcall(function() return f:get_data(obj) end)
                local t = type(v)
                if okv and (t == "number" or t == "boolean" or t == "string") then out[#out + 1] = f:get_name() .. "=" .. tostring(v) end
            end
            if #out >= 45 then break end
        end
        evenement(etiq .. " : " .. table.concat(out, ", "))
    end)
end
function R.resp_note(genre)
    local now = os.clock()
    R.resp_cnt = R.resp_cnt or {}
    local c = R.resp_cnt[genre] or { n = 0, t0 = now, tlog = -1000 }
    R.resp_cnt[genre] = c
    c.n = c.n + 1
    local ecoule = R.resp_post and (now - R.resp_post) or 0
    if now - c.tlog >= 30 then
        c.tlog = now
        local mort = appeler(joueur(), "get_IsDead")
        evenement(R.fmt("RESPAWN : blocage %s n°%d, %.0f s après le respawn (joueur mort : %s)", genre, c.n, ecoule, tostring(mort)))
        if ecoule > 10 and not R.resp_dump then
            R.resp_dump = true
            R.dump_champs(sdk.get_managed_singleton("app.MainFlowManager"), "RESPAWN : champs MainFlowManager")
            R.dump_champs(R.wk_user, "RESPAWN : champs WakestoneUser")
            R.dump_champs(sdk.get_managed_singleton("app.GuiManager"), "RESPAWN : champs GuiManager")
        end
    end
end
-- v0.34 : vrai tant que le respawn de BardN Death System est demandé ou en cours
function R.resp_garde()
    if R.resp_t then return true end
    if R.resp_fin and os.clock() < R.resp_fin then return true end
    -- v0.35 : après le respawn, la garde dure jusqu'à la mort suivante (5 min au plus)
    if R.resp_post then
        if R.resp_vivant and appeler(joueur(), "get_IsDead") == true then
            R.resp_post, R.resp_vivant, R.resp_fin = nil, nil, nil
            evenement("RESPAWN : nouvelle mort — garde levée")
        else
            return true
        end
    end
    local d = _G.BardN_DeathSystem
    if type(d) == "table" and type(d.is_active) == "function" then
        local ok, a = pcall(d.is_active)
        if ok and a == true then return true end
    end
    return false
end
pcall(function()
    local td = sdk.find_type_definition("app.SpecialWakestoneFlowController")
    local m = td and td:get_method("activateFlow()")
    if not m then return end
    sdk.hook(m, function(args)
        if R.resp_garde() then
            R.resp_note("Pierre éternelle")
            return sdk.PreHookResult.SKIP_ORIGINAL
        end
    end, nil)
end)
pcall(function()
    local wu = sdk.find_type_definition("app.WakestoneUser")
    local ms = {}
    pcall(function() ms = wu:get_methods() end)
    for _, m in ipairs(ms) do
        if m:get_name() == "selectUseRealItem" then
            local rt = ""
            pcall(function() rt = m:get_return_type():get_full_name() end)
            sdk.hook(m, function(args)
                if R.resp_garde() then
                    R.resp_bloc = true
                    R.resp_note("proposition de Pierre")
                    return sdk.PreHookResult.SKIP_ORIGINAL
                end
            end, function(r)
                if R.resp_bloc then
                    R.resp_bloc = false
                    if rt == "System.Boolean" then return sdk.to_ptr(0) end
                end
                return r
            end)
        end
    end
end)
function R.suivre_respawn()
    local now = os.clock()
    if R.dlg_natif and now - R.dlg_natif > 600 then R.dlg_natif = nil end
    local t = R.resp_t
    if t == nil or now < t then return end
    R.resp_t = nil
    if appeler(joueur(), "get_IsDead") ~= true then
        evenement("RESPAWN : déclenchement annulé (l'Insurgé est vivant)")
        return
    end
    local ok, res, pourquoi = pcall(function() return _G.BardN_DeathSystem.trigger_death("Shards of Life") end)
    if ok and res == true then
        R.resp_fin = os.clock() + 8.0
        R.resp_post, R.resp_vivant = os.clock(), false
        evenement("RESPAWN : la mort est prise en charge par BardN Death System")
    elseif ok and pourquoi == "sequence already running" then
        R.resp_fin = os.clock() + 8.0
        R.resp_post, R.resp_vivant = os.clock(), false
        evenement("RESPAWN : séquence déjà en cours")
    else
        R.resp_fin = nil
        evenement("RESPAWN : déclenchement IMPOSSIBLE — menu de chargement")
        if not ok then evenement("RESPAWN : erreur " .. tostring(res)) elseif pourquoi then evenement("RESPAWN : raison : " .. tostring(pourquoi)) end
        pcall(function() sdk.get_managed_singleton("app.MainFlowManager"):call("changeFlowPhase(app.MainFlowManager.Phase)", 40) end)
    end
end
pcall(function()
    local td = sdk.find_type_definition("app.Character")
    local m = td and td:get_method("onDieFromAttack(app.HitController.DamageInfo)")
    if not m then return end
    sdk.hook(m, function(args)
        local ok, chr = pcall(sdk.to_managed_object, args[2])
        local pj = joueur()
        if ok and chr and pj and adresse(chr) == adresse(pj) then
            if R.resp_post and not R.resp_t and R.resp_vivant then R.resp_post, R.resp_vivant, R.resp_fin = nil, nil, nil end
            R.sv_armer("coup mortel")
        end
    end, function(r) return r end)
end)
pcall(function()
    local im = sdk.find_type_definition("app.ItemManager")
    local methodes = {}
    pcall(function() methodes = im:get_methods() end)
    for _, m in ipairs(methodes) do
        local nom = m:get_name()
        if nom == "isHave" or nom == "getHaveAllNum" then
            local types = {}
            pcall(function() types = m:get_param_types() end)
            local premier = ""
            pcall(function() premier = types[1]:get_full_name() end)
            if premier == "System.Int32" then
                local base = m:is_static() and 2 or 3
                sdk.hook(m, function(args)
                    R.sv_id = nil
                    if R.sv and not R.sv.releve and not R.sv_pause then
                        local ok, id = pcall(function() return sdk.to_int64(args[base]) & 0xFFFFFFFF end)
                        if ok and id == R.SV_PIERRE then R.sv_id = nom end
                    end
                end, function(r)
                    if R.sv_id == nom then
                        R.sv_id = nil
                        if nom == "isHave" then return sdk.to_ptr(1) end
                        local ok, n = pcall(function() return sdk.to_int64(r) & 0xFFFFFFFF end)
                        if ok and n < 1 then return sdk.to_ptr(1) end
                    end
                    return r
                end)
            end
        end
    end
    -- le retrait de la Pierre est remplacé par la jauge
    local function bloque_retrait(args, base)
        if R.sv == nil then
            -- v0.8 : retrait vu pendant une Pierre choisie sur l'écran à 3 choix
            local sp = R.sv_pierre
            if sp then
                local okI, idI = pcall(function() return sdk.to_int64(args[base]) & 0xFFFFFFFF end)
                if okI and idI == R.SV_PIERRE then
                    sp.supprime = (sp.supprime or 0) + 1
                    evenement(R.fmt("ÉCRAN UNIQUE : retrait de la Pierre de Réveil demandé (%s)", sp.moi and "par le mod" or "par le jeu"))
                end
            end
            return
        end
        local ok, id = pcall(function() return sdk.to_int64(args[base]) & 0xFFFFFFFF end)
        if ok and id == R.SV_PIERRE then
            R.sv_releve()
            if not R.sv.retrait_note then
                R.sv.retrait_note = true
                evenement("SECONDE VIE : retrait de la Pierre de Réveil annulé")
            end
            return sdk.PreHookResult.SKIP_ORIGINAL
        end
    end
    local wu = sdk.find_type_definition("app.WakestoneUser")
    local md = wu and wu:get_method("deleteItem(System.Int32)")
    if md then
        local base = md:is_static() and 2 or 3
        sdk.hook(md, function(args) return bloque_retrait(args, base) end, nil)
    end
    for _, m in ipairs(methodes) do
        if m:get_name() == "deleteItem" then
            local premier = ""
            pcall(function() premier = m:get_param_types()[1]:get_full_name() end)
            if premier == "System.Int32" then
                local base = m:is_static() and 2 or 3
                sdk.hook(m, function(args) return bloque_retrait(args, base) end, nil)
            end
        end
    end
    -- « Non » au dialogue : menu de chargement (phase 40)
    local mf = sdk.find_type_definition("app.MainFlowManager")
    local m3 = mf and mf:get_method("changeFlowPhase(app.MainFlowManager.Phase)")
    if m3 then
        sdk.hook(m3, function(args)
            -- v0.34 : pendant le respawn, ni dialogue de Pierre (28/29) ni menu de chargement (40) du jeu
            if R.resp_garde() then
                local okg, phg = pcall(function() return sdk.to_int64(args[3]) & 0xFFFFFFFF end)
                if okg and (phg == 28 or phg == 29 or phg == 40) then
                    R.resp_note("phase " .. tostring(phg))
                    return sdk.PreHookResult.SKIP_ORIGINAL
                end
            end
            if not R.sv then
                -- v0.33 : « Non » sur le dialogue natif de la Pierre de Réveil (jauge pas pleine) = respawn de Respawn
                if R.dlg_natif and os.clock() - R.dlg_natif < 600 and R.respawn_dispo() then
                    local ok0, ph0 = pcall(function() return sdk.to_int64(args[3]) & 0xFFFFFFFF end)
                    if ok0 and ph0 == 40 and appeler(joueur(), "get_IsDead") == true then
                        R.dlg_natif = nil
                        pcall(function() args[3] = sdk.to_ptr(27) end)
                        evenement("RESPAWN : « Non » au dialogue du jeu — retour au jeu, respawn de BardN Death System")
                        R.respawn_planifier()
                    end
                end
                return
            end
            local ok, ph = pcall(function() return sdk.to_int64(args[3]) & 0xFFFFFFFF end)
            if ok then R.sv.ph, R.sv.ph_t = ph, os.clock() end
            if ok and ph == 40 and not R.sv.releve and R.sv.trois then
                -- v0.73 : écran unique — 2e bouton « Pierre de Réveil » : le jeu croit à un « Non »
                -- (phase 40) ; on l'envoie sur le chemin du « Oui » (phase 29) SANS triche → vraie pierre
                -- v0.74 : la phase 29 vérifie la réponse du dialogue et se fige ; on revient au jeu
                -- (phase 27, comme à la fin du vrai « Oui ») puis on appelle nous-mêmes le relevé
                -- natif : WakestoneUser.useWakestoneToRevivePlayer(Insurgé)
                R.sv = nil
                R.sv_refus_t, R.sv_refus_releve = os.clock(), nil
                local okP = pcall(function() args[3] = sdk.to_ptr(27) end)
                R.sv_pierre = { t = os.clock() + 0.15, essais = 0 }
                evenement("ÉCRAN UNIQUE : Pierre de Réveil choisie — retour au jeu " .. (okP and "ok" or "ÉCHEC") .. ", relevé natif demandé")
                return
            end
            if ok and ph == 40 and not R.sv.releve then
                R.sv = nil                                   -- plus aucune triche : vraies pierres seulement
                if R.respawn_dispo() then
                    -- v0.33 : « Non » = respawn de BardN Death System (retour au jeu, phase 27, puis son déclenchement)
                    pcall(function() args[3] = sdk.to_ptr(27) end)
                    evenement("SECONDE VIE : « Non » aux éclats — retour au jeu, respawn de BardN Death System")
                    R.respawn_planifier()
                    return
                end
                R.sv_refus_t, R.sv_refus_releve = os.clock(), nil
                -- v0.68 : « Non » aux éclats → la Pierre de Réveil classique est proposée ensuite
                local vraies = cfg.sv_puis_pierre and R.vraies_pierres() or 0
                if vraies > 0 then
                    evenement(R.fmt("SECONDE VIE : « Non » aux éclats — Pierre de Réveil classique proposée (%d)", vraies))
                    local okP = pcall(function() args[3] = sdk.to_ptr(28) end)    -- phase 28 : dialogue natif de la Pierre
                    if not okP then evenement("SECONDE VIE : impossible de reproposer la Pierre (menu de chargement)") end
                else
                    evenement("SECONDE VIE : « Non » aux éclats — éclats conservés, pas de vraie Pierre de Réveil")
                end
            end
        end, nil)
    end
end)
pcall(function()
    local gm = sdk.find_type_definition("app.GuiManager")
    local m = gm and gm:get_method("requestGUIPause(System.Boolean)")
    if m == nil then return end
    local base = m:is_static() and 2 or 3
    sdk.hook(m, function(args)
        local sv = R.sv
        if sv == nil or not sv.trois or sv.releve or sv.ferme_t or not sv.dialogue_t then return end
        if os.clock() - sv.dialogue_t < 0.2 then return end
        local ok, v = pcall(function() return (sdk.to_int64(args[base]) & 1) == 1 end)
        if ok and v == false then
            sv.ferme_t = os.clock()
            evenement(R.fmt("ÉCRAN UNIQUE : fenêtre fermée %.1f s après son ouverture", sv.ferme_t - sv.dialogue_t))
        end
    end, nil)
end)
-- réglages imposés (rien d'autre à imposer côté éclats)
function R.imposer()
    cfg.gain_reanimation = 1
end
-- v0.75 : presets (enveloppes avec journal)
function R.preset_info(nom) return PRESETS.info(nom) end
function R.preset_sauver(nom, libelle)
    local ok = PRESETS.sauver(nom, libelle)
    evenement(R.fmt("%s : réglages %s", libelle, ok and "sauvés" or "NON sauvés (erreur d'écriture)"))
end
function R.preset_charger(nom)
    local ok = PRESETS.charger(nom)
    if ok then pcall(R.imposer); sauver() end
    evenement(R.fmt("preset « %s » %s", nom, ok and "chargé" or "illisible"))
end
-- v0.74 : instance de WakestoneUser (relevé natif par une vraie pierre)
pcall(function()
    local wu = sdk.find_type_definition("app.WakestoneUser")
    local m = wu and wu:get_method("useWakestoneIfRequested(app.Character)")
    if m == nil then return end
    sdk.hook(m, function(args)
        if R.wk_user == nil or R.sv_pierre then
            local ok, o = pcall(sdk.to_managed_object, args[2])
            if ok and o then R.wk_user = o end
        end
    end, nil)
end)
-- v0.8 : journal des appels natifs liés à la consommation de la Pierre (pendant l'écran à 3 choix)
pcall(function()
    for _, cls in ipairs({ "app.WakestoneUser", "app.Player" }) do
        local td = sdk.find_type_definition(cls)
        local ms = {}
        pcall(function() ms = td:get_methods() end)
        for _, m in ipairs(ms) do
            local nom = m:get_name()
            if (cls == "app.WakestoneUser" and nom == "useItem") or (cls == "app.Player" and nom == "onReviveFromWakestone") then
                sdk.hook(m, function(args)
                    local sp = R.sv_pierre
                    if sp and not sp.moi then
                        sp.vus = (sp.vus or 0) + 1
                        if sp.vus <= 6 then evenement("ÉCRAN UNIQUE : le jeu appelle " .. cls .. "." .. nom) end
                    end
                end, nil)
            end
        end
    end
end)
-- v0.8 : tentatives de retrait de la Pierre (dans l'ordre), chacune suivie d'un nouveau décompte
function R.etapes_retrait(pj)
    local et = {}
    et[#et + 1] = { "WakestoneUser.deleteItem(77)", function()
        R.wk_user:call("deleteItem(System.Int32)", R.SV_PIERRE)
    end }
    local im = sdk.get_managed_singleton("app.ItemManager")
    local ms = {}
    pcall(function() ms = sdk.find_type_definition("app.ItemManager"):get_methods() end)
    for _, m in ipairs(ms) do
        if m:get_name() == "deleteItem" then
            local noms, args, ok = {}, {}, true
            pcall(function()
                local types = m:get_param_types()
                for i, ty in ipairs(types) do
                    local tn = ty:get_full_name()
                    noms[#noms + 1] = tn
                    if tn == "System.Int32" then args[i] = (i == 1) and R.SV_PIERRE or (i == 2 and 1 or 0)
                    elseif tn == "app.Character" then args[i] = pj
                    else ok = false end
                end
            end)
            local sig = "ItemManager.deleteItem(" .. table.concat(noms, ", ") .. ")"
            if ok and #args >= 1 and args[1] == R.SV_PIERRE and not m:is_static() then
                et[#et + 1] = { sig, function() m:call(im, table.unpack(args, 1, #noms)) end }
            else
                evenement("ÉCRAN UNIQUE : signature non essayée : " .. sig)
            end
        end
    end
    et[#et + 1] = { "WakestoneUser.useItem(0)", function() R.wk_user:call("useItem(System.Int32)", 0) end }
    return et
end
-- v0.8 : après le relevé, la Pierre doit avoir été retirée ; sinon le mod la retire lui-même
function R.verifier_pierre(sp, pj, now)
    if now < sp.verif then return end
    if sp.n0 == nil or sp.n0 < 1 then
        evenement("ÉCRAN UNIQUE : aucune vraie Pierre comptée avant le relevé — rien à vérifier")
        R.sv_pierre = nil
        return
    end
    local n1 = R.vraies_pierres(true)
    if n1 < sp.n0 then
        evenement(R.fmt("ÉCRAN UNIQUE : Pierre de Réveil consommée (%d → %d)%s", sp.n0, n1, sp.mod_agit and " — retirée par le mod" or ""))
        R.sv_pierre = nil
        return
    end
    if (sp.supprime or 0) > 0 and not sp.attente2 then
        -- le jeu a demandé le retrait mais le décompte n'a pas bougé : on lui laisse 3 s de plus avant d'agir
        sp.attente2, sp.verif = true, now + 3.0
        return
    end
    if sp.etapes == nil then
        evenement(R.fmt("ÉCRAN UNIQUE : la Pierre n'a PAS été retirée par le jeu (%d pierres, retrait vu : %d, appels vus : %d) → retrait par le mod",
            n1, sp.supprime or 0, sp.vus or 0))
        sp.etapes, sp.i = R.etapes_retrait(pj), 0
    end
    if sp.i >= #sp.etapes or R.wk_user == nil then
        evenement("ÉCRAN UNIQUE : retrait de la Pierre IMPOSSIBLE — envoie-moi le journal")
        R.sv_pierre = nil
        return
    end
    sp.i = sp.i + 1
    local e = sp.etapes[sp.i]
    sp.moi = true
    local ok, err = pcall(e[2])
    sp.moi, sp.mod_agit = false, true
    evenement(R.fmt("ÉCRAN UNIQUE : essai %d/%d « %s » : %s", sp.i, #sp.etapes, e[1], ok and "appelé" or ("ERREUR " .. tostring(err))))
    sp.verif = now + 0.7
end
function R.suivre_pierre_choisie()
    local sp = R.sv_pierre
    if sp == nil then return end
    local now = os.clock()
    if now < sp.t then return end
    local pj = joueur()
    if sp.vivant then
        if now > sp.vivant + 25 then R.sv_pierre = nil; return end
        return R.verifier_pierre(sp, pj, now)
    end
    if sp.n0 == nil then
        sp.n0 = R.vraies_pierres(true)
        evenement(R.fmt("ÉCRAN UNIQUE : %d vraie(s) Pierre(s) avant le relevé", sp.n0))
    end
    if appeler(pj, "get_IsDead") ~= true then
        evenement("ÉCRAN UNIQUE : Insurgé relevé par la Pierre de Réveil")
        sp.vivant, sp.verif = now, now + 4.0
        return
    end
    if sp.essais >= 3 then
        evenement("ÉCRAN UNIQUE : relevé par la Pierre IMPOSSIBLE — menu de chargement")
        R.sv_pierre = nil
        pcall(function() sdk.get_managed_singleton("app.MainFlowManager"):call("changeFlowPhase(app.MainFlowManager.Phase)", 40) end)
        return
    end
    sp.essais, sp.t = sp.essais + 1, now + 1.5
    local ok, err = pcall(function()
        R.wk_user:call("useWakestoneToRevivePlayer(app.Character)", pj)
    end)
    evenement(R.fmt("ÉCRAN UNIQUE : relevé natif par la Pierre, essai %d : %s", sp.essais, ok and "demandé" or ("ERREUR " .. tostring(err))))
end
-- v0.68 : nombre de vraies Pierres de Réveil (77) et de Pierres éternelles (601), sans triche
function R.vraies_pierres(seul77)
    local im = sdk.get_managed_singleton("app.ItemManager")
    local pj = joueur()
    if im == nil or pj == nil then return 0 end
    R.sv_pause = true                      -- v0.70 : triche suspendue le temps de compter
    local function a(id, k)
        local ok, v = pcall(function() return im:call("isHave(System.Int32, System.Int32, app.Character)", id, k, pj) end)
        return ok and v == true
    end
    -- v0.71 : nombre porté par l'Insurgé (plus grand k accepté par isHave), pas le coffre
    local n = 0
    if a(R.SV_PIERRE, 1) then
        local bas, haut = 1, 2
        while haut <= 128 and a(R.SV_PIERRE, haut) do bas, haut = haut, haut * 2 end
        while haut - bas > 1 do
            local m = (bas + haut) // 2
            if a(R.SV_PIERRE, m) then bas = m else haut = m end
        end
        n = bas
    end
    if n == 0 and not seul77 and a(601, 1) then n = 1 end
    R.sv_pause = false
    return n
end
-- v0.66 : texte du dialogue natif remplacé (« Éclats de vie » / « Shards of Life »)
pcall(function()
    local gm = sdk.find_type_definition("app.GuiManager")
    local methodes = {}
    pcall(function() methodes = gm:get_methods() end)
    for _, m in ipairs(methodes) do
        local premier = ""
        pcall(function() premier = m:get_param_types()[1]:get_full_name() end)
        if m:get_name() == "requestDialog" and premier == "System.String" then
            local base = m:is_static() and 2 or 3
            sdk.hook(m, function(args)
                if R.resp_garde() then
                    local okd, od = pcall(function() return sdk.to_managed_object(args[base]):call("ToString"):lower() end)
                    if okd and od and (od:find("veil", 1, true) or od:find("wakestone", 1, true)) then
                        R.resp_note("dialogue de Pierre")
                        return sdk.PreHookResult.SKIP_ORIGINAL
                    end
                end
                if R.sv == nil or R.sv.releve then
                    if R.respawn_dispo() then
                        pcall(function()
                            local o = sdk.to_managed_object(args[base]):call("ToString"):lower()
                            if o:find("veil", 1, true) or o:find("wakestone", 1, true) then R.dlg_natif = os.clock() end
                        end)
                    end
                    return
                end
                local orig = ""
                pcall(function() orig = sdk.to_managed_object(args[base]):call("ToString") end)
                local bas = orig:lower()
                if not (bas:find("veil", 1, true) or bas:find("wakestone", 1, true)) then return end
                local fr = orig:find("Pierre", 1, true) or orig:find("é", 1, true)
                if cfg.langue == "auto" and R.langue_jeu ~= (fr and "fr" or "en") then R.langue_jeu = fr and "fr" or "en"; R.cache_t, R.cache_n = {}, 0 end
                -- v0.48 : Second Breath — texte adapté au nombre d'éclats disponibles et
                -- au nombre de Séquelles qui en résulteront (0, 1 ou 2).
                local n = unites
                local ns = R.sb_nouvelles_pour(n)
                local mot_s_fr = (ns == 1) and "Séquelle" or "Séquelles"
                local mot_s_en = (ns == 1) and "Affliction" or "Afflictions"
                local avis_fr, avis_en
                if ns == 0 then
                    avis_fr = "aucune Séquelle"
                    avis_en = "no Affliction"
                else
                    avis_fr = string.format("%d %s à la résurrection", ns, mot_s_fr)
                    avis_en = string.format("%d %s on revival",         ns, mot_s_en)
                end
                local txt = fr and string.format("Second Breath ?\n(%d éclat%s consommé%s, %s.)",
                                                 n, n > 1 and "s" or "", n > 1 and "s" or "", avis_fr)
                              or string.format("Second Breath?\n(%d shard%s consumed, %s.)",
                                                 n, n > 1 and "s" or "", avis_en)
                local choix = nil
                if cfg.sv_ecran_unique then
                    local np = R.vraies_pierres()
                    if np > 0 then
                        R.sd_np = np
                        txt = fr and "Revenir à la vie ?" or "Return to life?"
                        local lib_eclats_fr = string.format("Second Breath (%d éclat%s → %s)", n, n > 1 and "s" or "", avis_fr)
                        local lib_eclats_en = string.format("Second Breath (%d shard%s → %s)", n, n > 1 and "s" or "", avis_en)
                        choix = fr and { lib_eclats_fr, string.format("Utiliser une Pierre de Réveil (%d)", np), "Non" }
                                    or { lib_eclats_en, string.format("Use a Wakestone (%d)", np), "No" }
                    end
                end
                local ok = pcall(function()
                    R.sv_txts = {}
                    local function chaine(t)
                        local str = sdk.create_managed_string(t)
                        pcall(function() str:add_ref() end)
                        R.sv_txts[#R.sv_txts + 1] = str
                        return sdk.to_ptr(str)
                    end
                    args[base] = chaine(txt)
                    if choix then
                        for i = 1, 3 do args[base + i] = chaine(choix[i]) end
                    end
                end)
                if choix and ok then R.sv.trois, R.sv.dialogue_t = true, os.clock() end
                if not R.sv.txt_note then
                    R.sv.txt_note = true
                    evenement("SECONDE VIE : dialogue « Éclats de vie » " .. (ok and "affiché" or "IMPOSSIBLE (texte du jeu gardé)"))
                end
            end, nil)
        end
    end
end)
function R.suivre_seconde_vie()
    -- repli : mort par une autre voie (chute…) détectée par l'état de l'Insurgé
    local mort = appeler(joueur(), "get_IsDead") == true
    if R.resp_post and not R.resp_t then      -- v0.38 : suivi vivant -> mort de la garde, sans lecture en plus
        if not mort then R.resp_vivant = true
        elseif R.resp_vivant then
            R.resp_post, R.resp_vivant, R.resp_fin = nil, nil, nil
            evenement("RESPAWN : nouvelle mort — garde levée")
        end
    end
    if mort and not R.sv_mort_prec then R.sv_armer("chute ou autre") end
    R.sv_mort_prec = mort
    local sv = R.sv
    if sv == nil then return end
    local now = os.clock()
    -- v0.73 : 3e bouton « Non » de l'écran unique : la fenêtre se ferme et le jeu attend →
    -- on demande nous-mêmes le menu de chargement (phase 40)
    if sv.ferme_t and not sv.releve and now - sv.ferme_t > 0.5 and (sv.ph_t or 0) <= sv.ferme_t and R.respawn_dispo() then
        -- v0.33 : « Non » = respawn de BardN Death System (retour au jeu, phase 27, puis son déclenchement)
        R.sv = nil
        local okF = pcall(function()
            sdk.get_managed_singleton("app.MainFlowManager"):call("changeFlowPhase(app.MainFlowManager.Phase)", 27)
        end)
        evenement("ÉCRAN UNIQUE : « Non » choisi — retour au jeu " .. (okF and "demandé" or "IMPOSSIBLE") .. ", respawn de BardN Death System")
        R.respawn_planifier()
        return
    end
    if sv.ferme_t and not sv.releve and now - sv.ferme_t > 0.5 and (sv.ph_t or 0) <= sv.ferme_t then
        R.sv = nil
        R.sv_refus_t, R.sv_refus_releve = os.clock(), nil
        local okF = pcall(function()
            sdk.get_managed_singleton("app.MainFlowManager"):call("changeFlowPhase(app.MainFlowManager.Phase)", 40)
        end)
        evenement("ÉCRAN UNIQUE : « Non » choisi — menu de chargement " .. (okF and "demandé" or "IMPOSSIBLE"))
        return
    end
    -- v0.32 : fenêtre à 3 boutons ouverte (ni relevé, ni fermeture vue) : on garde l'état (15 min au plus),
    -- sinon « Non » ne faisait parfois rien (état oublié avant le clic)
    if sv.trois and not sv.releve and not sv.ferme_t and sv.dialogue_t and now - sv.dialogue_t < 900 then return end
    local raison = nil
    if sv.releve and now - sv.t > 3.0 then raison = "relevé terminé"
    elseif not sv.releve and not mort and now - sv.t > 5.0 then raison = "relevé par autre chose"      -- relevé par autre chose
    elseif now - sv.t > 120 then raison = "délai de 120 s dépassé" end
    if raison then
        if sv.trois and not sv.releve then evenement("SECONDE VIE : état abandonné (" .. raison .. ") après l'écran à 3 choix") end
        R.sv = nil
    end
end


-- ----------------------------------------------------------------------------
-- v0.44 : remise à zéro du flux (repos, Transpierre, voyage) et coopération
-- ----------------------------------------------------------------------------
for _, h in ipairs({ { "app.Human", "notifyReviveFromWakestone()" }, { "app.Player", "onReviveFromWakestone()" },
                     { "app.ReviveFromWakestone", "revive(app.Character, System.Single, System.Boolean)" } }) do
    pcall(function()
        local td = sdk.find_type_definition(h[1])
        local m = td and td:get_method(h[2])
        if m then
            sdk.hook(m, function(args)
                if R.sv then R.sv_releve()
                elseif R.sv_refus_t and os.clock() - R.sv_refus_t < 120 then
                    -- v0.68 : vraie Pierre après refus des éclats : éclats gardés
                    -- v0.71 : les 3 accroches du relevé passent toutes ici (fenêtre de 5 s après le 1er appel)
                    if not R.sv_refus_releve then
                        R.sv_refus_releve = os.clock()
                        evenement("relevé par une vraie Pierre de Réveil : éclats de vie conservés")
                    end
                    if os.clock() - R.sv_refus_releve > 5 then R.sv_refus_t, R.sv_refus_releve = nil, nil end
                else R.raz_transpierre = true end
                return sdk.PreHookResult.CALL_ORIGINAL
            end,
                function(r) return r end)
        end
    end)
end
R.raz_etat = { skip = false, pos = nil, t = 0, dernier = -100 }
function R.raz(raison)
    local now = os.clock()
    if now - R.raz_etat.dernier < 3.0 then return end
    R.raz_etat.dernier = now
    if unites > 0 then changer_unites(-unites, "remise à zéro : " .. raison)
    else evenement("remise à zéro : " .. raison .. " (aucun éclat de vie)") end
    -- v0.48 : spec §6 — Repos à l'auberge et Pierre de faille guérissent les Séquelles.
    -- Les Traumatismes sont conservés (ils demandent une voyante).
    -- Le voyage ne guérit PAS les Séquelles (reste cohérent avec le texte de la spec).
    local r = tostring(raison or "")
    if r:find("^repos") or r:find("^Transpierre") or r:find("^Riftstone") or r:find("^Pierre de faille") then
        pcall(R.guerir_sequelles, raison)
    end
end
function R.heure_jeu()
    local tm = sdk.get_managed_singleton("app.TimeManager")
    if tm == nil then return nil end
    local jour, heure, minute = nil, nil, 0
    pcall(function() jour = tonumber(tm:call("get_InGameDay")) end)
    pcall(function() heure = tonumber(tm:call("get_InGameHour")) end)
    pcall(function() minute = tonumber(tm:call("get_InGameMinute")) or 0 end)
    if heure == nil then return nil end
    return (jour or 0) * 24 + heure + (minute or 0) / 60
end
function R.suivre_raz()
    if R.raz_transpierre then
        R.raz_transpierre = false
        if cfg.raz_transpierre then R.raz("Transpierre utilisée") end
    end
    local e = R.raz_etat
    local skip = false
    pcall(function() skip = sdk.get_managed_singleton("app.TimeSkipManager"):call("get_IsExecute") == true end)
    R.temps_passe = skip
    -- v0.62 : le repos ne compte que si l'heure du jeu avance d'au moins raz_repos_heures
    local h = R.heure_jeu()
    if skip and not e.skip then
        e.h_debut = h
        e.camp = false
        pcall(function() e.camp = sdk.get_managed_singleton("app.CampManager"):call("get_IsActiveCamp") == true end)
    end
    if e.skip and not skip and cfg.raz_repos then
        if h and e.h_debut then
            local d = h - e.h_debut
            if d < 0 then d = d + 24 end            -- passage de minuit sans jour lisible
            -- v0.62 : un camp actif = vraie nuit, quelle que soit la durée ; sinon (auberge)
            -- il suffit qu'un peu de temps passe : les passages « techniques » n'en font pas passer
            if e.camp or d >= cfg.raz_repos_heures then
                R.raz(R.fmt("repos (%s, %.1f h passées)", e.camp and "feu de camp" or "auberge / temps passé", d))
            else
                evenement(R.fmt("temps passé de %.1f h seulement (pas de camp) : éclats de vie conservés", d))
            end
        else
            R.raz("repos / temps passé (heure du jeu illisible)")
        end
    end
    e.skip = skip
    local now = os.clock()
    if now - e.t >= 0.5 then
        e.t = now
        local p = position(joueur())
        -- v0.48 : sauts de ~125 m parasites (même en combat) → voyage seulement hors combat,
        -- au-delà de raz_distance, et confirmé : la nouvelle position doit tenir 1 s
        if p and e.cand then
            if distance(p, e.cand.p) < 15 then
                if os.clock() - e.cand.t >= 1.0 then
                    if cfg.raz_voyage and not en_combat then R.raz(R.fmt("voyage (%.0f m d'un coup)", e.cand.d)) end
                    e.cand = nil
                end
            else
                e.cand = nil
            end
        elseif p and e.pos and distance(p, e.pos) > cfg.raz_distance then
            e.cand = { p = p, t = os.clock(), d = distance(p, e.pos) }
        end
        e.pos = p
    end
end
local function mettre_a_jour()
    local t = maintenant()

    if t - dernier_rafraichissement > 1.0 then
        dernier_rafraichissement = t
        pcall(rafraichir_groupe)
    end

    -- v0.45 : l'état de combat est relu 7 fois par seconde, pas à chaque image
    if t - (R.combat_t or -1) > 0.15 then
        R.combat_t = t
        local mode = appeler(sdk.get_managed_singleton("app.BattleManager"), "get_BattleMode")
        if type(mode) ~= "number" then mode = 0 end
        local combat = (mode == 2) or (cfg.compter_alerte_comme_combat and mode == 1)
        if combat ~= en_combat then
            en_combat = combat
            evenement(combat and "début du combat" or "fin du combat")
        end
    end

    pcall(R.suivre_langue)
end

-- ----------------------------------------------------------------------------
-- Intégration à HUD Controls (Nexus DD2 n° 105), même méthode que KH HUD :
-- la jauge est déclarée via _G.hud_controls.define_ui ; ses règles (combat, arme
-- dégainée, immobile…), touches et bascule globale décident de l'affichage.
-- ----------------------------------------------------------------------------
R.hc = { api = nil, def = nil, statut = "HUD Controls non détecté", essai = -100, alpha = 1.0, t = nil }
R.hcs = { def = nil, alpha = 1.0, t = nil }   -- v0.70 : barre d'icônes Séquelles / Traumatismes
function R.hc_brancher()
    if R.hc.api or not cfg.use_hud_controls then return end
    local now = os.clock()
    if now - R.hc.essai < 2.0 then return end
    R.hc.essai = now
    local api = rawget(_G, "hud_controls")
    if type(api) ~= "table" or type(api.define_ui) ~= "function" or type(api.calculate_alpha) ~= "function" then return end
    local ok, err = pcall(function()
        R.hc.def = api.define_ui("bardn_savior_gauge", { label = R.T("BardN Shards of Life — Éclats de vie") })
        -- v0.70 : barre d'icônes Séquelles / Traumatismes (bas gauche) = élément HUD Controls à part
        R.hcs.def = api.define_ui("bardn_sequelles_bar", { label = R.T("BardN Shards of Life — Séquelles et Traumatismes (barre d'icônes)") })
    end)
    if ok and R.hc.def then
        R.hc.api = api
        R.hc.statut = "connecté à HUD Controls (élément « BardN Shards of Life — Éclats de vie »)"
        evenement("HUD Controls : jauge déclarée")
    else
        R.hc.statut = "erreur HUD Controls : " .. tostring(err)
    end
end
function R.hc_cible()
    if not (R.hc.api and R.hc.def and cfg.use_hud_controls) then return 1.0 end
    if api.incantation and cfg.jauge_visible_incantation then return 1.0 end
    local ok, a = pcall(R.hc.api.calculate_alpha, R.hc.def, nil)
    if not ok or type(a) ~= "number" then return 1.0 end
    return a > 0 and 1.0 or 0.0
end
function R.hc_alpha()
    local now = os.clock()
    local dt = R.hc.t and math.min(0.1, now - R.hc.t) or 0
    R.hc.t = now
    local c = R.hc_cible()
    local v = dt / 0.25
    if R.hc.alpha < c then R.hc.alpha = math.min(c, R.hc.alpha + v) else R.hc.alpha = math.max(c, R.hc.alpha - v) end
    return R.hc.alpha
end
-- v0.70 : opacité (0..1, avec fondu) de la barre d'icônes Séquelles / Traumatismes selon HUD Controls.
-- Sans HUD Controls (ou option décochée) : toujours 1.
function R.hcs_alpha()
    local now = os.clock()
    local dt = R.hcs.t and math.min(0.1, now - R.hcs.t) or 0
    R.hcs.t = now
    local c = 1.0
    if R.hc.api and R.hcs.def and cfg.use_hud_controls then
        local ok, a = pcall(R.hc.api.calculate_alpha, R.hcs.def, nil)
        if ok and type(a) == "number" then c = a > 0 and 1.0 or 0.0 end
    end
    local v = dt / 0.25
    if R.hcs.alpha < c then R.hcs.alpha = math.min(c, R.hcs.alpha + v) else R.hcs.alpha = math.max(c, R.hcs.alpha - v) end
    return R.hcs.alpha
end
-- aperçu en direct de la jauge quand le tiroir « Interface à l'écran (HUD) » est ouvert
R.hud = { apercu = true, vu = -10 }
function R.hud_apercu_actif() return R.hud.apercu and os.clock() - R.hud.vu < 0.4 end

-- v0.43 : temporisation/fondu de la jauge lorsque le joueur devient disponible.
-- On ne touche pas à R.ca, également utilisée par d'autres effets visuels.
R.jauge_transition = { joueur_present = false, debut = nil, alpha = 0.0 }
local function alpha_jauge()
    local etat = R.jauge_transition
    local present = joueur() ~= nil
    local t = os.clock()
    -- v0.44 : masquée pendant la pause et le temps qui passe (écran noir), retour retardé
    local pause = false
    pcall(function()
        local pm = sdk.get_managed_singleton("app.PauseManager")
        pause = pm:call("isPausedAny") == true
    end)
    if pause or R.temps_passe then
        etat.bloque = R.temps_passe and "temps" or (etat.bloque == "temps" and "temps" or "pause")
        etat.alpha = 0.0
        return 0.0
    end
    if etat.bloque then
        etat.bloque_prec = etat.bloque
        etat.bloque = false
        etat.debut = t + ((etat.bloque_prec == "pause") and cfg.jauge_delai_pause or 5.0)
    end
    if not present then
        etat.joueur_present = false
        etat.debut = nil
        etat.alpha = 0.0
        return 0.0
    end
    if not etat.joueur_present then
        etat.joueur_present = true
        etat.debut = t + 5.0
        etat.alpha = 0.0
    end
    local cible = etat.debut and (t < etat.debut and 0.0 or math.min(1.0, (t - etat.debut) / 1.25)) or 1.0
    etat.alpha = cible
    return cible
end

local function couleur_alpha(col, a)
    if a >= 0.999 then return col end
    local base = (col >> 24) & 0xFF
    return (math.floor(base * a) << 24) | (col & 0xFFFFFF)
end

-- v0.3 : interface compatible BardN_KH_HUD. KH HUD appelle api.orbes_kh() à chaque image où il
-- dessine ses orbes ; tant qu'il le fait (R.kh_vu récent), la jauge classique n'affiche plus ses
-- segments (le reste — messages, barre d'incantation — reste dessiné). Si KH HUD est absent ou
-- masqué, la jauge classique reprend la main au bout de 2 s.
R.kh = { slots = {}, pret = false, n = 0 }
function api.orbes_kh()
    R.kh_vu = os.clock()
    local t = R.kh
    local n = math.max(1, cfg.energie_max)
    for i = #t.slots, n + 1, -1 do t.slots[i] = nil end
    for i = 1, n do t.slots[i] = math.max(0, math.min(1, unites - (i - 1))) end
    t.n = n
    t.pret = unites >= n
    return t
end

-- ============================================================================
-- v0.45 : FORMES, MOTEUR DE LIQUIDE ET STYLES D'INTERFACE
-- Le mod est autonome : rien de tout cela ne dépend de BardN_KH_HUD.
-- Un « parcours » décrit la jauge entière (tous les segments bout à bout) :
-- le flux, les reflets, les scintillements et la crête traversent les éclats
-- sans rupture, comme sur une seule jauge.
-- ============================================================================
local FL = {}

-- ----------------------------------------------------------------------------
-- Formes : profil vertical de la silhouette à la position u (0 = début du
-- segment, 1 = fin). Renvoie k0, k1 en fractions de la hauteur.
-- ----------------------------------------------------------------------------
FL.FORMES = { "segments", "eclats", "orbes", "lames", "barre" }
FL.FORMES_LIB = {
    segments = "Segments (rectangles)",
    eclats   = "Éclats (losanges)",
    orbes    = "Orbes (disques)",
    lames    = "Lames (biseautées)",
    barre    = "Barre continue (un seul bloc)",
}
function FL.plate(forme) return forme ~= "eclats" and forme ~= "orbes" and forme ~= "lames" end
function FL.profil(forme, u, biais)
    if forme == "eclats" then
        local k = 1 - math.abs(2 * u - 1)
        if k < 0.04 then k = 0.04 end
        return 0.5 - k * 0.5, 0.5 + k * 0.5
    elseif forme == "orbes" then
        local d = 2 * u - 1
        local k = math.sqrt(math.max(0.002, 1 - d * d))
        return 0.5 - k * 0.5, 0.5 + k * 0.5
    elseif forme == "lames" then
        local b = biais or 0.35
        return b * (1 - u), 1 - b * u
    end
    return 0, 1
end

-- ----------------------------------------------------------------------------
-- Couleurs (format du jeu d'affichage : 0xAABBGGRR)
-- ----------------------------------------------------------------------------
local function ch(c, d) return (c >> d) & 0xFF end
local function compose(a, b, g, r)
    return ((a & 0xFF) << 24) | ((b & 0xFF) << 16) | ((g & 0xFF) << 8) | (r & 0xFF)
end
function FL.melange(c1, c2, t)
    if t <= 0 then return c1 end
    if t >= 1 then return c2 end
    local function m(d) return math.floor(ch(c1, d) + (ch(c2, d) - ch(c1, d)) * t + 0.5) end
    return compose(m(24), m(16), m(8), m(0))
end
-- vers le blanc (k > 0) ou vers le noir (k < 0), sans toucher à l'opacité
function FL.lumiere(c, k)
    if k > 0 then
        local function m(d) local v = ch(c, d) return math.floor(v + (255 - v) * k + 0.5) end
        return compose(ch(c, 24), m(16), m(8), m(0))
    elseif k < 0 then
        local f = 1 + k
        local function m(d) return math.floor(ch(c, d) * f + 0.5) end
        return compose(ch(c, 24), m(16), m(8), m(0))
    end
    return c
end
function FL.opacite(c, a)
    if a >= 0.999 then return c end
    if a <= 0 then return c & 0xFFFFFF end
    return (math.floor(ch(c, 24) * a + 0.5) << 24) | (c & 0xFFFFFF)
end
-- palette cyclique de 4 couleurs, transitions adoucies
function FL.palette(p, u)
    u = u - math.floor(u)
    local f = u * 4
    local i = math.floor(f)
    local t = f - i
    t = t * t * (3 - 2 * t)
    return FL.melange(p[i % 4 + 1], p[(i + 1) % 4 + 1], t)
end

-- ----------------------------------------------------------------------------
-- Parcours : tous les segments bout à bout. d va de 0 à ctx.total.
-- ----------------------------------------------------------------------------
function FL.parcours(x0, y, w_seg, h, esp, n, forme, biais)
    return { x0 = x0, y = y, w = w_seg, h = h, esp = esp, n = n,
             forme = forme, biais = biais, plate = FL.plate(forme), total = w_seg * n }
end

-- Peint le morceau de parcours entre d1 et d2, sur la bande verticale t0..t1
-- (0 = bord haut de la silhouette, 1 = bord bas ; hors de [0,1] = débordement).
-- Les segments traversés sont découpés ; les formes non plates sont suivies
-- par petites tranches.
function FL.trait(ctx, d1, d2, t0, t1, col, pas_max)
    if col == nil or ch(col, 24) == 0 then return end
    if d1 < 0 then d1 = 0 end
    if d2 > ctx.total then d2 = ctx.total end
    if d2 - d1 <= 0.05 then return end
    if t1 < t0 then t0, t1 = t1, t0 end
    local w, esp, h, y = ctx.w, ctx.esp, ctx.h, ctx.y
    local i1 = math.floor(d1 / w)
    local i2 = math.floor((d2 - 0.001) / w)
    for i = i1, i2 do
        local a = math.max(d1, i * w)
        local b = math.min(d2, (i + 1) * w)
        if b - a > 0.05 then
            local xs = ctx.x0 + i * (w + esp)
            if ctx.plate then
                -- léger débordement (0,6 px) : les tranches voisines se recouvrent,
                -- sinon un quadrillage sombre apparaît à leurs jonctions.
                draw.filled_rect(xs + (a - i * w), y + t0 * h, (b - a) + 0.6,
                    math.max(0.6, (t1 - t0) * h) + 0.6, col)
            else
                -- Le profil est suivi par tranches, mais jamais plus de 8 par
                -- segment et par couche : le coût d'une forme reste borné.
                local pas = pas_max or 2.5
                local nb = math.max(1, math.min(8, math.ceil((b - a) / pas)))
                local dd = (b - a) / nb
                for j = 0, nb - 1 do
                    local xa = a + j * dd
                    local u = (xa + dd * 0.5 - i * w) / w
                    local k0, k1 = FL.profil(ctx.forme, u, ctx.biais)
                    local hh = (k1 - k0) * h
                    local ya = y + (k0 + t0 * (k1 - k0)) * h
                    draw.filled_rect(xs + (xa - i * w), ya, dd + 0.6,
                        math.max(0.6, (t1 - t0) * hh) + 0.6, col)
                end
            end
        end
    end
end

-- ----------------------------------------------------------------------------
-- Le liquide complet, de d_a à d_b sur le parcours.
-- pal = 4 couleurs ; c = table de réglages fl_* ; alpha = fondu général.
-- ----------------------------------------------------------------------------
function FL.liquide(ctx, d_a, d_b, pal, c, alpha, ech, horloge)
    local total = ctx.total
    if d_b - d_a <= 0.5 or alpha <= 0.01 then return end
    local now = horloge
    local mnow = now * math.max(0, c.fl_mult_vitesse or 1)
    local deux_pi = math.pi * 2
    local h = ctx.h

    -- 1. Lumière lancinante, sous le liquide : un halo qui respire et déborde.
    local battement = 0
    if c.fl_halo and (c.fl_halo_intensite or 0) > 0 then
        local sp = math.max(0, c.fl_halo_vitesse or 0.55)
        local b = 0.5 - 0.5 * math.cos(now * sp * deux_pi)
        b = b * b * (3 - 2 * b)
        local mn = math.max(0, math.min(1, c.fl_halo_min or 0.35))
        battement = mn + (1 - mn) * b
        local inten = math.max(0, math.min(1, c.fl_halo_intensite)) * battement
        local grow = math.max(0, c.fl_halo_taille or 0) * ech
        if inten > 0 and grow > 0.5 then
            local couches = math.max(4, math.min(10, math.floor(grow / 2.2)))
            local gmax, prec = grow / h, 0
            for i = 1, couches do
                local k = i / couches
                local g = gmax * k
                local f = 1 - k
                local a = math.floor(255 * inten * 0.32 * f * f * alpha) + 1
                local col = (a << 24) | (c.fl_halo_couleur & 0xFFFFFF)
                FL.trait(ctx, d_a, d_b, -g, -prec, col, 10)
                FL.trait(ctx, d_a, d_b, 1 + prec, 1 + g, col, 10)
                prec = g
            end
        end
    end

    -- 2. Le liquide : tranches fines dont la teinte défile et ondule, avec le
    -- relief et le vernis fondus dans la couleur (une seule passe de dessin).
    local finesse = math.max(1.0, (c.fl_finesse or 2.4) * ech)
    local nb = math.max(1, math.min(360, math.ceil((d_b - d_a) / finesse)))
    local pas = (d_b - d_a) / nb
    local wl = math.max(20, c.fl_longueur_onde or 300)
    local decal = mnow * (c.fl_vitesse or 26)
    local turb = math.max(0, c.fl_turbulence or 0)
    local vol = math.max(0, math.min(1, c.fl_volume or 0))
    local vernis = math.max(0, math.min(1, c.fl_vernis or 0))
    local bandes = c.fl_bandes or 0
    if bandes <= 0 then bandes = math.max(3, math.min(9, math.floor(h / 2.2))) end
    if not (vol > 0 or vernis > 0) then bandes = 1 end
    local inv = 1 / bandes
    -- profil de lumière dans l'épaisseur, calculé une fois
    local prof = FL.cache_prof
    if prof == nil or prof.n ~= bandes or prof.v ~= vol or prof.g ~= vernis then
        prof = { n = bandes, v = vol, g = vernis }
        for i = 0, bandes - 1 do
            local m = (i + 0.5) * inv
            local dh = (m - 0.16) / 0.26
            local dg = (m - 0.22) / 0.15
            local hi = 0.20 * vol * math.exp(-dh * dh) + 0.26 * vernis * math.exp(-dg * dg)
            if m > 0.50 then
                local k = (m - 0.50) / 0.50
                hi = hi - 0.30 * vol * k * k
            end
            prof[i + 1] = hi
        end
        FL.cache_prof = prof
    end
    -- fusion des tranches voisines de même couleur (formes plates seulement)
    local fusion = ctx.plate
    local debut, couleur = nil, nil
    for i = 0, nb - 1 do
        local d = d_a + (i + 0.5) * pas
        local u = (d - decal) / wl
            + turb * 0.16 * math.sin(d * 0.045 + mnow * 1.7)
            + turb * 0.10 * math.sin(d * 0.013 - mnow * 0.9)
            + turb * 0.05 * math.sin(d * 0.085 - mnow * 2.6)
        local base = FL.palette(pal, u)
        if fusion then
            if couleur == nil then debut, couleur = d_a + i * pas, base
            elseif base ~= couleur then
                FL.bandes_liquide(ctx, debut, d_a + i * pas, couleur, prof, bandes, inv, alpha)
                debut, couleur = d_a + i * pas, base
            end
        else
            FL.bandes_liquide(ctx, d_a + i * pas, d_a + (i + 1) * pas, base, prof, bandes, inv, alpha)
        end
    end
    if fusion and couleur ~= nil then
        FL.bandes_liquide(ctx, debut, d_b, couleur, prof, bandes, inv, alpha)
    end

    -- 3. La lumière lancinante traverse aussi le liquide.
    local trav = math.max(0, math.min(1, c.fl_halo_traversant or 0))
    if trav > 0 and battement > 0 then
        local a = math.floor(70 * trav * battement * alpha)
        if a > 0 then
            FL.trait(ctx, d_a, d_b, 0.06, 0.94, (a << 24) | (c.fl_halo_couleur & 0xFFFFFF), 3)
        end
    end

    -- 4. Reflets : ils traversent tous les éclats sans rupture.
    local nr = math.max(0, math.min(6, math.floor(c.fl_reflets or 0)))
    local ri = math.max(0, math.min(1, c.fl_reflet_intensite or 0))
    if nr > 0 and ri > 0 then
        local w = math.max(6, (c.fl_reflet_largeur or 70) * ech)
        local sp = c.fl_reflet_vitesse or 0.3
        local a = math.floor(255 * ri * 0.085 * alpha)
        if a > 0 then
            local gc = c.fl_reflet_couleur or 0xFFFFFFFF
            for g = 0, nr - 1 do
                local ph = mnow * sp + g / nr
                ph = ph - math.floor(ph)
                local centre = -w + ph * (total + 2 * w)
                for j = 1, 5 do
                    local k = 1 - (j - 1) * 0.17
                    local demi = w * 0.5 * k * k
                    local x1, x2 = centre - demi, centre + demi
                    if x2 > d_a and x1 < d_b then
                        FL.trait(ctx, math.max(d_a, x1), math.min(d_b, x2),
                            0.10 + 0.05 * (j - 1), 0.74 - 0.06 * (j - 1),
                            (a << 24) | (gc & 0xFFFFFF), 6)
                    end
                end
            end
        end
    end

    -- 5. Scintillements : de petites lumières qui traversent le liquide,
    -- naissent et s'éteignent aux deux bouts, clignotent chacune à son rythme.
    local ns = math.max(0, math.min(8, math.floor(c.fl_scintillements or 0)))
    local so = math.max(0, math.min(1, c.fl_scint_opacite or 0))
    if ns > 0 and so > 0 and (d_b - d_a) > 8 then
        local sc = c.fl_scint_couleur or 0xFFFFFFFF
        local ts = math.max(0.03, math.min(0.9, c.fl_scint_taille or 0.16))
        local sv = c.fl_scint_vitesse or 0.35
        local demi = math.max(0.8, ts * h * 0.5)
        for b = 1, ns do
            local graine = b * 1.6180339887
            local fr = graine - math.floor(graine)
            local ph = mnow * sv * (0.75 + 0.5 * fr) + fr
            ph = ph - math.floor(ph)
            local env = math.sin(ph * math.pi)
            env = env * env
            local cl = 0.55 + 0.45 * math.sin(mnow * (2.1 + 1.7 * fr) + graine * 6.0)
            local amp = env * cl
            if amp > 0.04 then
                local d = d_a + ph * (d_b - d_a)
                local a = 255 * so * amp * alpha
                local cc = 0.33 + 0.15 * math.sin(mnow * (0.9 + fr) + graine)
                cc = math.max(ts * 0.7, math.min(1 - ts * 0.7, cc))
                local base = sc & 0xFFFFFF
                FL.trait(ctx, d - demi * 0.45, d + demi * 0.45, cc - ts * 0.22, cc + ts * 0.22,
                    (math.floor(a * 0.55) << 24) | base, 2)
                FL.trait(ctx, d - demi, d + demi, cc - ts * 0.42, cc + ts * 0.42,
                    (math.floor(a * 0.22) << 24) | base, 2.5)
                FL.trait(ctx, d - demi * 4.5, d - demi * 0.6, cc - ts * 0.30, cc + ts * 0.30,
                    (math.floor(a * 0.07) << 24) | base, 3)
            end
        end
    end

    -- 6. Crête de surface : la lumière au bout du liquide, qui ondule.
    if c.fl_crete and (c.fl_crete_intensite or 0) > 0 and d_b < total - 0.5 then
        local ci = math.max(0, math.min(1, c.fl_crete_intensite))
        local cw = math.max(2, (c.fl_crete_largeur or 12) * ech)
        local ond = math.max(0, math.min(2, c.fl_ondulation or 0)) * 2.5 * ech
        local ov = c.fl_ondulation_vitesse or 1.6
        local tete = d_b - ond * (0.5 - 0.5 * math.cos(mnow * ov * deux_pi))
        tete = math.max(d_a, math.min(d_b, tete))
        local cc = c.fl_crete_couleur or 0xFFEAFFE6
        local a = math.floor(255 * ci * 0.11 * alpha)
        if a > 0 then
            for j = 1, 5 do
                local k = 1 - (j - 1) * 0.18
                local len = cw * k * k
                FL.trait(ctx, math.max(d_a, tete - len), tete,
                    0.04 + 0.04 * (j - 1), 0.84 - 0.05 * (j - 1), (a << 24) | (cc & 0xFFFFFF), 3)
            end
        end
        local a2 = math.floor(255 * ci * 0.45 * alpha)
        if a2 > 0 then
            FL.trait(ctx, math.max(d_a, tete - 1.8 * ech), tete, 0.02, 0.92,
                (a2 << 24) | (cc & 0xFFFFFF), 2)
        end
    end
end

-- Une colonne de liquide : les bandes de l'épaisseur, relief et vernis fondus
-- dans la couleur de base (un seul rectangle par bande).
function FL.bandes_liquide(ctx, d1, d2, base, prof, bandes, inv, alpha)
    if bandes <= 1 then
        FL.trait(ctx, d1, d2, 0, 1, FL.opacite(base, alpha), 2.5)
        return
    end
    for i = 0, bandes - 1 do
        local c = FL.lumiere(base, prof[i + 1])
        FL.trait(ctx, d1, d2, i * inv, (i + 1) * inv, FL.opacite(c, alpha), 2.5)
    end
end

-- ----------------------------------------------------------------------------
-- STYLES D'INTERFACE. Un style n'écrit QUE l'apparence (couleurs de la jauge
-- et réglages du liquide). Il ne touche jamais la position, la longueur, la
-- hauteur, la forme, ni les cases d'affichage : ton placement et ta forme
-- restent les tiens quand tu changes de style.
-- Couleurs au format du jeu d'affichage : 0xAABBGGRR.
-- ----------------------------------------------------------------------------
FL.styles = {
    -- Le rendu d'avant la v0.45 : fond ardoise, remplissage khaki, jaune vif quand tout est prêt.
    { nom = "Default (Shards cyan)", valeurs = {
        jauge_col_fond = 0xB0282831, jauge_col_fond2 = 0xB0273853, jauge_col_partiel = 0xE066ADB9,
        jauge_col_partiel2 = 0xC0636380, jauge_col_pret = 0xFF4FE2FF, jauge_col_pret2 = 0xFF1090C8,
        jauge_col_contour = 0xFF6B9D9D, jauge_col_contour2 = 0xFF3A5068, fl_couleur_1 = 0xFF223A3E,
        fl_couleur_2 = 0xFF52838A, fl_couleur_3 = 0xFF66ADB9, fl_couleur_4 = 0xFF3C656B,
        fl_couleur_pret_1 = 0xFF1E7A8A, fl_couleur_pret_2 = 0xFF3CC2D9, fl_couleur_pret_3 = 0xFF4FE2FF,
        fl_couleur_pret_4 = 0xFF2AA8C8, fl_vitesse = 26.0, fl_longueur_onde = 300.0, fl_turbulence = 0.40,
        fl_volume = 0.70, fl_vernis = 0.55, fl_reflets = 2, fl_reflet_vitesse = 0.30,
        fl_reflet_largeur = 70.0, fl_reflet_intensite = 0.40, fl_reflet_couleur = 0xFFFFFFFF,
        fl_scintillements = 4, fl_scint_taille = 0.16, fl_scint_vitesse = 0.35, fl_scint_opacite = 0.70,
        fl_scint_couleur = 0xFFFFFFFF, fl_crete = true, fl_crete_largeur = 12.0, fl_crete_intensite = 0.75,
        fl_crete_couleur = 0xFFE0F6FF, fl_ondulation = 0.50, fl_ondulation_vitesse = 1.60, fl_halo = false,
        fl_halo_couleur = 0xFF4FE2FF, fl_halo_vitesse = 0.55, fl_halo_taille = 14.0,
        fl_halo_intensite = 0.55, fl_halo_min = 0.35, fl_halo_traversant = 0.25,
    } },
    { nom = "Custom" },
    -- La jauge Drive de Kingdom Hearts 2 : or chaud en remplissage, vert MAX quand tous les éclats sont prêts, contour noir franc.
    { nom = "Kingdom Hearts 2 - Drive (doré)", valeurs = {
        jauge_col_fond = 0xE0101010, jauge_col_fond2 = 0xE0000000, jauge_col_partiel = 0xFF2AFCFD,
        jauge_col_partiel2 = 0xFF2AA0FE, jauge_col_pret = 0xFF46F954, jauge_col_pret2 = 0xFF2AA02E,
        jauge_col_contour = 0xFF000000, jauge_col_contour2 = 0xFF000000, fl_couleur_1 = 0xFF128AFE,
        fl_couleur_2 = 0xFF2AC7FE, fl_couleur_3 = 0xFF2AFCFD, fl_couleur_4 = 0xFF2AB4FE,
        fl_couleur_pret_1 = 0xFF1E8B2E, fl_couleur_pret_2 = 0xFF46F954, fl_couleur_pret_3 = 0xFFC8FF9E,
        fl_couleur_pret_4 = 0xFF34C23F, fl_vitesse = 30.0, fl_longueur_onde = 230.0, fl_turbulence = 0.30,
        fl_volume = 0.92, fl_vernis = 0.80, fl_reflets = 3, fl_reflet_vitesse = 0.38,
        fl_reflet_largeur = 55.0, fl_reflet_intensite = 0.55, fl_reflet_couleur = 0xFFE8FFFF,
        fl_scintillements = 5, fl_scint_taille = 0.15, fl_scint_vitesse = 0.45, fl_scint_opacite = 0.75,
        fl_scint_couleur = 0xFFC8FFFF, fl_crete = true, fl_crete_largeur = 13.0, fl_crete_intensite = 0.85,
        fl_crete_couleur = 0xFFD0F8FF, fl_ondulation = 0.50, fl_ondulation_vitesse = 1.80, fl_halo = true,
        fl_halo_couleur = 0xFF2AC7FE, fl_halo_vitesse = 0.60, fl_halo_taille = 13.0,
        fl_halo_intensite = 0.50, fl_halo_min = 0.35, fl_halo_traversant = 0.22,
    } },
    -- Vert plastique très brillant, lumière verte qui respire.
    { nom = "Kingdom Hearts 1 (vert)", valeurs = {
        jauge_col_fond = 0xD0141E14, jauge_col_fond2 = 0xD00A140A, jauge_col_partiel = 0xFF5ED149,
        jauge_col_partiel2 = 0xFF206616, jauge_col_pret = 0xFF8CF07F, jauge_col_pret2 = 0xFF369A25,
        jauge_col_contour = 0xFF000000, jauge_col_contour2 = 0xFF000000, fl_couleur_1 = 0xFF206616,
        fl_couleur_2 = 0xFF5ED149, fl_couleur_3 = 0xFFCDF8C9, fl_couleur_4 = 0xFF369A25,
        fl_couleur_pret_1 = 0xFF4AA02A, fl_couleur_pret_2 = 0xFF8CF07F, fl_couleur_pret_3 = 0xFFE8FFE8,
        fl_couleur_pret_4 = 0xFF6AC855, fl_vitesse = 22.0, fl_longueur_onde = 260.0, fl_turbulence = 0.30,
        fl_volume = 0.90, fl_vernis = 0.75, fl_reflets = 2, fl_reflet_vitesse = 0.22,
        fl_reflet_largeur = 80.0, fl_reflet_intensite = 0.45, fl_reflet_couleur = 0xFFFFFFFF,
        fl_scintillements = 4, fl_scint_taille = 0.17, fl_scint_vitesse = 0.32, fl_scint_opacite = 0.75,
        fl_scint_couleur = 0xFFFFFFFF, fl_crete = true, fl_crete_largeur = 12.0, fl_crete_intensite = 0.80,
        fl_crete_couleur = 0xFFE8FFEF, fl_ondulation = 0.45, fl_ondulation_vitesse = 1.40, fl_halo = true,
        fl_halo_couleur = 0xFF70E05B, fl_halo_vitesse = 0.50, fl_halo_taille = 16.0,
        fl_halo_intensite = 0.60, fl_halo_min = 0.30, fl_halo_traversant = 0.30,
    } },
    -- Sobre et organique : vert pâle du jeu, flux lent, peu de brillance ; turquoise quand tout est prêt.
    { nom = "Dragon's Dogma 2", valeurs = {
        jauge_col_fond = 0xB01C2418, jauge_col_fond2 = 0xB0101810, jauge_col_partiel = 0xFF527F4E,
        jauge_col_partiel2 = 0xFF24351C, jauge_col_pret = 0xFFAED6B4, jauge_col_pret2 = 0xFF34522E,
        jauge_col_contour = 0xFF46684A, jauge_col_contour2 = 0xFF24351C, fl_couleur_1 = 0xFF24351C,
        fl_couleur_2 = 0xFF527F4E, fl_couleur_3 = 0xFFAED6B4, fl_couleur_4 = 0xFF34522E,
        fl_couleur_pret_1 = 0xFF868C2E, fl_couleur_pret_2 = 0xFFB4C86E, fl_couleur_pret_3 = 0xFFF8FFE8,
        fl_couleur_pret_4 = 0xFF9AA84A, fl_vitesse = 14.0, fl_longueur_onde = 420.0, fl_turbulence = 0.18,
        fl_volume = 0.80, fl_vernis = 0.30, fl_reflets = 1, fl_reflet_vitesse = 0.18,
        fl_reflet_largeur = 110.0, fl_reflet_intensite = 0.22, fl_reflet_couleur = 0xFFE0F4FF,
        fl_scintillements = 2, fl_scint_taille = 0.13, fl_scint_vitesse = 0.22, fl_scint_opacite = 0.45,
        fl_scint_couleur = 0xFFE8FFF4, fl_crete = true, fl_crete_largeur = 8.0, fl_crete_intensite = 0.45,
        fl_crete_couleur = 0xFFEAFFF2, fl_ondulation = 0.30, fl_ondulation_vitesse = 1.0, fl_halo = false,
        fl_halo_couleur = 0xFF8BC97F, fl_halo_vitesse = 0.40, fl_halo_taille = 10.0,
        fl_halo_intensite = 0.35, fl_halo_min = 0.40, fl_halo_traversant = 0.12,
    } },
    -- Ambre et bronze, parchemin : chaud, cuivré, plus clair quand tout est prêt.
    { nom = "Dragon's Dogma 1", valeurs = {
        jauge_col_fond = 0xC01A1414, jauge_col_fond2 = 0xC00E0A08, jauge_col_partiel = 0xFF1F76C8,
        jauge_col_partiel2 = 0xFF0C2A5A, jauge_col_pret = 0xFF78C8F2, jauge_col_pret2 = 0xFF12448A,
        jauge_col_contour = 0xFF3C62A0, jauge_col_contour2 = 0xFF18304E, fl_couleur_1 = 0xFF0C2A5A,
        fl_couleur_2 = 0xFF1F76C8, fl_couleur_3 = 0xFF78C8F2, fl_couleur_4 = 0xFF12448A,
        fl_couleur_pret_1 = 0xFF12448A, fl_couleur_pret_2 = 0xFF4AB4FF, fl_couleur_pret_3 = 0xFFB8E9FF,
        fl_couleur_pret_4 = 0xFF1F76C8, fl_vitesse = 32.0, fl_longueur_onde = 240.0, fl_turbulence = 0.45,
        fl_volume = 0.85, fl_vernis = 0.45, fl_reflets = 2, fl_reflet_vitesse = 0.28,
        fl_reflet_largeur = 60.0, fl_reflet_intensite = 0.45, fl_reflet_couleur = 0xFFB0E6FF,
        fl_scintillements = 3, fl_scint_taille = 0.15, fl_scint_vitesse = 0.28, fl_scint_opacite = 0.60,
        fl_scint_couleur = 0xFFB0E6FF, fl_crete = true, fl_crete_largeur = 14.0, fl_crete_intensite = 0.70,
        fl_crete_couleur = 0xFFB8E9FF, fl_ondulation = 0.60, fl_ondulation_vitesse = 1.30, fl_halo = false,
        fl_halo_couleur = 0xFF4AB4FF, fl_halo_vitesse = 0.50, fl_halo_taille = 12.0,
        fl_halo_intensite = 0.45, fl_halo_min = 0.35, fl_halo_traversant = 0.18,
    } },
    -- Dessin animé : couleurs franches, gros reflets, contour blanc ; doré éclatant quand tout est prêt.
    { nom = "Dragon Quest", valeurs = {
        jauge_col_fond = 0xD01A1008, jauge_col_fond2 = 0xD00A0804, jauge_col_partiel = 0xFF4AC237,
        jauge_col_partiel2 = 0xFF1E6B0E, jauge_col_pret = 0xFF4AE0F2, jauge_col_pret2 = 0xFF30B0C8,
        jauge_col_contour = 0xFFFFFFFF, jauge_col_contour2 = 0xFFB0B0B0, fl_couleur_1 = 0xFF1E6B0E,
        fl_couleur_2 = 0xFF4AC237, fl_couleur_3 = 0xFF9EFFC8, fl_couleur_4 = 0xFF2E8F1E,
        fl_couleur_pret_1 = 0xFF167A8F, fl_couleur_pret_2 = 0xFF4AE0F2, fl_couleur_pret_3 = 0xFFC8FFFF,
        fl_couleur_pret_4 = 0xFF30B0C8, fl_vitesse = 60.0, fl_longueur_onde = 180.0, fl_turbulence = 0.55,
        fl_volume = 0.95, fl_vernis = 0.85, fl_reflets = 3, fl_reflet_vitesse = 0.50,
        fl_reflet_largeur = 50.0, fl_reflet_intensite = 0.60, fl_reflet_couleur = 0xFFFFFFFF,
        fl_scintillements = 6, fl_scint_taille = 0.20, fl_scint_vitesse = 0.55, fl_scint_opacite = 0.85,
        fl_scint_couleur = 0xFFFFFFFF, fl_crete = true, fl_crete_largeur = 16.0, fl_crete_intensite = 0.90,
        fl_crete_couleur = 0xFFFFFFFF, fl_ondulation = 0.90, fl_ondulation_vitesse = 2.20, fl_halo = false,
        fl_halo_couleur = 0xFF8CE07B, fl_halo_vitesse = 0.70, fl_halo_taille = 12.0,
        fl_halo_intensite = 0.50, fl_halo_min = 0.30, fl_halo_traversant = 0.20,
    } },
}
FL.CLES_STYLE = {}
for cle in pairs(FL.styles[1].valeurs) do FL.CLES_STYLE[#FL.CLES_STYLE + 1] = cle end
table.sort(FL.CLES_STYLE)
function FL.noms()
    local out = {}
    for i, s in ipairs(FL.styles) do out[i] = s.nom end
    return out
end
function FL.index(nom)
    for i, s in ipairs(FL.styles) do if s.nom == nom then return i end end
    return 2
end

-- Applique un style : écrit seulement ses propres clés d'apparence.
function FL.appliquer(nom)
    for _, s in ipairs(FL.styles) do
        if s.nom == nom and s.valeurs then
            for cle, val in pairs(s.valeurs) do
                if defauts[cle] ~= nil and type(cfg[cle]) == type(val) then cfg[cle] = val end
            end
            return true
        end
    end
    return false
end
-- Dès qu'un réglage d'apparence est modifié à la main, le style devient « Custom ».
function FL.devient_custom()
    if cfg.style ~= "Custom" then
        cfg.style = "Custom"
        evenement("style d'interface : Custom (un réglage d'apparence a été modifié)")
    end
end
-- Première installation de la v0.45 : les anciennes couleurs sont mises de côté
-- dans un preset, puis le style doré est appliqué.
if (cfg.fl_version or 0) < 45 then
    if PRESETS.info("avant_v045") == nil then
        cfg.style, cfg.fl_actif = "Custom", false      -- l'instantané rend exactement la v0.44
        PRESETS.sauver("avant_v045", "Avant la v0.45")
    end
    FL.appliquer("Kingdom Hearts 2 - Drive (doré)")
    cfg.style = "Kingdom Hearts 2 - Drive (doré)"
    cfg.fl_actif = true
    cfg.fl_version = 45
    sauver()
    evenement("v0.45 : style « Kingdom Hearts 2 - Drive (doré) » appliqué ; anciennes couleurs sauvées dans le preset « Avant la v0.45 »")
end

-- Palette du liquide : les couleurs « prêt » quand tous les éclats sont là.
function FL.palette_courante(pret)
    if pret and cfg.fl_pret_palette then
        return { cfg.fl_couleur_pret_1, cfg.fl_couleur_pret_2, cfg.fl_couleur_pret_3, cfg.fl_couleur_pret_4 }
    end
    return { cfg.fl_couleur_1, cfg.fl_couleur_2, cfg.fl_couleur_3, cfg.fl_couleur_4 }
end

-- Remplit un morceau de parcours avec un dégradé vertical (c1 en haut).
function FL.remplir(ctx, d1, d2, c1, c2, alpha)
    if d2 - d1 <= 0.05 then return end
    if c1 == c2 then
        FL.trait(ctx, d1, d2, 0, 1, FL.opacite(c1, alpha), 2.5)
        return
    end
    local n = math.max(2, math.min(ctx.plate and 10 or 5, math.floor(ctx.h / 2)))
    for i = 0, n - 1 do
        FL.trait(ctx, d1, d2, i / n, (i + 1) / n,
            FL.opacite(FL.melange(c1, c2, (i + 0.5) / n), alpha), 2.5)
    end
end

local function dessiner_jauge()
    local apercu = R.hud_apercu_actif()
    -- v0.44 : la position est toujours publiée (la barre d'incantation d'Ultimate Breath of Life s'y accroche)
    local g = R.geo
    local ok, taille = pcall(imgui.get_display_size)
    local sw, sh = 1920, 1080
    if ok and taille then sw, sh = taille.x, taille.y end
    local ech = math.max(0.3, cfg.hud_echelle or 1)
    g.sw, g.sh, g.ech = sw, sh, ech
    g.x, g.y = sw * (cfg.jauge_x + (cfg.hud_dx or 0)), sh * (cfg.jauge_y + (cfg.hud_dy or 0))
    g.w, g.h = cfg.jauge_largeur * ech, cfg.jauge_hauteur * ech
    g.alpha = 0.0
    if not cfg.jauge_visible and not apercu then return end
    pcall(R.hc_brancher)
    local alpha_transition = alpha_jauge()
    if apercu then alpha_transition = 1.0 end
    g.alpha = alpha_transition
    if alpha_transition <= 0.01 then return end
    local gauge_vis = apercu or R.hc_alpha() > 0.01
    local kg = math.max(0, math.min(1, cfg.hud_opacite or 1)) * math.max(0, math.min(1, cfg.jauge_opacite or 1))
    local alpha = gauge_vis and alpha_transition * (apercu and 1.0 or R.hc.alpha) * kg or 0.0
    if alpha <= 0.01 then return end
    local x, y, h = g.x, g.y, g.h
    local pret = unites >= cfg.energie_max
    local kh_actif = R.kh_vu ~= nil and os.clock() - R.kh_vu < 2.0 and not cfg.jauge_avec_kh and not apercu
    if not kh_actif then
        -- v0.45 : un seul parcours pour tous les éclats, quelle que soit la forme
        local forme = cfg.jauge_forme or "segments"
        local n = math.max(1, cfg.energie_max)
        local esp = (cfg.jauge_espacement or 4) * ech
        if forme == "barre" then n, esp = 1, 0 end
        local w = (g.w - esp * (n - 1)) / n
        if w < 2 then w = 2 end
        local ep = math.max(0, math.min(h / 2 - 0.5, (cfg.jauge_contour or 1) * ech))
        local biais = cfg.jauge_biais or 0.35
        local ctx = FL.parcours(x, y, w, h, esp, n, forme, biais)
        -- fond des éclats
        for i = 0, n - 1 do
            FL.remplir(ctx, i * w, (i + 1) * w, cfg.jauge_col_fond, cfg.jauge_col_fond2, alpha)
        end
        -- remplissage
        local frac = math.max(0, math.min(1, unites / math.max(1, cfg.energie_max)))
        local d_b = frac * ctx.total
        if d_b > 0.5 then
            local ci = FL.parcours(x, y + ep, w, math.max(1, h - 2 * ep), esp, n, forme, biais)
            if cfg.fl_actif then
                FL.liquide(ci, 0, d_b, FL.palette_courante(pret), cfg, alpha, ech, os.clock())
            else
                -- remplissage plat à dégradé vertical (comportement d'avant la v0.45)
                local c1 = pret and cfg.jauge_col_pret or cfg.jauge_col_partiel
                local c2 = pret and cfg.jauge_col_pret2 or cfg.jauge_col_partiel2
                for i = 0, n - 1 do
                    local a = i * w + ep
                    local b = math.min((i + 1) * w - ep, d_b)
                    if b > a then FL.remplir(ci, a, b, c1, c2, alpha) end
                end
            end
        end
        -- contour, par-dessus
        if ep > 0 then
            local k1 = FL.opacite(cfg.jauge_col_contour, alpha)
            local k2 = FL.opacite(cfg.jauge_col_contour2, alpha)
            local th = ep / h
            FL.trait(ctx, 0, ctx.total, 0, th, k1, 2.5)
            FL.trait(ctx, 0, ctx.total, 1 - th, 1, k2, 2.5)
            if ctx.plate then
                for i = 0, n - 1 do
                    FL.trait(ctx, i * w, i * w + ep, 0, 1, k1, 2.5)
                    FL.trait(ctx, (i + 1) * w - ep, (i + 1) * w, 0, 1, k2, 2.5)
                end
            end
        end
    end
    if R.message and os.clock() < R.message.fin then
        local a = math.min(1, (R.message.fin - os.clock()) / 0.6)
        R.dtext(R.message.txt, x, y + h + 18, couleur_alpha(0xFF6060FF, alpha * a))
    end
    if cfg.seconde_vie and cfg.jauge_texte_pret and pret and not api.incantation and not kh_actif then
        R.dtext("Éclats de vie prêts", x, y - 16, couleur_alpha(cfg.jauge_col_pret, alpha))
    end
end
local derniere_ecriture = 0
local function ecrire_journal()
    if not journal_sale or maintenant() - derniere_ecriture < 10.0 then return end
    journal_sale = false
    derniere_ecriture = maintenant()
    pcall(json.dump_file, "BardN_ShardsOfLife/journal.json", { version = api.version, journal = evenements })
end

re.on_frame(function()
    R.cadre.ok = false                     -- v0.45 : nouvelle image, cache de lecture vidé
    if not R.impose_fait then R.impose_fait = true; pcall(R.imposer) end
    if not R.voy.talk then pcall(R.voy_brancher) end   -- v0.48 : retry connexion voyante
    if not cfg.actif then R.geo.alpha = 0.0; return end
    pcall(ecrire_journal)
    pcall(mettre_a_jour)
    pcall(R.suivre_seconde_vie)
    pcall(R.suivre_respawn)
    pcall(R.suivre_pierre_choisie)
    pcall(R.suivre_raz)
    pcall(R.seq_tick)                      -- v0.48 : expiration naturelle des Séquelles
    pcall(R.voy_stock_tick)                -- v0.73 : stock d'ingrédients de la voyante (relevé chaque seconde)
    pcall(dessiner_jauge)
    pcall(R.dessiner_panneau_sequelles)    -- v0.48 : barre d'icônes Séquelles + Traumas (branché au Batch 4)
end)

-- ----------------------------------------------------------------------------
-- Menu REFramework : un tiroir principal, des sous-tiroirs
-- ----------------------------------------------------------------------------
local function case(lib, cle)
    local ch, v = imgui.checkbox(lib, cfg[cle])
    if ch then cfg[cle] = v; sauver() end
end
local function curseur_f(lib, cle, mn, mx, f)
    local ch, v = imgui.slider_float(lib, cfg[cle], mn, mx, f or "%.2f")
    if ch then cfg[cle] = v; sauver() end
end
local function curseur_i(lib, cle, mn, mx)
    local ch, v = imgui.slider_int(lib, cfg[cle], mn, mx)
    if ch then cfg[cle] = v; sauver() end
end

-- ----------------------------------------------------------------------------
-- v0.45 : repérage des nouveautés en cyan clair (outil de test, retiré en v1.0)
-- ----------------------------------------------------------------------------
R.CYAN = 0xFFFFC85A
function R.cyan_on() return pcall(function() imgui.push_style_color(0, R.CYAN) end) end
function R.cyan_off(ok) if ok then pcall(function() imgui.pop_style_color(1) end) end end

-- ----------------------------------------------------------------------------
-- v0.45 : réglages qui font partie d'un style (les modifier = passer en Custom)
-- ----------------------------------------------------------------------------
local function case_fl(lib, cle)
    local ch, v = imgui.checkbox(lib, cfg[cle])
    if ch then cfg[cle] = v; FL.devient_custom(); sauver() end
end
local function cur_fl(lib, cle, mn, mx, f)
    local ch, v = imgui.slider_float(lib, cfg[cle], mn, mx, f or "%.2f")
    if ch then cfg[cle] = v; FL.devient_custom(); sauver() end
end
local function cur_fli(lib, cle, mn, mx)
    local ch, v = imgui.slider_int(lib, cfg[cle], mn, mx)
    if ch then cfg[cle] = v; FL.devient_custom(); sauver() end
end
-- couleur simple (sans dégradé) qui appartient au style
function R.couleur_fl(lib, cle)
    local avant = cfg[cle]
    R.hud_selecteur(lib, cle)
    if cfg[cle] ~= avant then FL.devient_custom() end
end

function R.menu_style()
    local noms = FL.noms()
    local chg, nv = imgui.combo("Style d'interface##style", FL.index(cfg.style), noms)
    if chg and noms[nv] then
        cfg.style = noms[nv]
        if noms[nv] ~= "Custom" then FL.appliquer(noms[nv]) end
        sauver()
        evenement("style d'interface : " .. noms[nv])
    end
    imgui.text("Default et Custom en tête, puis les styles de jeux.")
    imgui.text("Un style n'écrit QUE les couleurs et le liquide : la position, la longueur, la hauteur et la forme ne bougent pas.")
    imgui.text("Modifier un réglage d'apparence fait passer le style en Custom.")
    if imgui.button("Réappliquer le style choisi##style_re") then
        FL.appliquer(cfg.style); sauver()
        evenement(R.fmt("style « %s » réappliqué", cfg.style))
    end
    imgui.separator()
    -- FORME : indépendante du style
    local libs, cour = {}, 1
    for i, f in ipairs(FL.FORMES) do
        libs[i] = R.T(FL.FORMES_LIB[f])
        if f == cfg.jauge_forme then cour = i end
    end
    local fc, fv = imgui.combo("Forme de la jauge##forme", cour, libs)
    if fc and FL.FORMES[fv] then
        cfg.jauge_forme = FL.FORMES[fv]; sauver()
        evenement("forme de la jauge : " .. cfg.jauge_forme)
    end
    imgui.text("La forme est indépendante du style : tu peux combiner n'importe quel style avec n'importe quelle forme.")
    if cfg.jauge_forme == "lames" then
        curseur_f("  inclinaison des lames", "jauge_biais", 0.0, 0.6)
    end
    if cfg.jauge_forme == "barre" then
        imgui.text("  (barre continue : le nombre d'éclats ne découpe plus la jauge, le remplissage est progressif)")
    end
end

function R.menu_liquide()
    case_fl("Remplissage liquide (couleurs qui défilent, relief, reflets, scintillements)", "fl_actif")
    if not cfg.fl_actif then
        imgui.text("  (décoché : remplissage plat à dégradé vertical, comme avant la v0.45)")
        return
    end
    local qlibs = { R.T("Élevée (le plus lisse)"), R.T("Moyenne (recommandée)"), R.T("Basse (le plus léger)") }
    local qc, qv = imgui.combo("Qualité de rendu##fl_q", cfg.fl_qualite, qlibs)
    if qc then
        cfg.fl_qualite = qv
        cfg.fl_finesse = (qv == 1 and 1.6) or (qv == 2 and 2.4) or 4.0
        cfg.fl_bandes = (qv == 1 and 0) or (qv == 2 and 0) or 3
        sauver()
    end
    imgui.text("  La qualité ne change que le nombre de traits dessinés, jamais les couleurs.")
    case_fl("Couleurs « prêt » quand tous les éclats sont là", "fl_pret_palette")

    if imgui.tree_node("Écoulement") then
        cur_fl("Vitesse du défilement", "fl_vitesse", 0.0, 120.0, "%.0f")
        cur_fl("Longueur d'onde (px)", "fl_longueur_onde", 40.0, 800.0, "%.0f")
        cur_fl("Remous", "fl_turbulence", 0.0, 1.0)
        cur_fl("Multiplicateur de vitesse (tout ce qui bouge)", "fl_mult_vitesse", 0.0, 5.0)
        imgui.tree_pop()
    end
    if imgui.tree_node("Relief et vernis") then
        cur_fl("Relief (rondeur du liquide)", "fl_volume", 0.0, 1.0)
        cur_fl("Vernis (brillance)", "fl_vernis", 0.0, 1.0)
        cur_fl("Finesse des tranches (px, plus bas = plus lisse et plus coûteux)", "fl_finesse", 1.0, 10.0, "%.1f")
        cur_fli("Bandes dans l'épaisseur (0 = automatique)", "fl_bandes", 0, 12)
        imgui.tree_pop()
    end
    if imgui.tree_node("Reflets") then
        cur_fli("Nombre de reflets", "fl_reflets", 0, 6)
        cur_fl("Vitesse des reflets", "fl_reflet_vitesse", 0.0, 2.0)
        cur_fl("Largeur des reflets (px)", "fl_reflet_largeur", 10.0, 300.0, "%.0f")
        cur_fl("Intensité des reflets", "fl_reflet_intensite", 0.0, 1.0)
        R.couleur_fl("Couleur des reflets##fl_rc", "fl_reflet_couleur")
        imgui.tree_pop()
    end
    if imgui.tree_node("Scintillements") then
        cur_fli("Nombre de lumières", "fl_scintillements", 0, 8)
        cur_fl("Taille des lumières", "fl_scint_taille", 0.03, 0.90)
        cur_fl("Passages par seconde", "fl_scint_vitesse", 0.0, 2.0)
        cur_fl("Luminosité", "fl_scint_opacite", 0.0, 1.0)
        R.couleur_fl("Couleur des lumières##fl_sc", "fl_scint_couleur")
        imgui.tree_pop()
    end
    if imgui.tree_node("Crête de surface") then
        case_fl("Crête au bout du liquide", "fl_crete")
        cur_fl("Largeur de la crête (px)", "fl_crete_largeur", 2.0, 40.0, "%.0f")
        cur_fl("Intensité de la crête", "fl_crete_intensite", 0.0, 1.0)
        cur_fl("Ondulation", "fl_ondulation", 0.0, 2.0)
        cur_fl("Vitesse de l'ondulation", "fl_ondulation_vitesse", 0.0, 4.0)
        R.couleur_fl("Couleur de la crête##fl_cc", "fl_crete_couleur")
        imgui.tree_pop()
    end
    if imgui.tree_node("Lumière lancinante (halo qui respire)") then
        case_fl("Halo autour de la jauge", "fl_halo")
        cur_fl("Vitesse du battement", "fl_halo_vitesse", 0.0, 3.0)
        cur_fl("Taille du halo (px)", "fl_halo_taille", 0.0, 40.0, "%.0f")
        cur_fl("Intensité", "fl_halo_intensite", 0.0, 1.0)
        cur_fl("Luminosité au creux", "fl_halo_min", 0.0, 1.0)
        cur_fl("Lumière traversant le liquide", "fl_halo_traversant", 0.0, 1.0)
        R.couleur_fl("Couleur du halo##fl_hc", "fl_halo_couleur")
        imgui.tree_pop()
    end
    if imgui.tree_node("Couleurs du liquide") then
        imgui.text("Quatre couleurs qui défilent en boucle (éclats pas tous prêts) :")
        R.couleur_fl("Couleur 1##fl_c1", "fl_couleur_1")
        R.couleur_fl("Couleur 2##fl_c2", "fl_couleur_2")
        R.couleur_fl("Couleur 3##fl_c3", "fl_couleur_3")
        R.couleur_fl("Couleur 4##fl_c4", "fl_couleur_4")
        imgui.text("Quatre couleurs quand tous les éclats sont prêts :")
        R.couleur_fl("Couleur 1 (prêt)##fl_p1", "fl_couleur_pret_1")
        R.couleur_fl("Couleur 2 (prêt)##fl_p2", "fl_couleur_pret_2")
        R.couleur_fl("Couleur 3 (prêt)##fl_p3", "fl_couleur_pret_3")
        R.couleur_fl("Couleur 4 (prêt)##fl_p4", "fl_couleur_pret_4")
        imgui.tree_pop()
    end
end

-- v0.45 : textes du style, de la forme et du liquide
for k, v in pairs({
    ["Style d'interface"] = "Interface Style",
    ["Default et Custom en tête, puis les styles de jeux."] = "Default and Custom first, then the game styles.",
    ["Un style n'écrit QUE les couleurs et le liquide : la position, la longueur, la hauteur et la forme ne bougent pas."] = "A style only writes colours and liquid settings: position, length, height and shape never move.",
    ["Modifier un réglage d'apparence fait passer le style en Custom."] = "Changing any appearance setting switches the style to Custom.",
    ["Réappliquer le style choisi"] = "Reapply Selected Style",
    ["Forme de la jauge"] = "Gauge Shape",
    ["La forme est indépendante du style : tu peux combiner n'importe quel style avec n'importe quelle forme."] = "The shape is independent of the style: any style can be combined with any shape.",
    ["  inclinaison des lames"] = "  blade slant",
    ["  (barre continue : le nombre d'éclats ne découpe plus la jauge, le remplissage est progressif)"] = "  (single bar: the shard count no longer splits the gauge, the fill is continuous)",
    ["Segments (rectangles)"] = "Segments (rectangles)",
    ["Éclats (losanges)"] = "Shards (diamonds)",
    ["Orbes (disques)"] = "Orbs (discs)",
    ["Lames (biseautées)"] = "Blades (slanted)",
    ["Barre continue (un seul bloc)"] = "Single continuous bar",
    ["STYLE, FORME ET LIQUIDE"] = "STYLE, SHAPE AND LIQUID",
    ["Remplissage liquide"] = "Liquid Fill",
    ["Remplissage liquide (couleurs qui défilent, relief, reflets, scintillements)"] = "Liquid fill (flowing colours, relief, glints, sparkles)",
    ["  (décoché : remplissage plat à dégradé vertical, comme avant la v0.45)"] = "  (unchecked: flat vertical-gradient fill, as before v0.45)",
    ["Qualité de rendu"] = "Render Quality",
    ["Élevée (le plus lisse)"] = "High (smoothest)",
    ["Moyenne (recommandée)"] = "Medium (recommended)",
    ["Basse (le plus léger)"] = "Low (lightest)",
    ["  La qualité ne change que le nombre de traits dessinés, jamais les couleurs."] = "  Quality only changes how many strokes are drawn, never the colours.",
    ["Couleurs « prêt » quand tous les éclats sont là"] = "\"Ready\" colours when every shard is there",
    ["Écoulement"] = "Flow",
    ["Vitesse du défilement"] = "Flow Speed",
    ["Longueur d'onde (px)"] = "Wavelength (px)",
    ["Remous"] = "Turbulence",
    ["Multiplicateur de vitesse (tout ce qui bouge)"] = "Speed Multiplier (everything that moves)",
    ["Relief et vernis"] = "Relief and Gloss",
    ["Relief (rondeur du liquide)"] = "Relief (roundness of the liquid)",
    ["Vernis (brillance)"] = "Gloss",
    ["Finesse des tranches (px, plus bas = plus lisse et plus coûteux)"] = "Slice Fineness (px, lower = smoother and costlier)",
    ["Bandes dans l'épaisseur (0 = automatique)"] = "Bands Across the Thickness (0 = automatic)",
    ["Reflets"] = "Glints",
    ["Nombre de reflets"] = "Number of Glints",
    ["Vitesse des reflets"] = "Glint Speed",
    ["Largeur des reflets (px)"] = "Glint Width (px)",
    ["Intensité des reflets"] = "Glint Intensity",
    ["Couleur des reflets"] = "Glint Colour",
    ["Scintillements"] = "Sparkles",
    ["Nombre de lumières"] = "Number of Lights",
    ["Taille des lumières"] = "Light Size",
    ["Passages par seconde"] = "Passes per Second",
    ["Luminosité"] = "Brightness",
    ["Couleur des lumières"] = "Light Colour",
    ["Crête de surface"] = "Surface Crest",
    ["Crête au bout du liquide"] = "Crest at the End of the Liquid",
    ["Largeur de la crête (px)"] = "Crest Width (px)",
    ["Intensité de la crête"] = "Crest Intensity",
    ["Ondulation"] = "Wobble",
    ["Vitesse de l'ondulation"] = "Wobble Speed",
    ["Couleur de la crête"] = "Crest Colour",
    ["Lumière lancinante (halo qui respire)"] = "Throbbing Light (breathing halo)",
    ["Halo autour de la jauge"] = "Halo Around the Gauge",
    ["Vitesse du battement"] = "Beat Speed",
    ["Taille du halo (px)"] = "Halo Size (px)",
    ["Intensité"] = "Intensity",
    ["Luminosité au creux"] = "Brightness at the Trough",
    ["Lumière traversant le liquide"] = "Light Through the Liquid",
    ["Couleur du halo"] = "Halo Colour",
    ["Couleurs du liquide"] = "Liquid Colours",
    ["Quatre couleurs qui défilent en boucle (éclats pas tous prêts) :"] = "Four colours flowing in a loop (shards not all ready):",
    ["Quatre couleurs quand tous les éclats sont prêts :"] = "Four colours when every shard is ready:",
    ["Couleur 1"] = "Colour 1",
    ["Couleur 2"] = "Colour 2",
    ["Couleur 3"] = "Colour 3",
    ["Couleur 4"] = "Colour 4",
    ["Couleur 1 (prêt)"] = "Colour 1 (ready)",
    ["Couleur 2 (prêt)"] = "Colour 2 (ready)",
    ["Couleur 3 (prêt)"] = "Colour 3 (ready)",
    ["Couleur 4 (prêt)"] = "Colour 4 (ready)",
    ["Restaurer les réglages d'avant la v0.45"] = "Restore the settings from before v0.45",
    ["Avant la v0.45"] = "Before v0.45",
    ["(nouveau en v0.45)"] = "(new in v0.45)",
    ["Remettre l'apparence et le style par défaut"] = "Reset appearance and style to default",
}) do R.EN[k] = v end

-- v0.42 : tiroir unique « Interface à l'écran (HUD) » : tous les éléments à plat (aucun sous-tiroir à ouvrir sauf les sélecteurs de couleur)
function R.hud_selecteur(lib, cle)
    if not imgui.tree_node(lib) then return end
    local c = math.tointeger(cfg[cle]) or defauts[cle]
    local okp, ch, v = pcall(imgui.color_picker, "Choisir la couleur##cp_" .. cle, c)
    if okp then
        if ch and v ~= nil then cfg[cle] = (math.tointeger(v) or math.floor(v)) & 0xFFFFFFFF; sauver() end
    else
        imgui.text("(sélecteur de couleur indisponible : curseurs Rouge / Vert / Bleu)")
        local cr, cv, cb = c & 0xFF, (c >> 8) & 0xFF, (c >> 16) & 0xFF
        local a1, nr = imgui.slider_int("Rouge##cr_" .. cle, cr, 0, 255)
        local a2, nv = imgui.slider_int("Vert##cv_" .. cle, cv, 0, 255)
        local a3, nb = imgui.slider_int("Bleu##cb_" .. cle, cb, 0, 255)
        if a1 or a2 or a3 then
            cfg[cle] = (c & 0xFF000000) | ((a3 and nb or cb) << 16) | ((a2 and nv or cv) << 8) | (a1 and nr or cr)
            sauver()
        end
    end
    c = math.tointeger(cfg[cle]) or c
    local ach, na = imgui.slider_int("Transparence (0 = invisible, 255 = opaque)##ca_" .. cle, (c >> 24) & 0xFF, 0, 255)
    if ach then cfg[cle] = (na << 24) | (c & 0xFFFFFF); sauver() end
    imgui.tree_pop()
end
function R.hud_couleur(lib, cle)
    if not imgui.tree_node(lib) then return end
    R.hud_selecteur("Couleur du haut##h_" .. cle, cle)
    R.hud_selecteur("Couleur du bas (dégradé)##b_" .. cle, cle .. "2")
    if imgui.button("Même couleur en bas (pas de dégradé)##mm_" .. cle) then cfg[cle .. "2"] = cfg[cle]; sauver() end
    imgui.same_line()
    if imgui.button("Remettre par défaut##cd_" .. cle) then cfg[cle] = defauts[cle]; cfg[cle .. "2"] = defauts[cle .. "2"]; sauver() end
    imgui.tree_pop()
end
function R.menu_hud()
    R.hud.vu = os.clock()
    local ch, v = imgui.checkbox("Aperçu en direct de la jauge tant que ce tiroir est ouvert", R.hud.apercu)
    if ch then R.hud.apercu = v end
    imgui.text("L'aperçu montre la jauge d'éclats même hors combat.")
    imgui.separator()
    imgui.text("RÉGLAGE DE GROUPE (tous les éléments d'un coup)")
    curseur_f("Opacité de la jauge (réglage de groupe)", "hud_opacite", 0.0, 1.0)
    curseur_f("Décalage horizontal de la jauge (fraction de l'écran)", "hud_dx", -0.5, 0.5, "%.3f")
    curseur_f("Décalage vertical de la jauge (fraction de l'écran)", "hud_dy", -0.5, 0.5, "%.3f")
    curseur_f("Échelle de la jauge (la barre d'incantation d'Ultimate Breath of Life la suit)", "hud_echelle", 0.5, 2.5)
    if imgui.button("Remettre le réglage de groupe par défaut##hud_raz") then
        for _, cle in ipairs({ "hud_opacite", "hud_dx", "hud_dy", "hud_echelle" }) do cfg[cle] = defauts[cle] end
        sauver()
    end
    imgui.separator()
    imgui.text("HUD CONTROLS")
    case("Utiliser les règles de HUD Controls (s'il est installé)", "use_hud_controls")
    imgui.text("  état : " .. (cfg.use_hud_controls and R.hc.statut or "désactivé"))
    case("  toujours visible pendant une incantation d'Ultimate Breath of Life", "jauge_visible_incantation")
    imgui.separator()
    -- v0.45 : nouveautés de cette version, écrites en cyan clair (rien n'était
    -- coloré en v0.44 : il n'y a donc rien à remettre en blanc).
    imgui.text("STYLE, FORME ET LIQUIDE")
    R.menu_style()
    local ouv_fl = imgui.tree_node("Remplissage liquide")
    if ouv_fl then
        R.menu_liquide()
        imgui.tree_pop()
    end
    imgui.separator()
    imgui.text("1. JAUGE D'ÉCLATS")
    local vu = R.kh_vu ~= nil and os.clock() - R.kh_vu < 2.0
    imgui.text("Affichage actuel : " .. ((vu and not cfg.jauge_avec_kh) and "orbes de lumière dans BardN_KH_HUD (jauge classique masquée)" or "jauge classique"))
    imgui.text("  (orbes : menu BardN_KH_HUD > Wakestone Counter > Show Life Shard Orbs)")
    case("Afficher la jauge classique", "jauge_visible")
    case("  l'afficher même quand BardN_KH_HUD affiche déjà les orbes (pour la régler / avoir les deux)", "jauge_avec_kh")
    case("  message rouge sous la jauge à chaque perte d'éclat", "jauge_message_perte")
    case("  texte « Éclats de vie prêts » au-dessus de la jauge", "jauge_texte_pret")
    curseur_f("Position horizontale", "jauge_x", 0.0, 1.0)
    curseur_f("Position verticale", "jauge_y", 0.0, 1.0)
    curseur_i("Longueur totale (px)", "jauge_largeur", 60, 900)
    curseur_i("Épaisseur / hauteur des segments (px)", "jauge_hauteur", 3, 60)
    curseur_i("Écart entre les segments (px)", "jauge_espacement", 0, 40)
    curseur_f("Épaisseur du contour (px, 0 = aucun)", "jauge_contour", 0.0, 8.0, "%.1f")
    curseur_f("Opacité de la jauge", "jauge_opacite", 0.05, 1.0)
    imgui.text("  couleurs (couleur du haut + couleur du bas = dégradé vertical) :")
    R.hud_couleur("Fond des segments##jauge_c1", "jauge_col_fond")
    R.hud_couleur("Remplissage (éclats pas tous prêts)##jauge_c2", "jauge_col_partiel")
    R.hud_couleur("Remplissage (tous les éclats prêts)##jauge_c3", "jauge_col_pret")
    R.hud_couleur("Contour##jauge_c4", "jauge_col_contour")
    if imgui.button("Remettre l'apparence et le style par défaut##jauge_raz") then
        for _, cle in ipairs({ "jauge_x", "jauge_y", "jauge_largeur", "jauge_hauteur", "jauge_espacement",
            "jauge_contour", "jauge_opacite", "jauge_forme", "jauge_biais", "style" }) do cfg[cle] = defauts[cle] end
        for _, cle in ipairs(FL.CLES_STYLE) do cfg[cle] = defauts[cle] end
        cfg.fl_version = 45
        sauver()
        evenement("apparence et style remis par défaut")
    end
    imgui.text("(La barre d'incantation, la frange et les cercles se règlent dans BardN Ultimate Breath of Life.)")
end

re.on_draw_ui(function()
    if not imgui.tree_node(NOM) then return end
    imgui.text("Langue / Language :")
    for _, o in ipairs({ { "fr", "Français" }, { "en", "English" }, { "auto", "Auto" } }) do
        imgui.same_line()
        if imgui.button((cfg.langue == o[1] and "[x] " or "[ ] ") .. o[2] .. "##lg" .. o[1]) then R.changer_langue(o[1]) end
    end
    if cfg.langue == "auto" then
        imgui.same_line()
        imgui.text("(" .. (R.langue_jeu == "fr" and "jeu : français" or (R.langue_jeu == "en" and "game: English" or "?")) .. ")")
    end
    case("Mod actif", "actif")
    imgui.text(R.fmt("Éclats de vie : %d / %d   |   %s%s", unites, cfg.energie_max,
        en_combat and "en combat" or "hors combat", api.incantation and "   |   INCANTATION" or ""))
    local ub = rawget(_G, "BardN_UltimateBreathOfLife")
    if type(ub) == "table" then imgui.text(R.fmt("Ultimate Breath of Life détecté (v%s)", tostring(ub.version)))
    else imgui.text("Ultimate Breath of Life non installé (facultatif)") end

    -- 1. PRESETS ---------------------------------------------------------------
    if imgui.tree_node("Presets") then
        for i = 1, 3 do
            local info = R.preset_info("preset_" .. i)
            imgui.text(R.fmt("Preset %d : %s", i, info or "vide"))
            imgui.same_line()
            if imgui.button("Sauver##ps" .. i) then R.preset_sauver("preset_" .. i, "Preset " .. i) end
            if info then
                imgui.same_line()
                if imgui.button("Charger##pc" .. i) then R.preset_charger("preset_" .. i) end
            end
        end
        local avv = R.preset_info("avant_v045")
        if avv then
            imgui.text("Avant la v0.45 : " .. avv)
            imgui.same_line()
            if imgui.button("Restaurer les réglages d'avant la v0.45##pv045") then R.preset_charger("avant_v045") end
        end
        local av = R.preset_info("avant_reset")
        if av then
            imgui.text("Avant la dernière remise par défaut : " .. av)
            imgui.same_line()
            if imgui.button("Restaurer##pr") then R.preset_charger("avant_reset") end
        end
        if R.reset_arme and os.clock() - R.reset_arme < 3 then
            if imgui.button(">>> CONFIRMER : tout remettre par défaut (réglages actuels sauvés avant) <<<") then
                R.reset_arme = nil
                R.preset_sauver("avant_reset", "Avant remise par défaut")
                local langue_gardee = cfg.langue
                for k, v in pairs(defauts) do cfg[k] = v end
                cfg.langue = langue_gardee
                R.imposer()
                sauver()
                evenement("réglages remis par défaut (anciens réglages sauvés)")
            end
        elseif imgui.button("Réglages par défaut…") then
            R.reset_arme = os.clock()
        end
        imgui.tree_pop()
    end

    -- 1b. INTERFACE À L'ÉCRAN (HUD) -----------------------------------------------
    if imgui.tree_node("Interface à l'écran (HUD)") then
        R.menu_hud()
        imgui.tree_pop()
    end

    -- v0.48 : avertissement si BardN_New_Death_System est actif
    if rawget(_G, "BardN_New_Death_System") then
        local cyc2 = R.cyan_on()
        imgui.text(R.T("⚠  BardN New Death System est actif. Les deux mods gèrent les séquelles de façon indépendante."))
        imgui.text(R.T("   Il est recommandé de n'activer qu'un seul des deux systèmes à la fois."))
        R.cyan_off(cyc2)
        imgui.separator()
    end

    -- 7. SÉQUELLES ET TRAUMATISMES (v0.48, repéré en blanc depuis v0.62) ----------
    local ouvert_seq = imgui.tree_node("Séquelles et Traumatismes (v0.48)##seq_tr")
    if ouvert_seq then
        -- Second Breath
        case("Second Breath : utiliser les éclats pour ressusciter avec des Séquelles", "second_breath")
        if cfg.second_breath then
            curseur_i("  seuil de Séquelles avant tirage en rang II", "sb_rang2_seuil", 1, 13)
            imgui.text(R.T("  Table : 1 éclat → 2 Séquelles rang I ; 2 éclats → 1 Séquelle rang I ; 3 éclats → 0 Séquelle"))
            case("  revenir à la vie même à 0 éclat", "sb_zero")
            if cfg.sb_zero then
                imgui.text(R.T("    0 éclat → 3 Séquelles rang I : la survie reste possible, mais elle coûte cher."))
            else
                imgui.text(R.T("    À 0 éclat, aucun recours : l'écran de mort reprend la main."))
            end
            imgui.text(R.T("    Dans tous les cas, les Séquelles déjà subies deviennent des Traumatismes."))
        end
        imgui.separator()

        -- Séquelles actives
        case("Séquelles actives (mécanique principale)", "seq_actif")
        if cfg.seq_actif then
            curseur_i("Durée (jours de jeu avant expiration naturelle)", "seq_jours", 1, 30)
            imgui.separator()
            imgui.text(R.T("Effets actifs (décocher pour désactiver sans supprimer les Séquelles existantes) :"))
            case("  Métabolisme perturbé (soins réduits)", "met_on")
            if cfg.met_on then
                curseur_i("    rang I : −% soins", "met_n1", 5, 90)
                curseur_i("    rang II : −% soins", "met_n2", 5, 95)
            end
            case("  Douleur persistante (+% coût endurance)", "dou_on")
            if cfg.dou_on then
                curseur_i("    rang I : +%", "dou_n1", 5, 100)
                curseur_i("    rang II : +%", "dou_n2", 5, 150)
            end
            case("  Commotion cérébrale (ordres aux pions muets)", "com_on")
            case("  Vitalité diminuée (×jauge blanche / 1000)", "vit_on")
            if cfg.vit_on then
                curseur_i("    rang I : malus HP max", "vit_n1", 50, 2000)
                curseur_i("    rang II : malus HP max", "vit_n2", 50, 3000)
            end
            case("  Fragilité (+% dégâts subis)", "fra_on")
            if cfg.fra_on then
                curseur_i("    rang I : +%", "fra_n1", 5, 100)
                curseur_i("    rang II : +%", "fra_n2", 5, 150)
            end
            case("  Lien perdu (pions non réanimables)", "res_on")
            case("  Faiblesse (−% dégâts infligés)", "fai_on")
            if cfg.fai_on then
                curseur_i("    rang I : −%", "fai_n1", 5, 60)
                curseur_i("    rang II : −%", "fai_n2", 5, 75)
            end
            case("  Instabilité (×déséquilibre subi)", "ins_on")
            if cfg.ins_on then
                curseur_i("    rang I : ×", "ins_n1", 1, 20)
                curseur_i("    rang II : ×", "ins_n2", 1, 30)
            end
            case("  Épuisement (−% endurance max)", "epu_on")
            if cfg.epu_on then
                curseur_i("    rang I : −%", "epu_n1", 5, 80)
                curseur_i("    rang II : −%", "epu_n2", 5, 90)
            end
            case("  Essoufflement (conso endurance ×, nécessite BardN Stamina Fatigue)", "ess_on")
            if cfg.ess_on then
                curseur_i("    rang I : ×", "ess_n1", 2, 10)
                curseur_i("    rang II : ×", "ess_n2", 2, 15)
            end
            case("  Garde défaillante (casse équipement ×, nécessite BardN Enemy Break Equipment)", "gar_on")
            if cfg.gar_on then
                curseur_i("    rang I : ×", "gar_n1", 1, 8)
                curseur_i("    rang II : ×", "gar_n2", 1, 12)
            end
            case("  Dysphagie (consommables bloqués)", "dys_on")
            case("  Surcharge (−% charge max, nécessite BardN RPG Level Up)", "sur_on")
            if cfg.sur_on then
                curseur_i("    rang I : −%", "sur_n1", 5, 60)
                curseur_i("    rang II : −%", "sur_n2", 5, 80)
            end
        end
        imgui.separator()

        -- Traumatismes
        if cfg.voy_actif and R.voy_nb() == 0 then
            local nt_ = 0
            for _ in pairs(R.tr.actives) do nt_ = nt_ + 1 end
            if nt_ > 0 then
                imgui.text_colored(R.fmt("ATTENTION : %d traumatisme(s) actif(s) et aucune voyante désignée.", nt_), R.ROUGE_VOY)
            else
                imgui.text_colored("Aucune voyante désignée : un traumatisme subi ne pourrait pas être soigné.", R.ROUGE_VOY)
            end
            imgui.text("  Ouvre « Voyante active » plus bas pour en désigner une.")
        end
        imgui.text(R.T("Traumatismes : Séquelles permanentes (guérissables uniquement par la Voyante)."))
        imgui.text(R.T("  Déclenchement : Second Breath avec Séquelles actives → Séquelles transformées en Traumatismes."))
        imgui.text(R.T("  Soins : Voyante (Traumatismes seulement) ; les Séquelles guérissent à l'auberge ou à la Pierre de faille."))
        imgui.separator()

        -- Voyante
        case("Voyante active", "voy_actif")
        if cfg.voy_actif then
            curseur_i("  prix d'un Traumatisme niveau I (or, 0 = gratuit)", "voy_prix_tr1", 0, 50000)
            curseur_i("  prix d'un Traumatisme niveau II (or, 0 = gratuit)", "voy_prix_tr2", 0, 100000)
            curseur_i("  recette niveau I : nombre d'ingrédients", "voy_n1_ingr", 1, 5)
            curseur_i("  recette niveau I : valeur min d'un ingrédient", "voy_n1_min", 1, 1000)
            curseur_i("  recette niveau I : valeur max d'un ingrédient", "voy_n1_max", 1, 2000)
            curseur_i("  recette niveau II : nombre d'ingrédients", "voy_n2_ingr", 1, 6)
            curseur_i("  recette niveau II : valeur min d'un ingrédient", "voy_n2_min", 1, 2000)
            curseur_i("  recette niveau II : valeur max d'un ingrédient", "voy_n2_max", 1, 4000)
            imgui.text(R.T("  Branchement voyante : ") ..
                (R.voy.talk and R.T("connectée") or R.T("non connectée (en attente de BardN_Menu ou IGO/GuildTalk)")))
            -- v0.72 : QUI SOIGNE (comme New Death System). Sans voyante désignée, le menu de discussion ne propose rien.
            imgui.separator()
            imgui.text_colored("Qui soigne tes traumatismes", R.CYAN_VOY)
            local nbv = R.voy_nb()
            if nbv == 0 then
                imgui.text_colored("AUCUNE VOYANTE DÉSIGNÉE : tes traumatismes ne peuvent pas être soignés.", R.ROUGE_VOY)
            end
            imgui.text("  Parle à un PNJ en jeu (ouvre son menu de discussion), reviens ici, puis clique sur le bouton ci-dessous.")
            local dp = R.voy.dernier
            if dp then
                imgui.text(R.fmt("  Dernier PNJ à qui tu as parlé : %s (menu %s)", tostring(dp.nom or ("PNJ " .. dp.cid)), tostring(dp.type)))
                if cfg.voy_pnj[dp.cid] == nil then
                    if imgui.button("Ce PNJ est une voyante##voy_add") then
                        cfg.voy_pnj[dp.cid] = tostring(dp.nom or ("PNJ " .. dp.cid)); cfg.voy_retires[dp.cid] = nil; sauver()
                    end
                else
                    imgui.text("  C'est une voyante : les soins s'affichent dans son menu.")
                end
            else
                imgui.text_colored("  Aucun PNJ relevé pour l'instant : va parler à quelqu'un en jeu.", R.GRIS_VOY)
            end
            imgui.text(R.fmt("  Voyantes connues : %d", nbv))
            for k, nom in pairs(cfg.voy_pnj) do
                imgui.text("     " .. tostring(nom) .. "  (PNJ " .. k .. ")")
                imgui.same_line()
                if imgui.button("Retirer##voy_" .. k) then cfg.voy_pnj[k] = nil; cfg.voy_retires[k] = true; sauver() end
            end
            if R.voy_import > 0 then
                imgui.text(R.fmt("  %d voyante(s) ajoutée(s) au lancement (d'origine ou depuis Économie dynamique).", R.voy_import))
            end
            imgui.separator()
            case("  ligne « rien à soigner » chez la voyante quand aucun traumatisme", "voy_vide")
            case("  couleurs personnalisées pour les ingrédients (sinon : grisé du jeu pour ce qui manque)", "voy_couleur_on")
            R.hud_selecteur("  ingrédient qui manque##voy_gris_c", "voy_gris")
            R.hud_selecteur("  ingrédient complet##voy_complet_c", "voy_complet")
        end
        imgui.separator()

        -- HUD Séquelles
        case("Barre d'icônes de séquelles à l'écran", "sx_actif")
        if cfg.sx_actif then
            curseur_f("  position X (fraction écran)", "sx_x", 0.0, 0.95, "%.3f")
            curseur_f("  position Y (fraction écran)", "sx_y", 0.0, 0.98, "%.3f")
            curseur_i("  taille des icônes (px)", "sx_taille", 16, 128)
            curseur_i("  écart entre icônes (px)", "sx_ecart", 0, 40)
            curseur_f("  opacité", "sx_opacite", 0.0, 1.0, "%.2f")
            case("  afficher les jours restants", "sx_jours")
            curseur_i("  opacité du texte (0–100)", "sx_texte", 0, 100)
            R.hud_selecteur("  couleur des Séquelles (barre d'icônes)##sx_c", "sx_couleur")
            R.hud_selecteur("  couleur des Traumatismes (barre d'icônes)##sx_ctr", "sx_couleur_tr")
            case("  label « Traumatisme : » devant les icônes de trauma", "sx_libelle_tr")
            imgui.separator()
            case("  annonce d'une nouvelle Séquelle / Traumatisme au centre-haut", "sx_annonce")
            if cfg.sx_annonce then
                curseur_f("  position Y annonce (fraction écran)", "sx_annonce_y", 0.0, 0.5, "%.3f")
                curseur_i("  durée de l'annonce (secondes)", "sx_annonce_duree", 2, 30)
                curseur_f("  pause entre deux annonces (secondes)", "sx_annonce_pause", 0.5, 5.0, "%.1f")
                curseur_i("  opacité du texte de l'annonce (0–100)", "sx_annonce_texte", 0, 100)
                R.hud_selecteur("  couleur de l'annonce : Séquelle##sx_an_c", "sx_an_couleur")
                R.hud_selecteur("  couleur de l'annonce : Traumatisme##sx_an_ctr", "sx_an_couleur_tr")
                case("  fond de fumée derrière l'annonce", "sx_annonce_fond")
                if cfg.sx_annonce_fond then
                    curseur_i("  opacité du fond (0–100)", "sx_annonce_fond_opacite", 0, 100)
                    local cyc_f = R.cyan_on()
                    curseur_i("  taille du fond (%)", "sx_annonce_fond_echelle", 50, 400)
                    curseur_i("  décalage vertical du fond (px)", "sx_annonce_fond_dy", -100, 100)
                    R.cyan_off(cyc_f)
                end
                -- v0.66 : bouton d'aperçu de l'annonce
                if imgui.button(R.T("Aperçu de l'annonce##sx_an_prev")) then
                    pcall(R.sx_annoncer, "fragilite", 2, false)
                end
                imgui.same_line()
                if imgui.button(R.T("Aperçu (traumatisme)##sx_an_prev_tr")) then
                    pcall(R.sx_annoncer, "fragilite", 2, true)
                end
            end
        end

        -- Panneau de détail au menu pause (v0.63)
        imgui.separator()
        local cyc_det = R.cyan_on()
        case("Afficher le panneau dans le menu pause (nouveau en v0.63)", "det_actif")
        R.cyan_off(cyc_det)
        if not cfg.det_actif then R.det_apercu = false end   -- v0.66 : couper l'aperçu si désactivé
        if cfg.det_actif then
            curseur_f("  position X (%)", "det_x", 0.0, 0.98, "%.2f")
            curseur_f("  position Y (%)", "det_y", 0.0, 0.98, "%.2f")
            curseur_i("  taille du panneau (%)", "det_echelle", 30, 300)
            curseur_i("  taille des icônes (%)", "det_icone", 30, 300)
            curseur_i("  taille du texte (%)", "det_texte", 30, 300)
            curseur_i("  espacement des lignes", "det_espace", 0, 60)
            curseur_f("  opacité du panneau", "det_opacite", 0.05, 1.0, "%.2f")
            case("  en-tête « Séquelles »", "det_entete")
            case("  fond du panneau", "det_fond")
            if cfg.det_fond then R.hud_selecteur("  couleur du fond##det_f", "det_fond_couleur") end
            R.hud_selecteur("  couleur des titres##det_t", "det_titre_couleur")
            R.hud_selecteur("  couleur des Séquelles (panneau pause)##det_sc", "det_seq_couleur")
            R.hud_selecteur("  couleur des Traumatismes (panneau pause)##det_tc", "det_tr_couleur")
            R.hud_selecteur("  couleur des effets##det_e", "det_texte_couleur")
            case("  jours restants", "det_jours")
            case("  remède sous chaque traumatisme (une fois révélé par une voyante)", "det_remede")
            case("  déplaçable à la souris", "det_souris")
            if imgui.button(R.T("Aperçu du panneau (hors pause)##det_prev")) then R.det_apercu = not R.det_apercu end
            if R.det_apercu then imgui.same_line(); imgui.text(R.T("[aperçu actif]")) end
        end

        -- État des Séquelles et Traumatismes actifs
        imgui.separator()
        imgui.text(R.T("État actuel :"))
        local seq_a2 = R.seq and R.seq.actives or {}
        local tr_a2  = R.tr  and R.tr.actives  or {}
        local n_seq, n_tr = 0, 0
        for _ in pairs(seq_a2) do n_seq = n_seq + 1 end
        for _ in pairs(tr_a2)  do n_tr  = n_tr  + 1 end
        imgui.text(R.fmt("  Séquelles : %d    Traumatismes : %d", n_seq, n_tr))
        for id, s in pairs(seq_a2) do
            local lib = R.SEQ_LIB and R.SEQ_LIB[id] and R.T(R.SEQ_LIB[id].nom) or id
            imgui.text(R.fmt("    %s rang %d", lib, s.rang or 1))
        end
        for id, t in pairs(tr_a2) do
            local lib = R.SEQ_LIB and R.SEQ_LIB[id] and R.T(R.SEQ_LIB[id].nom) or id
            imgui.text(R.fmt("    [Trauma] %s rang %d", lib, t.rang or 1))
        end
        if imgui.button(R.T("Guérir toutes les Séquelles (test)##seq_raz")) then
            pcall(R.guerir_sequelles, "menu test")
        end
        imgui.same_line()
        if imgui.button(R.T("Guérir Séquelles + Traumatismes (test)##tr_raz")) then
            pcall(R.guerir_tout, "menu test")
        end

        imgui.tree_pop()
    end

    -- 6. ÉCLATS DE VIE -----------------------------------------------------------
    if imgui.tree_node("Éclats de vie (Shards of Life)") then
        curseur_i("Éclats maximum", "energie_max", 1, 10)
        imgui.text("GAIN : un éclat de vie chaque fois que tu relèves un pion")
        case("  seulement en combat", "reanimation_combat_seul")
        imgui.text("")
        imgui.text("SECONDE VIE")
        case("Tous les éclats = une seconde vie (écran et relevé natifs de la Pierre de Réveil)", "seconde_vie")
        if cfg.seconde_vie then
            case("  un seul écran : Éclats de vie / Pierre de Réveil (N) / Non", "sv_ecran_unique")
            if not cfg.sv_ecran_unique then case("  si je refuse les éclats, proposer ensuite la Pierre de Réveil", "sv_puis_pierre") end
        end
        imgui.text("")
        imgui.text(R.T("MORT SANS RECOURS"))
        case("  retour direct à la dernière auberge (plus de choix de chargement)", "mort_auberge")
        imgui.text(R.T("  Sinon, l'écran « Cette histoire est terminée » et ses 4 options restent."))
        imgui.text("")
        imgui.text("COMPATIBILITÉ « BardN Death System »")
        case("  « Non » à l'écran de mort = réapparition à la dernière pierre de faille (au lieu du menu de chargement)", "respawn_compat")
        imgui.text(R.respawn_present() and "  état : BardN Death System détecté" or "  état : BardN Death System non détecté (« Non » ouvre le menu de chargement)")
        imgui.text("")
        imgui.text("REMISE À ZÉRO DES ÉCLATS")
        case("après une nuit (auberge, feu de camp)", "raz_repos")
        if cfg.raz_repos then curseur_f("  heures de jeu minimales passées (hors feu de camp)", "raz_repos_heures", 0.0, 6.0, "%.1f") end
        case("après une Pierre de Réveil", "raz_transpierre")
        case("après un voyage (char à bœufs, téléportation)", "raz_voyage")
        imgui.text("")
        imgui.text("(La jauge à l'écran se règle dans le tiroir « Interface à l'écran (HUD) ».)")
        imgui.text("(Les ultimes — Breath of Life, Slow Time — sont dans le mod BardN Ultimate Breath of Life.)")
        imgui.tree_pop()
    end


    -- 2. OUTILS DE TEST ----------------------------------------------------------
    local cyc_outils = R.cyan_on()
    local ouv_outils = imgui.tree_node(R.T("Outils de test") .. " (v0.63)##outils")
    R.cyan_off(cyc_outils)
    if ouv_outils then

        -- 2a. Éclats de vie ---
        if imgui.tree_node(R.T("Éclats de vie") .. "##dbg_eclats") then
            if imgui.button("- 1 éclat") then ajuster(-1, "bouton de test (-1)") end
            imgui.same_line()
            if imgui.button("+ 1 éclat") then ajuster(1, "bouton de test (+1)") end
            imgui.same_line()
            if imgui.button("Remplir") then ajuster(cfg.energie_max, "bouton de test") end
            imgui.same_line()
            if imgui.button("Vider") then ajuster(-cfg.energie_max, "bouton de test") end
            imgui.tree_pop()
        end

        -- 2b. Déclencher des séquelles ---
        if imgui.tree_node(R.T("Déclencher des séquelles") .. "##dbg_seq") then
            if imgui.button(R.T("Séquelle au hasard (rang I)")) then
                R.seq_tirage(1, "outil de test (hasard)")
            end
            imgui.same_line()
            if imgui.button(R.T("Séquelle au hasard (rang max)")) then
                local l = {}
                for _, d in ipairs(R.SEQ_LIB) do l[#l + 1] = d end
                if #l > 0 then
                    local d = l[math.random(1, #l)]
                    for _ = 1, d.niveaux do R.seq_appliquer(d.id, "test (rang max)") end
                end
            end
            imgui.separator()
            imgui.text(R.T("Par nom (un bouton = appliquer rang I, clic supplémentaire = aggrave) :"))
            local premier = true
            for _, d in ipairs(R.SEQ_LIB) do
                if not premier then imgui.same_line() end
                premier = false
                if imgui.button(R.T(d.nom) .. "##t_" .. d.id) then
                    R.seq_appliquer(d.id, "outil de test")
                end
            end
            imgui.tree_pop()
        end

        -- 2c. Transformer en traumatismes ---
        if imgui.tree_node(R.T("Transformer en traumatismes") .. "##dbg_tr") then
            if imgui.button(R.T("Toutes les séquelles → Traumatismes")) then
                R.transformer_sequelles_en_traumas()
            end
            imgui.separator()
            imgui.text(R.T("Par nom (transforme la séquelle active en traumatisme) :"))
            local premier = true
            for _, d in ipairs(R.SEQ_LIB) do
                if R.seq.actives[d.id] then
                    if not premier then imgui.same_line() end
                    premier = false
                    if imgui.button(R.T(d.nom) .. " → Tr##tr_" .. d.id) then
                        local a = R.seq.actives[d.id]
                        local niveau = a.niveau or 1
                        local prev = R.tr.actives[d.id]
                        local nv2 = (prev and math.max(prev.niveau or 1, niveau)) or niveau
                        R.tr.actives[d.id] = { niveau = nv2, depuis = R.heure_jeu() or 0, recette = {}, revele = false }
                        R.seq.actives[d.id] = nil
                        pcall(seq_sauver); pcall(tr_sauver)
                        pcall(seq_annoncer, d.id, R.T("Traumatisme") .. " : " .. R.T(d.nom), "", true)
                        pcall(R.sx_annoncer, d.id, nv2, true)
                    end
                end
            end
            if premier then imgui.text(R.T("  Aucune séquelle active.")) end
            imgui.tree_pop()
        end

        -- 2d. Guérison ---
        if imgui.tree_node(R.T("Guérison") .. "##dbg_guerir") then
            if imgui.button(R.T("Tout guérir (séquelles + traumas)")) then
                R.guerir_tout("bouton de test")
            end
            imgui.separator()
            -- Guérir une séquelle précise
            for _, d in ipairs(R.SEQ_LIB) do
                if R.seq.actives[d.id] then
                    if imgui.button(R.T("Guérir : ") .. R.T(d.nom) .. "##gs_" .. d.id) then
                        R.seq_guerir(d.id, "outil de test")
                    end
                    imgui.same_line()
                end
            end
            -- Guérir un trauma précis
            for _, d in ipairs(R.SEQ_LIB) do
                if R.tr.actives[d.id] then
                    if imgui.button(R.T("Guérir trauma : ") .. R.T(d.nom) .. "##gt_" .. d.id) then
                        R.tr_guerir(d.id, "outil de test")
                    end
                    imgui.same_line()
                end
            end
            imgui.text("")  -- retour à la ligne après les same_line
            imgui.tree_pop()
        end

        -- 2e. État en cours ---
        if imgui.tree_node(R.T("État en cours") .. "##dbg_etat") then
            local n_seq, n_tr = 0, 0
            for _, d in ipairs(R.SEQ_LIB) do
                local a = R.seq.actives[d.id]
                if a then
                    n_seq = n_seq + 1
                    imgui.text("  • " .. R.seq_texte(d.id))
                end
            end
            if n_seq == 0 then imgui.text(R.T("  Aucune séquelle active.")) end
            imgui.separator()
            for _, d in ipairs(R.SEQ_LIB) do
                local a = R.tr.actives[d.id]
                if a then
                    n_tr = n_tr + 1
                    imgui.text("  ★ " .. R.tr_texte(d.id))
                end
            end
            if n_tr == 0 then imgui.text(R.T("  Aucun traumatisme actif.")) end
            imgui.tree_pop()
        end

        -- 2f. Écran de mort (déclenchement + diagnostic du blocage) ---
        if imgui.tree_node(R.T("Écran de mort") .. "##dbg_mort") then
            imgui.text(R.T("Pendant l'écran de mort, forcer le choix à la main :"))
            local function _t()
                local t = (R.mort or {}).this
                if not t then R.mort_diag.maj = R.T("aucune instance : le hook ne s'est jamais déclenché") end
                return t
            end
            if imgui.button(R.T("Valider : dernière auberge")) then
                local t = _t(); if t then R.mort.fait = false; R.mort_valider(t, 2, "manuel") end
            end
            imgui.same_line()
            if imgui.button(R.T("Valider : écran titre")) then
                local t = _t(); if t then R.mort.fait = false; R.mort_valider(t, 3, "manuel") end
            end
            imgui.separator()
            imgui.text(R.T("Faire apparaître l'écran « Cette histoire est terminée » :"))
            if imgui.button(R.T("Forcer l'écran de mort (phase 40)")) then
                local mfm = sdk.get_managed_singleton("app.MainFlowManager")
                local fait = false
                if mfm then
                    -- Plusieurs signatures possibles : on tente dans l'ordre.
                    for _, sig in ipairs({ "changeFlowPhase(app.MainFlowManager.Phase)",
                                           "changeFlowPhase(System.Int32)",
                                           "changeFlowPhase" }) do
                        local ok = pcall(function() mfm:call(sig, 40) end)
                        if ok then R.mort_diag.decl = sig; fait = true; break end
                    end
                end
                if not fait then R.mort_diag.decl = R.T("échec : aucune signature acceptée") end
            end
            imgui.same_line()
            if imgui.button(R.T("Phase 42 (GameOver)")) then
                local mfm = sdk.get_managed_singleton("app.MainFlowManager")
                local fait = false
                if mfm then
                    for _, sig in ipairs({ "changeFlowPhase(app.MainFlowManager.Phase)",
                                           "changeFlowPhase(System.Int32)",
                                           "changeFlowPhase" }) do
                        local ok = pcall(function() mfm:call(sig, 42) end)
                        if ok then R.mort_diag.decl = sig .. " (42)"; fait = true; break end
                    end
                end
                if not fait then R.mort_diag.decl = R.T("échec : aucune signature acceptée") end
            end
            imgui.text(R.T("Déclenchement : ") .. tostring((R.mort_diag or {}).decl or "-"))
            imgui.text(R.T("(Si rien ne se passe, meurs normalement : le diagnostic ci-dessous"))
            imgui.text(R.T(" se remplit quand même pendant le vrai écran de mort.)"))
            imgui.separator()
            local d = R.mort_diag or {}
            imgui.text(R.T("Accrochage pose : ") .. tostring(d.pose or "-"))
            imgui.text(R.T("Appels du hook : ") .. tostring(d.hooks or 0))
            imgui.text(R.T("Phase du jeu : ") .. tostring(d.phase or "-"))
            imgui.text(R.T("FlowNow : ") .. tostring(d.flow or "-"))
            imgui.text(R.T("IsWaitInput : ") .. tostring(d.att or "-"))
            imgui.text(R.T("1re option lue : ") .. tostring(d.sel0 or "-"))
            imgui.text(R.T("Dernière action : ") .. tostring(d.maj or "-"))
            imgui.text(R.T("Ret (choix validé) : ") .. tostring(d.ret or "-"))
            imgui.text(R.T("(Ces valeurs se remplissent pendant l'écran de mort.)"))
            imgui.tree_pop()
        end

        -- 2g. Journal ---
        if imgui.tree_node(R.T("Journal") .. "##dbg_journal") then
            for _, ev in ipairs(evenements) do imgui.text(ev) end
            imgui.tree_pop()
        end

        imgui.tree_pop()
    end
    imgui.tree_pop()
end)

-- ============================================================================
-- v0.62 — MORT : RETOUR DIRECT À LA DERNIÈRE AUBERGE
-- Sur l'écran « Cette histoire est terminée », au lieu de laisser le joueur
-- choisir, on sélectionne pour lui la 3ᵉ option (« Charger depuis la dernière
-- auberge »). Le jeu suit ensuite SON propre chemin de chargement : aucun
-- risque d'écran noir figé, contrairement à une annulation de choix.
--
-- Index des options : 0 = sauvegarde auto, 1 = sauv. provisoire,
--                     2 = dernière auberge, 3 = écran titre.
--
-- PRUDENCE DE CHARGEMENT : rien pendant la lecture du fichier ; l'accrochage
-- se pose à la première image, dans un pcall.
-- ============================================================================
R.mort = { pose = false, essais = 0, fait = false }
R.MORT_PHASES = { [40] = true, [41] = true, [42] = true }
R.MORT_CHOIX_AUBERGE = 2
R.MORT_FLOW_SORTIE  = 9   -- FadeOut : fondu de sortie normal

function R.mort_phase()
    local ok, mfm = pcall(sdk.get_managed_singleton, "app.MainFlowManager")
    if not ok or not mfm then return nil end
    local ok2, p = pcall(function() return mfm:get_field("<FlowPhase>k__BackingField") end)
    return ok2 and p or nil
end

-- Valide un choix comme le ferait le joueur : on pose le résultat, on sort de
-- l'attente de saisie, puis on pousse la machine à états vers FadeOut (9), qui
-- est l'état relevé juste après une vraie validation (sonde 013).
function R.mort_valider(this, choix, origine)
    -- 1. Poser le choix : l'appelant (MainFlowManager) le lira à la fin.
    pcall(function() this:set_field("Ret", choix) end)
    -- 2. Sortir de l'attente de saisie.
    pcall(function() this:set_field("IsWaitInput", false) end)
    -- 3. Pousser vers FadeOut (9) : l'état que le jeu se met lui-même juste
    --    après une vraie validation (relevé sonde 013). Il enchaîne seul
    --    jusqu'à End, et le fondu de sortie est joué normalement.
    --    NOTE : setFlowId() n'est pas utilisé — l'appel ne lève pas d'erreur
    --    mais reste sans effet (constaté en jeu en v0.62).
    pcall(function() this:set_field("FlowNow", R.MORT_FLOW_SORTIE) end)

    local relu_r = select(2, pcall(function() return this:get_field("Ret") end))
    local relu_f = select(2, pcall(function() return this:get_field("FlowNow") end))
    R.mort.fait = true
    R.mort_diag.maj = (origine or "?") .. " : Ret<-" .. tostring(choix)
        .. " FlowNow<-" .. tostring(R.MORT_FLOW_SORTIE)
        .. " ; relu Ret=" .. tostring(relu_r) .. " Flow=" .. tostring(relu_f)
end

function R.mort_poser()
    if R.mort.pose then return end
    R.mort.essais = R.mort.essais + 1
    if R.mort.essais > 600 then return end   -- abandon après ~10 s de jeu

    local ok, err = pcall(function()
        local td = sdk.find_type_definition("app.ui023401")
        if not td then error("type app.ui023401 absent") end
        local m = td:get_method("update")
        if not m then error("méthode update absente") end

        sdk.hook(m,
            function(args)
                if cfg.mort_auberge == false or cfg.actif == false then
                    return sdk.PreHookResult.CALL_ORIGINAL
                end
                local phase = R.mort_phase()
                if not phase or not R.MORT_PHASES[phase] then
                    R.mort.fait = false
                    return sdk.PreHookResult.CALL_ORIGINAL
                end
                local ok2, this = pcall(sdk.to_managed_object, args[2])
                if not ok2 or not this then return sdk.PreHookResult.CALL_ORIGINAL end

                R.mort_diag.hooks = R.mort_diag.hooks + 1
                R.mort_diag.phase = tostring(phase)

                R.mort.this = this          -- pour le bouton de test manuel
                pcall(function()
                    local ret  = this:get_field("Ret")
                    local flow = this:get_field("FlowNow")
                    local att  = this:get_field("IsWaitInput")
                    R.mort_diag.ret  = tostring(ret)
                    R.mort_diag.flow = tostring(flow)
                    R.mort_diag.att  = tostring(att)
                    R.mort_diag.sel0 = tostring(this:get_field("SelText0"))

                    -- Rien n'a encore été choisi : on choisit « dernière auberge »
                    -- à la place du joueur. Condition large : on n'exige plus
                    -- IsWaitInput, car le moment exact où il passe à true est
                    -- incertain et on risquait de manquer la fenêtre.
                    if not R.mort.fait and ret == -1 and (flow == 3 or flow == 4)
                       and att == true then
                        R.mort_valider(this, R.MORT_CHOIX_AUBERGE, "auto")
                    end
                end)
                return sdk.PreHookResult.CALL_ORIGINAL
            end,
            function(retval) return retval end)
    end)

    if ok then
        R.mort.pose = true
        R.mort_diag.pose = "oui"
    else
        R.mort_diag.pose = "échec : " .. tostring(err)
    end
end

re.on_frame(function() pcall(R.mort_poser) end)
