-- ============================================================================
-- BardN_UltimateBreathOfLife v0.5 — Ultimate Breath of Life (Dragon's Dogma 2)
-- v0.5 : compatibilité BardN Shards of Life v0.48 (api_niveau 2). Aucune nouvelle fonctionnalité.
-- v0.4 : retour de test de la v0.2/v0.3 : ONDE DE REPOUSSÉE RETIRÉE (cassée en jeu, abandonnée) ; orbite de la
--        caméra sur les pions adoucie (6 °/s au lieu de 12, 12° max au lieu de 40 : elle décalait trop la caméra
--        du héros et durait trop) ; coup de zoom au réveil raccourci (0,3 s au lieu de 0,5). Les réglages qui ont
--        changé et l'outil « retirer des PV » (v0.3, pas encore testé) restent en cyan ; le reste repasse en blanc.
-- v0.3 : OUTIL DE TEST « retirer des PV à un pion » (Pion 1/2/3, pourcentage, 100 % = à terre). Le branchement
--        n'est PAS certain (un ancien « Tuer les pions » n'avait jamais marché) : quatre méthodes essayées en
--        cascade jusqu'à ce que les PV baissent vraiment, le journal dit laquelle a pris et si le pion est bien
--        mort 0,5 s après. La méthode « coup factice (damageProc) » est à part, derrière une case, car un
--        DamageInfo sans attaquant pourrait faire planter le jeu.
-- v0.2 : (1) CORRECTIF : un ralenti « au lancement » programmé n'était pas annulé par une interruption
--            (il partait après coup et bloquait Slow Time) ; (2) code mort retiré (capture du battement
--            de cœur jamais branchée, ultime « Rupture » supprimée depuis la v0.28, réglage duree_canalisation) ;
--        (3) OPTIMISATIONS : appeler() sans allocation, joueur mis en cache le temps d'une image,
--            « peut lancer » du cercle au sol mis en cache 0,25 s, adresse de l'ActionManager et préchargement
--            cadencés, suivi des effets décoratifs une seule fois par image, cercles au sol sans pcall par segment,
--            enregistrement du mouvement court-circuité ; (4) CHORÉGRAPHIE : dernier pion mis en valeur
--            (temps plus long + ralenti approfondi relâché à son réveil), caméra orbitale + coup de zoom au réveil,
--            ONDE DE REPOUSSÉE (expérimentale, décochée) à la lumière finale : réaction DmgShrink + poussée scriptée
--            (méthode validée par la sonde Bourrasque) ; (5) menu réorganisé (titres orange, nouveautés en cyan).
-- v0.1 : NOUVEAU MOD, issu de la séparation de « BardN Shards of Life » (v0.43) en deux mods.
--   Ce mod REQUIERT « BardN Shards of Life » (la jauge d'Éclats de vie, la seconde vie, les remises à zéro).
--   Il contient les ULTIMES qui dépensent les éclats :
--     * Breath of Life : résurrection héroïque des pions à terre (croix gauche + B maintenu, réassignable) ;
--     * Slow Time : ralentissement du monde pour tous sauf l'Insurgé (croix droite + B) ;
--   leur chorégraphie (lévitation, relevé des pions un par un), la caméra, les effets visuels, la barre
--   d'incantation (sous la jauge de Shards of Life), la frange d'écran, les cercles au sol,
--   et les éléments HUD Controls correspondants.
-- Dialogue avec Shards of Life : _G.BardN_ShardsOfLife (get_unites, est_en_combat, changer_unites,
--   marquer_reanimation, jauge, incantation, abonnes_seconde_vie). Sans lui, ce mod reste inactif et le dit.
-- Réglages : reframework/data/BardN_UltimateBreathOfLife/config.json
--   (repris au 1er lancement depuis BardN_ShardsOfLife/config_avant_separation.json ou config.json)
-- ============================================================================

local NOM    = "BardN_ShardsOfLife_Ult_BoL v0.5"
local CONFIG = "BardN_UltimateBreathOfLife/config.json"
local DOSSIER = "BardN_UltimateBreathOfLife/"
local DOSSIER_SOL = "BardN_ShardsOfLife/"  -- ancien mod commun (reprise des réglages et des presets au 1er lancement)
local ANCIEN = "BardN_Savior/"
local ANCIEN2 = "BardN_BreathOfLife/"

-- ----------------------------------------------------------------------------
-- Réglages
-- ----------------------------------------------------------------------------
local defauts = {
    actif = true,
    -- énergie
    langue = "",                             -- v0.11 : "fr", "en" ou "auto" (langue du jeu)
    -- rengainer avant d'incanter
    -- effets visuels du jeu (« shells », catalogue de Skill Maker) — v0.14
    -- v0.18 : plusieurs effets combinables, chacun avec sa taille et ses copies
    effets = {},                             -- cle -> {canal, reussite, taille, copies}
    effet_suivre_rayon = false,               -- taille = rayon / rayon de base de l'effet
    effet_rayon_base = 2.0,                  -- rayon (m) de l'effet à l'échelle 1 (à calibrer)
    effet_echelle_fixe = 0.1,
    effet_hauteur = 0.75,                     -- décalage vertical (m)
    compenser_endurance = true,              -- rend l'endurance que l'Empyrée consomme
    effet_dynamique = true,                  -- v0.20 : la taille suit l'onde de canalisation
    inverse_duree = 0.8,                     -- durée de la disparition des effets (s)
    fin_expansion = 0.6,                     -- v0.27 : mode « grandir » : +60 % de taille
    fin_meme_a_l_interruption = true,        -- v0.27 : même disparition quand on interrompt
    cercle_mage = true,                      -- v0.30 : toujours actif (imposé) ; v0.26 : cercle d'incantation des sorts de Mage / Sorcier
    cercle_action = 1,                       -- index dans CERCLES
    effet_couper_interruption = true,        -- v0.20 : supprime les effets si la canalisation est interrompue
    effet_perso_fichier = "AppSystem/shell/userdata/humanshellparamdata_jobmagic.user",
    effet_perso_id = 17,
    rengainer = true,
    delai_rengainer = 0.3,
    -- résurrection héroïque
    capacite_active = true,
    cout = 3,
    -- condition de lancement : 1 = aucune (lancer en anticipation),
    --                          2 = au moins un pion à terre, 3 = tous les pions à terre
    condition_lancement = 1,
    cfg_version = 34,
    debloquer_apres = true,                 -- « annule tout » natif après l'animation
    rayon = 29.9,                             -- mètres autour de l'Insurgé
    duree_incantation = 5.5,                 -- v0.28 : durée de l'incantation sans cercle du jeu (s)
    consommer_au_lancement = false,          -- v0.42 : ignoré (paiement seulement à l'exécution)
    interrompre_si_relache = true,
    interrompre_si_touche = true,
    jouer_animation = true,
    maintenir_animation = true,
    -- v0.24 : comme les sorts de Mage / Sorcier : une fois chargé, le sort part
    -- quand on RELÂCHE (relâcher avant la fin de la canalisation l'annule)
    lancer_au_relachement = true,
    maintien_max = 0.0,                      -- 0 = maintien illimité ; sinon le sort part tout seul
    boucle_image = 200.0,                    -- image où reboucle l'animation pendant le maintien              -- v0.22 : relance l'animation si le jeu l'écrase
    -- méthode d'animation : 1 = forcer l'état « RescuePawn » (technique Skill Maker)
    --                       2 = mouvement brut enregistré, 3 = demande d'action
    methode_animation = 2,
    anim_bank = 0,                           -- mouvement de sauvetage (relevé en jeu le
    anim_id = 1001,                          -- 21/10 : banque 0, id 1001, 260 images)
    anim_fin = 260.0,
    utilisable_hors_combat = true,
    -- déclencheur
    combo_manette = 0x00040084,                 -- croix gauche (0x4) + B (0x40080)
    -- v0.28 : 2e ultime « Rupture » — déstabilise fortement les ennemis devant
    -- v0.29 : caméra qui dézoome pendant le maintien de la résurrection
    attendre_fin_effets = false,             -- v0.33 : contrôle rendu tout de suite (défaut)
    fondu_courbe = 3.0,                      -- v0.30 : >1 = l'effet reste visible longtemps puis s'éteint              -- v0.29 : remise à zéro après la disparition des effets
    -- v0.36 : lévitation des Mages / Sorciers pendant l'incantation (remplace l'animation de sauvetage)
    -- v0.37 : synchronisation du cercle d'incantation et de l'incantation
    cercle_sync = 1,                         -- 1 le sort est prêt quand le cercle est refermé, 2 cercle accéléré, 3 aucune
    cercle_duree_mesuree = 5.475,              -- durée native du cercle, mesurée en jeu (s)
    final_source = 2,                        -- v0.39 : index dans R.SOURCES_FINAL
    final_delai = 0.0,                       -- s après la fin du ralenti
    saut_avant_elevation = true,
    saut_delai = 0.45,
    coeur_actif = false,                      -- battement de cœur pendant l'incantation
    coeur_1 = 0.35,                          -- moments (fraction de l'incantation)
    coeur_2 = 0.7,
    coeur_fov = 7.0,                         -- pulsation du champ de vision (degrés)
    coeur_vitesse = 0.55,                    -- vitesse du jeu pendant le battement (1 = aucun effet)
    final_apres = 3,                         -- lumière finale : 1 fin du ralenti, 2 retour au sol, 3 au relâchement (en vol), 4 après un délai, 5 geste du sort (essai)
    portee_cylindre = true,                  -- v0.76 : rayon à plat + hauteur séparée
    portee_haut = 20.0,
    portee_bas = 20.0,
    vol_maintien = true,                     -- v0.78 : rester en l'air après l'incantation
    vol_fin = 2,                             -- 1 durée fixe, 2 jusqu'au dernier pion relevé
    vol_duree = 5.0,
    vol_apres = 1.0,                         -- s en l'air après le dernier pion
    ralenti_moment = 2,                      -- v0.77 : 1 au lancement (+ délai), 2 au relevé du 1er pion
    final_delai_relache = 0.95,               -- v0.76 : mode 4, s après le relâchement
    geste_nom = "",                          -- v0.76 : nom de l'action du geste, mémorisé une fois trouvé
    geste_delai = 0.0,                       -- v0.76 : mode 5, s après le début du geste (0 = à la fin du geste)
    focus_actif = true,                      -- pions relevés un par un après la lumière
    focus_camera = true,                     -- caméra tournée vers chaque pion
    focus_delai = 0.53,                       -- s entre la lumière et le premier pion
    chute_max = 1.5,                         -- v0.51 : attente maximale du retour au sol (s)
    focus_duree = 0.86,                       -- s par pion
    focus_reveil = 0.24,                     -- s avant de relever le pion visé
    focus_zoom = 7.8,                       -- degrés de champ de vision en moins sur le pion
    focus_sens_h = 1.0,
    focus_transition = 0.8,                  -- v0.79 : s pour tourner la caméra vers le pion (et revenir)
    focus_douceur = 0.5,                     -- v0.79 : lissage du point visé (passage d'un pion à l'autre, pion qui se relève)
    focus_hauteur = 0.9,                     -- v0.79 : hauteur visée sur le pion (m)
    focus_force = 0.82,                       -- v0.79 : 1 = pion au centre, 0.5 = à mi-chemin entre l'Insurgé et le pion
    m079 = true,
    m080 = true,
    m081 = true,
    m090 = true,
    natif_fin = true,                        -- v0.90 : garder l'Éclat sacré natif à la fin de l'incantation
    focus_sens_v = 1.0,
    annulation_active = true,                -- v0.45 : LT annule l'incantation
    annulation_bouton = 0x00000200,               -- LT (validé en jeu : 0x200) ; capturable
    cercle_attente_max = 0.3,                -- v0.52 : attente maximale de la fin du rengainage
    final_choix = {},                        -- v0.53 : sources cumulables de la lumière finale
    seconde_vie_effet = true,               -- lumière finale jouée sur l'Insurgé relevé
    ralenti_delai = 2.2,                     -- v0.57 : délai avant le ralenti (s)
    effet_pion_proprietaire = true,          -- v0.57 : effet « sur les pions » lancé depuis le pion lui-même
    levitation = true,
    levitation_endurance = true,             -- l'endurance ne baisse pas pendant la lévitation
    controle_atterrissage = true,            -- v0.82 : contrôle rendu dès le contact avec le sol
    levitation_fin = 1,                      -- 1 descente naturelle, 2 remise à zéro immédiate
    camera_actif = false,
    camera_methode = 2,                      -- 1 distance (expérimental), 2 champ de vision (validé), 3 les deux
    camera_distance_on = false,               -- v0.61 : vrai recul via l'option native (CameraManager._DistanceOffset)
    camera_distance_ajout = 6.4,             -- v0.61 : unités ajoutées au maximum (1 unité ≈ 1 m ; l'option du jeu va de 0 à 1)
    camera_delai = 0.0,                      -- v0.34 : s d'incantation avant que la caméra bouge
    camera_recul = 3.0,                      -- m de recul maximal
    camera_montee = 0.4,                     -- m de hauteur ajoutée au maximum
    camera_fov = 11.0,                       -- degrés ajoutés au maximum
    camera_duree_zoom = 3.8,                 -- s pour atteindre le dézoom maximal
    camera_retour = 0.7,                     -- s pour revenir à la caméra normale
    temps_actif = true,                      -- v0.41 : Slow Time (2e ultime)
    temps_combo = 0x00040088,                -- croix droite (0x8) + B
    temps_touche_clavier = 0,
    temps_cout = 3,                          -- éclats de vie
    temps_duree = 7.0,                       -- secondes RÉELLES de ralentissement
    temps_vitesse = 0.2,                     -- vitesse du monde (0.2 = -80 %)
    temps_canal = 1.0,                       -- courte incantation avant l'effet (s)
    temps_compenser = true,                  -- l'Insurgé garde sa vitesse normale
    temps_animation = false,                 -- animation de sauvetage pendant l'incantation
    -- v0.2 : dernier pion relevé mis en valeur
    dernier_pion_special = true,
    dernier_pion_duree_mult = 2.5,           -- la durée par pion (et le délai avant son réveil) est multipliée pour le dernier
    dernier_pion_ralenti = true,             -- ralenti approfondi tant que la caméra est sur lui, relâché à son réveil
    dernier_pion_ralenti_vitesse = 0.25,
    -- v0.2 : caméra orbitale sur les pions relevés
    focus_orbite = true,
    focus_orbite_vitesse = 6.0,              -- degrés par seconde autour du pion visé (v0.4 : 12 → 6)
    focus_orbite_max = 12.0,                 -- angle maximal parcouru (degrés) (v0.4 : 40 → 12)
    focus_punch = true,
    focus_punch_fov = 6.0,                   -- degrés de champ de vision en moins au réveil du pion
    focus_punch_duree = 0.3,                 -- s (v0.4 : 0,5 → 0,3)
    -- v0.3 : outil de test « retirer des PV »
    test_pv_pct = 100,
    test_pv_methode = 0,                     -- 0 auto (cascade), 1..4 une méthode précise
    test_pv_risque = false,                  -- autorise le coup factice (damageProc)
    maintien = 0.35,                         -- secondes de maintien
    tolerance_enchainement = 0.8,            -- croix gauche peut précéder B
    touche_clavier = 0,                      -- 0 = aucune (code de touche Windows)
    -- ralenti à la réussite
    ralenti_actif = true,
    ralenti_vitesse = 0.12,
    ralenti_duree = 1.5,                     -- secondes réelles
    -- cercle de zone dessiné au sol autour de l'Insurgé
    zone_pendant_canalisation = false,
    zone_quand_prete = false,               -- aperçu quand la capacité est utilisable
    zone_toujours = false,                  -- pour régler le rayon
    zone_epaisseur = 3.0,
    use_hud_controls = true,
    hud_opacite = 1.0,                       -- v0.42 : réglage de groupe (tous les éléments à l'écran)
    message_cercle_casse = true,             -- v0.31 : message quand le cercle du jeu reste ouvert (arme sans bâton de mage)
    -- v0.20 : anneau d'incantation dessiné par le mod (au sol, autour du personnage)
    anneau_affichage = 2,                    -- 1 toujours, 2 jamais (défaut), 3 sauf Guerrier et Mage ; outil de test depuis la v0.26
    anneau_rayon_debut = 2.2,                -- rayon au début de l'incantation (m)
    anneau_rayon_fin = 0.45,                 -- rayon quand le sort est prêt (m)
    anneau_epaisseur = 3.0,                  -- épaisseur du trait (px)
    anneau_col = 0xFF40D0FF,                 -- 0xAABBGGRR : doré
    anneau_col2 = 0xFFFFFFFF,                -- blanc
    frange_actif = true,                     -- v0.26 : frange d'écran pendant l'incantation
    frange_col = 0xFF2EDCFF,                 -- 0xAABBGGRR : jaune
    frange_largeur_min = 3.0,                -- largeur (% de l'écran) au début de la charge
    frange_largeur_max = 11.0,               -- largeur à la fin de la charge
    frange_largeur_prete = 25.0,             -- largeur quand le sort est prêt
    frange_opa_min = 0.04,                   -- opacité au début de la charge
    frange_opa_max = 0.20,                   -- opacité à la fin de la charge
    frange_opa_prete = 0.75,                 -- opacité quand le sort est prêt
    frange_douceur = 1.2,                    -- plus haut = le dégradé s'efface plus vite vers le centre
    frange_fondu = 0.6,                      -- disparition à la fin (s)
    -- v0.1 : barre d'incantation (dessinée sous la jauge de Shards of Life ; ex-réglages « jauge_* » du mod commun)
    barre_epaisseur = 4,                     -- épaisseur (px, avant l'échelle de la jauge)
    barre_opacite = 0.94,
    barre_decalage_x = 0,                    -- décalage par rapport à la position sous la jauge (px)
    barre_decalage_y = 0,
    barre_texte_incantation = true,          -- texte « PRÊT — relâche pour lancer »
    barre_col_fond = 0xB0282831,             -- couleurs au format 0xAABBGGRR (haut) + 2 (bas) = dégradé vertical
    barre_col_fond2 = 0xB0273853,
    barre_col_progres = 0xFF78CBFB,
    barre_col_progres2 = 0xFFB0B0B0,
    barre_col_pret = 0xFF4FE2FF,
    barre_col_pret2 = 0xFF1090C8,
}
local BASE = {   -- v0.14 : tables de base (preset 2 de l'utilisateur) ; copiées si aucune config n'existe
    effets = {
        final = { canal = false, coeur = false, copies = 1, deco_mode = 1, ecart = 0.0, emplacement = 1, fin_mode = 1, final = true, hauteur = 3.0, inverse_reussite = true, opacite_croissante = true, opacite_min = 0.57, reussite = false, taille = 0.87 },
        sceau = { canal = false, coeur = false, copies = 1, deco_mode = 1, ecart = 0.0, emplacement = 1, fin_mode = 2, final = false, hauteur = 0.0, inverse_reussite = true, opacite_croissante = true, opacite_min = 0.1, reussite = false, taille = 1.0 },
    },
    final_choix = {
        bouclier = { hauteur = 0.0, on = false, taille = 1.0 },
        brise = { hauteur = 0.0, on = false, taille = 1.0 },
        brise2 = { hauteur = 0.0, on = false, taille = 1.0 },
        cure = { hauteur = 0.0, on = false, taille = 1.0 },
        cure2 = { hauteur = 0.0, on = false, taille = 1.0 },
        dragon = { hauteur = 0.0, on = false, taille = 1.0 },
        dragon2 = { hauteur = 0.0, on = false, taille = 1.0 },
        empyree = { cible = 1, duree_vie = 5.5, hauteur = -8.2, on = false, taille = 4.29 },
        g_cure = { hauteur = 0.0, on = false, taille = 1.0 },
        g_empyree = { hauteur = 0.0, on = false, taille = 1.0 },
        g_holy = { hauteur = 0.0, on = false, taille = 1.0 },
        g_soin = { hauteur = 0.0, on = false, taille = 1.0 },
        hate = { hauteur = 0.0, on = false, taille = 1.0 },
        hate2 = { hauteur = 0.0, on = false, taille = 1.0 },
        holy = { cible = 1, duree_vie = 2.4, hauteur = -0.5, on = false, taille = 2.08 },
        holy2 = { cible = 2, duree_vie = 3.8, hauteur = -3.2, on = true, taille = 1.05 },
        liche = { cible = 1, duree_vie = 4.5, hauteur = 0.0, on = false, taille = 1.0 },
        sceau = { cible = 1, hauteur = 0.0, on = false, taille = 10.58 },
        soin = { hauteur = 0.0, on = false, taille = 1.0 },
    },
}
local function copie_profonde(t)
    if type(t) ~= "table" then return t end
    local c = {}
    for k, v in pairs(t) do c[k] = copie_profonde(v) end
    return c
end
local cfg = {}
for k, v in pairs(defauts) do cfg[k] = v end
local version_lue = nil
local importe = false
-- v0.1 : réglages repris de l'ancien mod commun (une seule fois, tant que le nouveau fichier n'existe pas)
local ANCIENNES = { DOSSIER_SOL .. "config_avant_separation.json", DOSSIER_SOL .. "config.json",
                    ANCIEN2 .. "config.json", ANCIEN .. "config.json" }
local RENOM = { jauge_canal_epaisseur = "barre_epaisseur", jauge_col_canal = "barre_col_progres", jauge_col_canal2 = "barre_col_progres2",
                jauge_col_fond = "barre_col_fond", jauge_col_fond2 = "barre_col_fond2", jauge_col_pret = "barre_col_pret",
                jauge_col_pret2 = "barre_col_pret2", jauge_opacite = "barre_opacite", jauge_texte_incantation = "barre_texte_incantation" }
local function appliquer(data)
    for k, v in pairs(data) do
        k = RENOM[k] or k
        if defauts[k] ~= nil and type(v) == type(defauts[k]) then
            if math.type(defauts[k]) == "integer" then v = math.tointeger(v) or defauts[k] end
            cfg[k] = v
        end
    end
end
local function charger()
    local ok, data = pcall(json.load_file, CONFIG)
    if ok and type(data) == "table" then
        version_lue = tonumber(data.cfg_version) or 0
        appliquer(data)
        return
    end
    for _, chemin in ipairs(ANCIENNES) do
        local ok2, d = pcall(json.load_file, chemin)
        if ok2 and type(d) == "table" and d.capacite_active ~= nil then
            version_lue = tonumber(d.cfg_version) or 0
            appliquer(d)
            importe = true
            return
        end
    end
end
local function sauver() pcall(json.dump_file, CONFIG, cfg) end
-- presets de réglages (copies complètes de la config)
local PRESETS = {}
function PRESETS.chemin(nom) return DOSSIER .. nom .. ".json" end
-- reprise des presets de l'ancien mod commun (une seule fois, sans écraser)
for _, nom in ipairs({ "preset_1", "preset_2", "preset_3", "avant_reset" }) do
    pcall(function()
        local deja = json.load_file(PRESETS.chemin(nom))
        if type(deja) ~= "table" then
            for _, chemin in ipairs({ DOSSIER_SOL .. nom .. "_avant_separation.json", DOSSIER_SOL .. nom .. ".json",
                                      ANCIEN2 .. nom .. ".json", ANCIEN .. nom .. ".json" }) do
                local vieux = json.load_file(chemin)
                if type(vieux) == "table" and vieux.capacite_active ~= nil then json.dump_file(PRESETS.chemin(nom), vieux); break end
            end
        end
    end)
end
function PRESETS.info(nom)
    local c = PRESETS.cache and PRESETS.cache[nom]
    if c == nil or os.clock() - c.t > 2 then
        local ok, d = pcall(json.load_file, PRESETS.chemin(nom))
        c = { t = os.clock(), txt = (ok and type(d) == "table") and tostring(d._preset_date or "sauvé") or false }
        PRESETS.cache = PRESETS.cache or {}
        PRESETS.cache[nom] = c
    end
    return c.txt or nil
end
function PRESETS.sauver(nom, libelle)
    local copie = {}
    for k, v in pairs(cfg) do copie[k] = v end
    local quand = "sauvé"
    pcall(function() quand = os.date("%d/%m %H:%M") end)
    copie._preset_date = quand
    local ok = pcall(json.dump_file, PRESETS.chemin(nom), copie)
    if PRESETS.cache then PRESETS.cache[nom] = nil end
    return ok, libelle
end
function PRESETS.charger(nom)
    local ok, d = pcall(json.load_file, PRESETS.chemin(nom))
    if not (ok and type(d) == "table") then return false end
    for k, v in pairs(d) do
        k = RENOM[k] or k
        if k ~= "langue" and defauts[k] ~= nil and type(v) == type(defauts[k]) then
            if math.type(defauts[k]) == "integer" then v = math.tointeger(v) or defauts[k] end
            cfg[k] = v
        end
    end
    sauver()
    return true
end
charger()
-- réglages imposés (appliqués APRÈS la lecture de la config depuis v0.65)
cfg.coeur_actif = false                -- v0.52 : battements de cœur supprimés
if cfg.final_choix == defauts.final_choix then cfg.final_choix = copie_profonde(BASE.final_choix) end   -- v0.14 : pas de config → base
if type(cfg.final_choix) ~= "table" or next(cfg.final_choix) == nil then   -- v0.53 : reprend l'ancienne source unique
    cfg.final_choix = {}
    local anciens = { "holy", "holy2", "empyree", "cure2", "soin", "brise" }
    local k = anciens[cfg.final_source or 2] or "holy2"
    cfg.final_choix[k] = { on = true, taille = 1.0, hauteur = 0.0 }
end
cfg.cercle_mage = true                   -- v0.30 : le cercle d'incantation est toujours actif (lévitation pilotable)
cfg.cercle_sync = 1                    -- v0.66 : le cercle EST l'incantation (l'accélération n'avait aucun effet : 5,5 s toujours)
cfg.camera_methode = 2                 -- v0.52 : seul le champ de vision est gardé (le recul ne marchait pas)
if cfg.annulation_bouton == 0x400 then cfg.annulation_bouton = 0x200 end   -- v0.46 : LT = 0x200
cfg.utilisable_hors_combat = true      -- v0.46 : les sorts ne sont plus limités au combat
-- v0.51 : séquence plus rapide, coopération moins sensible (anciens défauts remplacés)
if cfg.focus_delai == 0.5 then cfg.focus_delai = 0.2 end
if cfg.focus_duree == 1.6 then cfg.focus_duree = 1.2 end
if cfg.focus_reveil == 0.5 then cfg.focus_reveil = 0.25 end
if not cfg.m090 then cfg.m090 = true; cfg.zone_pendant_canalisation = false end   -- v0.90 : cercle au sol décoché
if not cfg.m081 then cfg.m081 = true; cfg.delai_rengainer, cfg.cercle_attente_max = 0.3, 0.3 end   -- v0.81 : début de sort raccourci
if not cfg.m080 then cfg.m080 = true; cfg.focus_transition, cfg.focus_douceur, cfg.focus_force = 0.8, 0.5, 0.7 end   -- v0.80 : réglage « cinématique »
if not cfg.m079 then cfg.m079 = true; if cfg.cercle_attente_max > 0.3 then cfg.cercle_attente_max = 0.3 end end   -- v0.79
-- migration des anciennes configurations (avant v0.10)
if version_lue ~= nil and version_lue < 34 then
    cfg.camera_methode = 2             -- v0.34 : champ de vision validé en jeu, distance non
end
if version_lue ~= nil and version_lue < 33 then
    cfg.attendre_fin_effets = false    -- v0.33 : l'Insurgé restait bloqué après la réussite
end
if version_lue ~= nil and version_lue < 21 and version_lue >= 10 then
    cfg.effet_dynamique = true         -- v0.21 : réactivée (la v0.20 ne retrouvait pas les effets)
    cfg.cfg_version = 21
    sauver()
end
if version_lue ~= nil and version_lue < 10 then
    cfg.methode_animation = 2         -- « forcer l'état » ne fonctionne pas dans ce jeu
    cfg.condition_lancement = 1
    cfg.cfg_version = 21
    sauver()
end

-- ----------------------------------------------------------------------------
-- État et outils
-- ----------------------------------------------------------------------------
if importe then sauver() end              -- v0.1 : crée tout de suite le fichier de réglages propre à ce mod

-- ----------------------------------------------------------------------------
-- État et outils
-- ----------------------------------------------------------------------------
local R = {}   -- v0.28 : état et fonctions de la Rupture (limite de 200 variables locales)

-- ----------------------------------------------------------------------------
-- v0.11 : LANGUE — français / English (bouton en haut du menu : Français, English, Auto)
-- Le script est écrit en français ; en anglais, chaque texte affiché (menu, écran, journal) passe par
-- R.T() : traduction exacte du texte entier, sinon traduction des morceaux connus (dictionnaire R.EN).
-- Les textes du jeu eux-mêmes (dialogue de la Pierre de Réveil) suivent la langue du jeu.
-- ----------------------------------------------------------------------------
R.EN = {
    ["cercle bloqué sur la préparation après %.1f s : état « prêt » demandé (%s)"] = "circle stuck on the preparation after %.1f s: \"ready\" state requested (%s)",
    ["demande acceptée"] = "request accepted",
    ["échec"] = "failed",
    ["lancement : vocation = %s (3 = Mage, dont le cercle est repris ici)"] = "launch: vocation = %s (3 = Mage, whose circle is used here)",
    ["illisible"] = "unreadable",
    ["interrompu (%s)"] = "interrupted (%s)",
    ["réussi"] = "succeeded",
    ["aucun"] = "none",
    ["lancement : sort précédent = %s"] = "launch: previous spell = %s",
    ["cercle : haut du corps → %s (%.2f s)"] = "circle: upper body → %s (%.2f s)",
    ["cercle : à %.0f s, haut du corps = %s"] = "circle: at %.0f s, upper body = %s",
    ["ATTENTION : le jeu n'a jamais atteint « prêt » après %.1f s (haut du corps = %s) : sort déclaré chargé par la sécurité"] = "WARNING: the game never reached \"ready\" after %.1f s (upper body = %s): spell declared charged by the safety timer",
    ["Couleur du haut"] = "Top colour",
    ["Couleur du bas (dégradé)"] = "Bottom colour (gradient)",
    ["Même couleur en bas (pas de dégradé)"] = "Same colour at the bottom (no gradient)",
    ["Remettre par défaut"] = "Reset to default",
    ["  texte « PRÊT — relâche pour lancer » pendant l'incantation"] = "  \"READY — release to cast\" text during the incantation",
    ["Choisir la couleur"] = "Pick the colour",
    ["Transparence (0 = invisible, 255 = opaque)"] = "Transparency (0 = invisible, 255 = opaque)",
    ["Rouge"] = "Red",
    ["Vert"] = "Green",
    ["Bleu"] = "Blue",
    ["(sélecteur de couleur indisponible : curseurs Rouge / Vert / Bleu)"] = "(colour picker unavailable: Red / Green / Blue sliders)",
    ["à 0"] = "at 0",
    ["Hâte"] = "Haste",
    ["vide"] = "empty",
    [" = « "] = " = \" ",
    [" » : "] = "\": ",
    ["Pion "] = "Pawn ",
    ["aucun"] = "none",
    ["début"] = "start",
    ["lancé"] = "launched",
    ["sauvé"] = "saved",
    ["ÉCHEC"] = "FAILED",
    ["échec"] = "failed",
    ["Aucune"] = "None",
    ["BLOQUÉ"] = "BLOCKED",
    ["Caméra"] = "Camera",
    ["PORTÉE"] = "RANGE",
    ["Sauver"] = "Save",
    ["aucune"] = "none",
    ["chargé"] = "loaded",
    ["coupée"] = "disabled",
    ["laissé"] = "left",
    ["lancée"] = "launched",
    ["relevé"] = "revived",
    ["sauvés"] = "saved",
    ["ÉCHEC "] = "FAILED ",
    ["Charger"] = "Load",
    ["ERREUR "] = "ERROR ",
    ["Empyrée"] = "Empyrean",
    ["Essayer"] = "Try",
    ["Journal"] = "Journal",
    ["PV %.0f"] = "HP %.0f",
    ["Preset "] = "Preset ",
    ["Presets"] = "Presets",
    ["Ralenti"] = "Slow-motion",
    ["Rupture"] = "Rupture",
    ["affiché"] = "shown",
    ["demandé"] = "requested",
    ["essayer"] = "try",
    ["relance"] = "retry",
    [" = objet"] = " = object",
    [" — ÉCHEC"] = " — FAILED",
    ["1. DÉBUT"] = "1. START",
    ["Capturer"] = "Capture",
    ["Dézoomer"] = "Zoom out",
    ["demandée"] = "requested",
    ["effet « "] = "effect \" ",
    ["méthode "] = "method ",
    ["relancée"] = "requested again",
    ["réussite"] = "success",
    ["sort n° "] = "spell no. ",
    ["toujours"] = "always",
    ["  état : "] = "  state: ",
    [" champ(s)"] = " field(s)",
    [" » lancée"] = " \" launched",
    ["COMMANDES"] = "CONTROLS",
    ["Mod actif"] = "Mod enabled",
    ["Restaurer"] = "Restore",
    ["appliquée"] = "applied",
    ["coup reçu"] = "hit taken",
    ["désactivé"] = "disabled",
    ["effet n° "] = "effect no. ",
    ["en combat"] = "in combat",
    ["erreur : "] = "error: ",
    ["illisible"] = "unreadable",
    ["rengainer"] = "sheathe",
    ["    taille"] = "    size",
    ["5. RALENTI"] = "5. SLOW-MOTION",
    ["Aucune##tc"] = "None##tc",
    ["Brise-sort"] = "Spell Break",
    ["IMPOSSIBLE"] = "IMPOSSIBLE",
    ["NON coupée"] = "NOT disabled",
    ["Par défaut"] = "Default",
    ["Sauver##ps"] = "Save##ps",
    ["essayer##e"] = "try##e",
    ["par le jeu"] = "by the game",
    ["par le mod"] = "by the mod",
    ["pas encore"] = "not yet",
    ["redemandée"] = "requested again",
    ["sort lancé"] = "spell cast",
    ["Charger##pc"] = "Load##pc",
    ["Hâte niv. 2"] = "Haste lv. 2",
    ["aucun effet"] = "no effect",
    ["hors combat"] = "outside combat",
    ["registre lu"] = "registry read",
    ["sur le pion"] = "on the pawn",
    ["transition "] = "transition ",
    ["Éclat sacré"] = "Holy Shine",
    [" déjà relevé"] = " already revived",
    ["Capturer##ca"] = "Capture##ca",
    ["Capturer##tc"] = "Capture##tc",
    ["Chorégraphie"] = "Choreography",
    ["NON modifiés"] = "NOT changed",
    ["Purification"] = "Purification",
    ["Utilisable :"] = "Usable:",
    ["animation : "] = "animation: ",
    ["animation « "] = "animation \" ",
    ["au lancement"] = "on cast",
    ["déséquilibré"] = "staggered",
    ["rengainer : "] = "sheathe: ",
    ["élévation : "] = "lift-off: ",
    ["    taille##t"] = "    size##t",
    ["NON appliquée"] = "NOT applied",
    ["Point de soin"] = "Healing Spot",
    ["Restaurer##pr"] = "Restore##pr",
    ["déjà en cours"] = "already running",
    ["geste du sort"] = "spell gesture",
    ["lévitation : "] = "levitation: ",
    ["remboursement"] = "refund",
    ["retour au sol"] = "landing",
    ["sécurité 20 s"] = "20 s safety",
    [" impossible : "] = " impossible: ",
    ["2. INCANTATION"] = "2. INCANTATION",
    ["Effets visuels"] = "Visual effects",
    ["Outils de test"] = "Test tools",
    ["Par défaut##cm"] = "Default##cm",
    ["Preset %d : %s"] = "Preset %d: %s",
    ["Rupture lancée"] = "Rupture cast",
    ["après le délai"] = "after the delay",
    ["après un délai"] = "after a delay",
    ["au relâchement"] = "on release",
    ["fin du ralenti"] = "end of the slow-motion",
    ["infos de nœud "] = "node info ",
    ["    hauteur (m)"] = "    height (m)",
    [" (nouvel essai)"] = " (new attempt)",
    [" interrompue : "] = " interrupted: ",
    [" non retrouvé ("] = " not found (",
    ["6. ATTERRISSAGE"] = "6. LANDING",
    ["Capacité active"] = "Ability enabled",
    ["Insurgé à terre"] = "Arisen down",
    ["après le cercle"] = "after the circle",
    ["essai direct : "] = "direct attempt: ",
    ["maximum atteint"] = "maximum reached",
    ["taille et durée"] = "size and duration",
    ["touche relâchée"] = "key released",
    ["  vitesse du jeu"] = "  game speed",
    [" : canalisation…"] = " : channelling…",
    [" » enregistrée ("] = " \" recorded (",
    ["%s : réglages %s"] = "%s: settings %s",
    ["4. PIONS RELEVÉS"] = "4. REVIVED PAWNS",
    ["Rayon à plat (m)"] = "Flat radius (m)",
    ["Réglage commun :"] = "Common setting:",
    ["au retour au sol"] = "on landing",
    ["caméra : erreur "] = "camera: error ",
    ["capture terminée"] = "capture finished",
    ["forcer l'état : "] = "forcing the state: ",
    ["liste des effets"] = "effect list",
    ["preset « %s » %s"] = "preset \"%s\" %s",
    ["remise à zéro : "] = "reset: ",
    ["visuel seulement"] = "visual only",
    ["  geste trouvé : "] = "  gesture found: ",
    ["  vers le bas (m)"] = "  downwards (m)",
    [" : lumière finale"] = " : final light",
    ["Brise-sort niv. 2"] = "Spell Break lv. 2",
    ["Lumière finale : "] = "Final light: ",
    ["PV max illisibles"] = "max HP unreadable",
    ["Rupture : onde « "] = "Rupture: shockwave \" ",
    ["Tester le ralenti"] = "Test the slow-motion",
    ["Touche clavier : "] = "Keyboard key: ",
    ["battement de cœur"] = "heartbeat",
    ["fin de lévitation"] = "end of levitation",
    ["pendant le cercle"] = "during the circle",
    ["    hauteur (m)##h"] = "    height (m)##h",
    ["   |   INCANTATION"] = "   |   CASTING",
    ["  vers le haut (m)"] = "  upwards (m)",
    [") → mouvement brut"] = ") → raw motion",
    ["Annuler la capture"] = "Cancel the capture",
    ["Grimoire : Empyrée"] = "Grimoire: Empyrean",
    ["Répression magique"] = "Magic Suppression",
    ["après le coup reçu"] = "after the hit taken",
    ["aucun pion à terre"] = "no pawn down",
    ["battement de cœur "] = "heartbeat ",
    ["Éclat sacré niv. 2"] = "Holy Shine lv. 2",
    ["  durée (s réelles)"] = "  duration (real seconds)",
    ["%s %s (secours, %s)"] = "%s %s (backup, %s)",
    ["Barre d'incantation"] = "Incantation bar",
    ["Débloquer l'Insurgé"] = "Unstick the Arisen",
    ["Insurgé introuvable"] = "Arisen not found",
    ["Purification niv. 2"] = "Purification lv. 2",
    ["animation relancée "] = "animation restarted ",
    ["capacité désactivée"] = "ability disabled",
    ["demande de création"] = "creation request",
    ["fin de canalisation"] = "end of channelling",
    ["mouvement brut joué"] = "raw motion played",
    ["pas d'ActionManager"] = "no ActionManager",
    ["ÉCHEC de la demande"] = "request FAILED",
    ["Éclats de vie prêts"] = "Shards of Life ready",
    ["à la fin du ralenti"] = "at the end of the slow-motion",
    ["  durée en l'air (s)"] = "  time in the air (s)",
    ["  durée par pion (s)"] = "  duration per pawn (s)",
    ["Bouclier (Guard bit)"] = "Shield (Guard bit)",
    ["Coût (éclats de vie)"] = "Cost (Shards of Life)",
    ["Insurgé indisponible"] = "Arisen unavailable",
    ["Rester en lévitation"] = "Stay levitating",
    ["Réglages par défaut…"] = "Default settings…",
    ["pas de HitController"] = "no HitController",
    ["énergie insuffisante"] = "not enough shards",
    ["  durée du retour (s)"] = "  return duration (s)",
    [" illisible (liste de "] = " unreadable (list of ",
    ["Breath of Life réussi"] = "Breath of Life succeeded",
    ["DamageInfo impossible"] = "DamageInfo impossible",
    ["Essayer sur mes pions"] = "Try on my pawns",
    ["PENDANT L'INCANTATION"] = "DURING THE INCANTATION",
    ["Répression démoniaque"] = "Demonic Suppression",
    ["chargement du fichier"] = "loading the file",
    ["geste : essai %s → %s"] = "gesture: attempt %s → %s",
    ["identifiant illisible"] = "identifier unreadable",
    ["ÉCHEC → remise à zéro"] = "FAILED → reset",
    ["état RescuePawn forcé"] = "RescuePawn state forced",
    ["  hauteur générale (m)"] = "  overall height (m)",
    ["%s hors de portée (%s)"] = "%s out of range (%s)",
    ["3. APRÈS L'INCANTATION"] = "3. AFTER THE INCANTATION",
    ["Annuler avec un bouton"] = "Cancel with a button",
    ["DamageInfo : champs = "] = "DamageInfo: fields = ",
    ["Grimoire : Éclat sacré"] = "Grimoire: Holy Shine",
    ["HitManager introuvable"] = "HitManager not found",
    ["cercle d'incantation ("] = "casting circle (",
    ["couche FSM introuvable"] = "FSM layer not found",
    ["erreur HUD Controls : "] = "HUD Controls error: ",
    ["haut du corps libre : "] = "upper body free: ",
    ["identifiant de l'effet"] = "effect identifier",
    ["pendant une durée fixe"] = "for a fixed duration",
    ["    recul maximal (≈ m)"] = "    maximum pull-back (≈ m)",
    ["  %s (%.1f m) : %s (%s)"] = "  %s (%.1f m): %s (%s)",
    ["  pendant l'incantation"] = "  during the incantation",
    [" effet(s) supprimé(s) ("] = " effect(s) removed (",
    ["Avant remise par défaut"] = "Before reset to defaults",
    ["Essayer le dézoom (3 s)"] = "Try the zoom-out (3 s)",
    ["Grimoire : Purification"] = "Grimoire: Purification",
    ["animation impossible : "] = "animation impossible: ",
    ["caméra : visée du pion "] = "camera: pawn aim ",
    ["geste du sort TROUVÉ : "] = "spell gesture FOUND: ",
    ["rechargement du fichier"] = "reloading the file",
    ["Éclats de vie perdus : "] = "Shards of Life lost: ",
    ["Capturer une combinaison"] = "Capture a combination",
    ["Grimoire : Point de soin"] = "Grimoire: Healing Spot",
    ["HUD Controls non détecté"] = "HUD Controls not detected",
    ["Onde de l'attaque lourde"] = "Heavy attack shockwave",
    ["Sauter avant l'élévation"] = "Jump before lifting off",
    ["ShellManager introuvable"] = "ShellManager not found",
    ["[capture] couche %d : %s"] = "[capture] layer %d: %s",
    [">>> appuie sur la touche…"] = ">>> press the key…",
    ["HitController introuvable"] = "HitController not found",
    ["[capture] nouvel effet : "] = "[capture] new effect: ",
    ["aucun pion dans le groupe"] = "no pawn in the party",
    ["saut avant l'élévation : "] = "jump before lift-off: ",
    ["  délai pour rengainer (s)"] = "  delay to sheathe (s)",
    ["  hauteur générale (m)##hg"] = "  overall height (m)##hg",
    [" » impossible à l'étape « "] = " \" impossible at step \" ",
    [" → essai du mouvement brut"] = " → trying the raw motion",
    ["PRÊT — relâche pour lancer"] = "READY — release to cast",
    ["Rengainer avant d'incanter"] = "Sheathe before incanting",
    ["cercle accéléré ×%.2f : %s"] = "circle sped up ×%.2f: %s",
    ["maintien en l'air : %.1f s"] = "hover: %.1f s",
    ["l'état forcé n'a pas tenu ("] = "the forced state did not hold (",
    ["liste ShellParams illisible"] = "ShellParams list unreadable",
    ["réanimation native en cours"] = "native revival in progress",
    ["éclats de vie %d -> %d (%s)"] = "Shards of Life %d -> %d (%s)",
    ["ERREUR séquence de relevé : "] = "ERROR in the revival sequence: ",
    ["au relâchement, en plein vol"] = "on release, mid-air",
    ["fichier d'effets rechargé : "] = "effects file reloaded: ",
    ["jusqu'au dernier pion relevé"] = "until the last pawn is revived",
    ["mouvement brut impossible : "] = "raw motion impossible: ",
    ["suivi des effets : effet n° "] = "effect tracking: effect no. ",
    ["sur le geste du sort (essai)"] = "on the spell gesture (experimental)",
    ["type SetNodeInfo introuvable"] = "SetNodeInfo type not found",
    ["énergie insuffisante (%d/%d)"] = "not enough shards (%d/%d)",
    ["  délai avant le 1er pion (s)"] = "  delay before the 1st pawn (s)",
    ["Barre d'incantation##jauge_c5"] = "Incantation bar##jauge_c5",
    ["HUD Controls : jauge déclarée"] = "HUD Controls: gauge registered",
    ["Liche : signe de résurrection"] = "Lich: resurrection sign",
    ["Magie chargée (longue portée)"] = "Charged magick (long range)",
    ["Rupture lancée (aucun ennemi)"] = "Rupture cast (no enemy)",
    ["annulée (bouton d'annulation)"] = "cancelled (cancel button)",
    ["create_instance a renvoyé nil"] = "create_instance returned nil",
    ["requestActionCore introuvable"] = "requestActionCore not found",
    ["setCurrentNode indisponible ("] = "setCurrentNode unavailable (",
    ["  délai (s après le lancement)"] = "  delay (s after the cast)",
    ["NON sauvés (erreur d'écriture)"] = "NOT saved (write error)",
    ["fichier d'effet introuvable : "] = "effect file not found: ",
    ["si tous les pions sont à terre"] = "if all the pawns are down",
    ["Éclats de vie (Shards of Life)"] = "Shards of Life",
    ["  hauteur visée sur le pion (m)"] = "  aim height on the pawn (m)",
    [") — opacité et fondu sans effet"] = ") — opacity and fade have no effect",
    ["Cercle de zone dessiné au sol :"] = "Area circle drawn on the ground:",
    ["Répression démoniaque (étendue)"] = "Demonic Suppression (extended)",
    ["cercle : attente de %.2f s (%s)"] = "circle: waited %.2f s (%s)",
    ["couche de mouvement introuvable"] = "motion layer not found",
    ["effet natif du jeu %s (%s) : %s"] = "native game effect %s (%s): %s",
    ["maintien en l'air : lévitation "] = "hover: levitation ",
    ["remboursement (sort interrompu)"] = "refund (spell interrupted)",
    ["si au moins un pion est à terre"] = "if at least one pawn is down",
    ["éclats de vie déjà au maximum ("] = "Shards of Life already at maximum (",
    ["    durée de vie (s, 0 = native)"] = "    lifetime (s, 0 = native)",
    ["  délai après le relâchement (s)"] = "  delay after release (s)",
    [" fois pendant cette canalisation"] = " times during this channelling",
    ["Escroc : dragon de fumée (corps)"] = "Trickster: Smoke Dragon (body)",
    ["Lancier mystique : sceau magique"] = "Mystic Spearhand: magick seal",
    ["Lumière finale (lumière intense)"] = "Final light (intense light)",
    ["fin de la lévitation : descente "] = "end of levitation: descent ",
    ["interrompu pendant le rengainage"] = "interrupted while sheathing",
    ["lévitation : état après 0,5 s = "] = "levitation: state after 0.5 s = ",
    ["Éclats de vie consommés : relevé"] = "Shards of Life spent: revival",
    ["  toujours (pour régler le rayon)"] = "  always (to adjust the radius)",
    ["effet visuel seulement : effet « "] = "visual effect only: effect \" ",
    ["nouvelle touche clavier (%s) : %d"] = "new keyboard key (%s): %d",
    ["Escroc : dragon de fumée (souffle)"] = "Trickster: Smoke Dragon (breath)",
    ["ShellCreateInfo impossible à créer"] = "ShellCreateInfo could not be created",
    ["Tourner la caméra vers chaque pion"] = "Turn the camera towards each pawn",
    ["méthode setCurrentNode introuvable"] = "setCurrentNode method not found",
    ["Éclats de vie : %d / %d   |   %s%s"] = "Shards of Life: %d / %d   |   %s%s",
    ["    durée de vie (s, 0 = native)##d"] = "    lifetime (s, 0 = native)##d",
    ["  bouton : 0x%X (défaut 0x200 = LT)"] = "  button: 0x%X (default 0x200 = LT)",
    ["  souplesse (s, plus = plus fluide)"] = "  smoothness (s, higher = smoother)",
    ["Interrompre si l'Insurgé est touché"] = "Interrupt if the Arisen is hit",
    ["Temps de maintien pour démarrer (s)"] = "Hold time to start (s)",
    ["geste du sort : frappe après %.2f s"] = "spell gesture: strike after %.2f s",
    ["  taille générale de tous les effets"] = "  overall size of all effects",
    ["  zoom sur le pion (degrés en moins)"] = "  zoom on the pawn (degrees less)",
    [" » introuvable, collision non coupée"] = " \" not found, collision not disabled",
    ["BardN Shards of Life — Éclats de vie"] = "BardN Shards of Life — Shards of Life",
    ["Pions suivis : %d   |   à terre : %d"] = "Pawns tracked: %d   |   down: %d",
    ["cercle en attente : haut du corps = "] = "circle waiting: upper body = ",
    ["  aperçu quand le sort est utilisable"] = "  preview when the spell is usable",
    ["  délai avant que la caméra bouge (s)"] = "  delay before the camera moves (s)",
    ["  recul réel (distance native du jeu)"] = "  real pull-back (the game's native distance)",
    ["essai direct (pas encore enregistrée)"] = "direct attempt (not recorded yet)",
    ["fin naturelle des effets : méthode « "] = "natural end of the effects: method \" ",
    ["geste : couche 0 = %s | couche 1 = %s"] = "gesture: layer 0 = %s | layer 1 = %s",
    ["main introuvable : effet placé au sol"] = "hand not found: effect placed on the ground",
    ["Avant la dernière remise par défaut : "] = "Before the last reset to defaults: ",
    ["Rupture : onde impossible à l'étape « "] = "Rupture: shockwave impossible at step \" ",
    ["Rupture : puissance de l'onde x%.1f %s"] = "Rupture: shockwave power x%.1f %s",
    ["quand le premier pion revient à la vie"] = "when the first pawn returns to life",
    ["  attente maximale du retour au sol (s)"] = "  maximum wait for the landing (s)",
    ["Breath of Life (résurrection des pions)"] = "Breath of Life (pawn resurrection)",
    ["essai sur les pions : aucun pion trouvé"] = "test on the pawns: no pawn found",
    ["fin du maintien en l'air après %.1f s%s"] = "end of the hover after %.1f s%s",
    ["maintien maximal atteint : le sort part"] = "maximum hold reached: the spell goes off",
    ["  délai entre le saut et l'élévation (s)"] = "  delay between the jump and the lift-off (s)",
    ["  taille générale de tous les effets##tg"] = "  overall size of all effects##tg",
    ["SUR LES PIONS RELEVÉS (relevé un par un)"] = "ON THE REVIVED PAWNS (revived one by one)",
    ["compensation de l'endurance : méthode « "] = "stamina compensation: method \" ",
    ["nouvelle combinaison manette (%s) : 0x%X"] = "new gamepad combination (%s): 0x%X",
    ["registre InstantiatedShellDict illisible"] = "InstantiatedShellDict registry unreadable",
    ["À la fin de l'incantation, sur l'Insurgé"] = "At the end of the incantation, on the Arisen",
    ["Épaisseur de la barre d'incantation (px)"] = "Incantation bar thickness (px)",
    ["Rupture : état des ennemis 0,5 s après : "] = "Rupture: enemy state 0.5 s later: ",
    ["Sur chaque pion quand il revient à la vie"] = "On each pawn when it returns to life",
    ["fin de canalisation (lévitation / cercle)"] = "end of channelling (levitation / circle)",
    ["  reste en l'air après le dernier pion (s)"] = "  stays in the air after the last pawn (s)",
    ["tous les pions ne sont pas à terre (%d/%d)"] = "not all pawns are down (%d/%d)",
    ["état RescuePawn actif : animation en cours"] = "RescuePawn state active: animation playing",
    ["  vitesse de rotation (s, plus = plus doux)"] = "  rotation speed (s, higher = gentler)",
    ["aucun pion dans la zone : énergie conservée"] = "no pawn in the area: shards kept",
    ["aucune énergie consommée (sort non exécuté)"] = "no shard spent (spell not executed)",
    ["disparition de l'effet : mode %d sur %.1f s"] = "effect fade-out: mode %d over %.1f s",
    ["type via.motion.MotionFsm2Layer introuvable"] = "via.motion.MotionFsm2Layer type not found",
    ["  champ de vision ajouté (degrés, 0 = aucun)"] = "  added field of view (degrees, 0 = none)",
    ["  durée pour atteindre le dézoom maximal (s)"] = "  time to reach the maximum zoom-out (s)",
    ["  pion relevé après (s, caméra déjà sur lui)"] = "  pawn revived after (s, camera already on it)",
    ["Lancer Breath of Life (comme la combinaison)"] = "Cast Breath of Life (same as the combination)",
    ["DamageInfo : champs de déséquilibre réglés = "] = "DamageInfo: stagger fields set = ",
    ["aucun ennemi dans le cône : énergie conservée"] = "no enemy in the cone: shards kept",
    ["  attente maximale de la fin du rengainage (s)"] = "  maximum wait for sheathing to finish (s)",
    ["cercle refermé après %.2f s d'incantation (%s)"] = "circle closed after %.2f s of incantation (%s)",
    ["lévitation interrompue par le jeu (%s) : %s %s"] = "levitation interrupted by the game (%s): %s %s",
    ["maintien en l'air jusqu'au dernier pion relevé"] = "hover until the last pawn is revived",
    ["L'endurance ne baisse pas pendant la lévitation"] = "Stamina does not drop during levitation",
    ["Un par un (sinon : tous d'un coup au lancement)"] = "One by one (otherwise: all at once on cast)",
    ["atterrissage : contrôle rendu après %.2f s (%s)"] = "landing: control returned after %.2f s (%s)",
    ["Coche un ou plusieurs effets (ils se cumulent) :"] = "Tick one or more effects (they stack):",
    ["ValueType absent de cette version de REFramework"] = "ValueType missing from this REFramework version",
    ["effet « %s » lancé (%s, taille %.2f, %d copie%s)"] = "effect \"%s\" launched (%s, size %.2f, %d cop%s)",
    ["effet « %s » sur le pion (%.1f, %.1f, %.1f) : %s"] = "effect \"%s\" on the pawn (%.1f, %.1f, %.1f): %s",
    ["effets sur les pions : position du pion illisible"] = "effects on pawns: pawn position unreadable",
    ["  (sinon : sphère de ce rayon autour de l'Insurgé)"] = "  (otherwise: sphere of this radius around the Arisen)",
    ["  frappe après le début du geste (s, 0 = à la fin)"] = "  strike after the start of the gesture (s, 0 = at the end)",
    ["  maintien maximal une fois prêt (s, 0 = illimité)"] = "  maximum hold once ready (s, 0 = unlimited)",
    ["opacité : EffectManager2 introuvable sur l'effet ("] = "opacity: EffectManager2 not found on the effect (",
    ["relevé des pions : %d pion(s) à relever, un par un"] = "reviving the pawns: %d pawn(s) to revive, one by one",
    ["  intensité (1 = pion au centre, 0,5 = à mi-chemin)"] = "  intensity (1 = pawn centred, 0.5 = halfway)",
    ["Rupture : %d ennemi(s) dans le cône (%.0f m, %.0f°)"] = "Rupture: %d enemy(ies) in the cone (%.0f m, %.0f°)",
    ["réglages remis par défaut (anciens réglages sauvés)"] = "settings reset to defaults (old settings saved)",
    ["sort chargé : relâche la combinaison pour le lancer"] = "spell charged: release the combination to cast it",
    ["Lancer au relâchement de B (comme les sorts de Mage)"] = "Cast on release of B (like Mage spells)",
    ["fin de canalisation, après la disparition des effets"] = "end of channelling, after the effects fade",
    ["mouvement de sauvetage enregistré : banque %d, id %d"] = "rescue motion recorded: bank %d, id %d",
    ["opacité : %d élément(s) d'effet colorés (alpha %.2f)"] = "opacity: %d effect element(s) coloured (alpha %.2f)",
    ["Reprendre le contrôle dès que l'Insurgé touche le sol"] = "Regain control as soon as the Arisen touches the ground",
    ["effet visuel seulement (%s) : collision %s, dégâts %s"] = "visual effect only (%s): collision %s, damage %s",
    ["fin naturelle indisponible : fondu utilisé à la place"] = "natural end unavailable: fade used instead",
    ["Interrompre si la combinaison est relâchée avant la fin"] = "Interrupt if the combination is released before the end",
    ["Utiliser les règles de HUD Controls (s'il est installé)"] = "Use HUD Controls rules (if installed)",
    ["effet : taille non modifiable (ShellBaseParam illisible)"] = "effect: size cannot be changed (ShellBaseParam unreadable)",
    [">>> Maintiens la nouvelle combinaison, puis relâche tout…"] = ">>> Hold the new combination, then release everything…",
    ["Cercle d'incantation (Éclat sacré du Mage, ≈ 5,5 s natif)"] = "Casting circle (Mage's Holy Shine, ≈ 5.5 s native)",
    ["Arrêter l'essai"] = "Stop the test",
    ["Cercle d'incantation (Éclat sacré du Mage, ≈ 5,5 s natif) : toujours actif"] = "Casting circle (Mage's Holy Shine, ≈ 5.5 s native): always on",
    ["  Il fixe la durée (≈ 5,5 s) et garde la lévitation pilotable. Avec un bâton de mage il se resserre ;"] = "  It sets the duration (≈ 5.5 s) and keeps levitation steerable. With a mage staff it tightens;",
    ["  avec une autre arme (ex. lance du Chevalier mage) il reste ouvert : la frange d'écran donne alors la progression,"] = "  with another weapon (e.g. the Mystic Spearhand's spear) it stays open: the screen fringe then shows the progress,",
    ["  un message l'indique à l'écran, et le sort fonctionne quand même."] = "  a message says so on screen, and the spell still works.",
    ["Le cercle du jeu reste ouvert avec cette arme (il ne se referme qu'avec un bâton de mage)."] = "The game's circle stays open with this weapon (it only closes with a mage staff).",
    ["Le sort fonctionne quand même."] = "The spell still works.",
    ["  message « le cercle reste ouvert avec cette arme, le sort fonctionne quand même »"] = "  message \"the circle stays open with this weapon, the spell still works\"",
    ["lévitation : encore en StartLevitate après %.2f s, KeepLevitate demandé (%s)"] = "levitation: still in StartLevitate after %.2f s, KeepLevitate requested (%s)",
    ["lévitation : état 0,5 s après la demande de KeepLevitate = "] = "levitation: state 0.5 s after the KeepLevitate request = ",
    ["Frange d'écran pendant l'incantation"] = "Screen-edge fringe during the incantation",
    ["Afficher la frange"] = "Show the fringe",
    ["Largeur au début de la charge (% de l'écran)"] = "Width at the start of the charge (% of the screen)",
    ["Largeur à la fin de la charge (%)"] = "Width at the end of the charge (%)",
    ["Largeur quand le sort est prêt (%)"] = "Width when the spell is ready (%)",
    ["Opacité au début de la charge"] = "Opacity at the start of the charge",
    ["Opacité à la fin de la charge"] = "Opacity at the end of the charge",
    ["Opacité quand le sort est prêt"] = "Opacity when the spell is ready",
    ["Douceur du dégradé (plus haut = plus près des bords)"] = "Gradient softness (higher = closer to the edges)",
    ["Durée de la disparition (s)"] = "Fade-out time (s)",
    ["Couleur de la frange"] = "Fringe colour",
    ["Essayer la frange"] = "Preview the fringe",
    ["Cercle d'incantation dessiné"] = "Drawn casting circle",
    ["Cercle de portée dessiné au sol"] = "Range circle drawn on the ground",
    ["(cercle du jeu décoché : l'anneau suit la durée d'incantation réglée dans la Chorégraphie)"] = "(game circle unchecked: the ring follows the incantation time set in Choreography)",
    ["(le cercle de portée dessiné au sol se règle dans Outils de test)"] = "(the range circle drawn on the ground is set in Test tools)",
    ["toujours"] = "always",
    ["jamais"] = "never",
    ["sauf Guerrier et Mage (leur cercle du jeu se resserre déjà)"] = "except Fighter and Mage (their in-game circle already tightens)",
    ["Rayon au début de l'incantation (m)"] = "Radius at the start of the incantation (m)",
    ["Rayon quand le sort est prêt (m)"] = "Radius when the spell is ready (m)",
    ["Épaisseur du trait (px)"] = "Line thickness (px)",
    ["Couleur de l'anneau"] = "Ring colour",
    ["Couleur des détails (anneau intérieur, onde finale)"] = "Detail colour (inner ring, final wave)",
    ["Essayer l'anneau (sans lancer de sort)"] = "Preview the ring (without casting)",
    ["anneau du mod : affiché (mode %d, vocation %s)"] = "mod ring: shown (mode %d, vocation %s)",
    ["Portée en hauteur séparée (cylindre, mesurée depuis le sol)"] = "Separate vertical range (cylinder, measured from the ground)",
    ["caméra : le jeu a ramené la distance à %.2f (on la réécrit)"] = "camera: the game reset the distance to %.2f (rewriting it)",
    ["suivi des effets : effet retrouvé (taille dynamique active)"] = "effect tracking: effect found (dynamic size active)",
    ["cercle de Mage : couche 0 = %s | couche 1 = %s | endurance %s"] = "Mage circle: layer 0 = %s | layer 1 = %s | stamina %s",
    ["caméra : distance du joueur %.2f → jusqu'à %.2f pendant le sort"] = "camera: player distance %.2f → up to %.2f during the spell",
    ["%.1f m à plat (max %.1f), %+.1f m en hauteur (max +%.0f / -%.0f)"] = "%.1f m flat (max %.1f), %+.1f m in height (max +%.0f / -%.0f)",
    ["Moment du sort (effet de fin d'incantation, puis pions relevés) :"] = "Spell timing (end-of-incantation effect, then pawns revived):",
    ["remise à zéro de l'Insurgé (%s) : annulation %s, haut du corps %s"] = "Arisen reset (%s): cancellation %s, upper body %s",
    ["aucun mouvement enregistré : fais une réanimation normale une fois"] = "no motion recorded: perform a normal revival once",
    ["le fichier ne contient que %d effets (pas encore chargé ? réessaie)"] = "the file contains only %d effects (not loaded yet? try again)",
    ["Rupture : direction du regard illisible, cône remplacé par un cercle"] = "Rupture: gaze direction unreadable, cone replaced by a circle",
    ["effets sur les pions : aucun effet coché avec la cible « les pions »"] = "effects on pawns: no effect ticked with the target \"the pawns\"",
    ["compensation de l'endurance impossible (aucune méthode ne fonctionne)"] = "stamina compensation impossible (no method works)",
    ["animation écrasée par le jeu (mouvement %s/%s) : relancée à l'image %.0f"] = "animation overridden by the game (motion %s/%s): restarted at frame %.0f",
    ["séquence de relevé bloquée (phase %s) : pions restants relevés d'un coup"] = "revival sequence stuck (phase %s): remaining pawns revived at once",
    ["geste du sort introuvable : lumière tout de suite (envoie-moi le journal)"] = "spell gesture not found: light right away (send me the journal)",
    ["connecté à HUD Controls (élément « BardN Shards of Life — Éclats de vie »)"] = "connected to HUD Controls (element \"BardN Shards of Life — Shards of Life\")",
    ["  (essai : le mod bloque l'effet du jeu ; le journal dit ce qu'il a bloqué)"] = "  (experimental: the mod blocks the game's effect; the journal says what it blocked)",
    ["Les éclats ne sont pris que si le sort part (jamais en cas d'interruption)."] = "Shards are only spent if the spell goes off (never on interruption).",
    ["effet supprimé par le JEU %.2f s après le début de sa disparition (mode %d)"] = "effect removed by the GAME %.2f s after its fade-out began (mode %d)",
    [">>> CONFIRMER : tout remettre par défaut (réglages actuels sauvés avant) <<<"] = ">>> CONFIRM: reset everything to defaults (current settings saved first) <<<",
    ["Garder la lumière sacrée du jeu à la fin de l'incantation (Éclat sacré natif)"] = "Keep the game's holy light at the end of the incantation (native Holy Shine)",
    ["cercle : le haut du corps est en « %s » au lieu de la préparation → relance %d"] = "circle: the upper body is in \"%s\" instead of the preparation → retry %d",
    ["liste ShellParams illisible même après rechargement (réessaie dans quelques secondes)"] = "ShellParams list unreadable even after reloading (try again in a few seconds)",
    ["Avant le cercle ≈ %.2f s (+ %.2f s max si l'arme n'est pas rangée), puis cercle ≈ %.1f s"] = "Before the circle ≈ %.2f s (+ %.2f s max if the weapon is not sheathed), then circle ≈ %.1f s",
    ["Combinaison manette : 0x%X (défaut 0x40084 = croix gauche + B) — boutons enfoncés : 0x%X"] = "Gamepad combination: 0x%X (default 0x40084 = D-pad left + B) — buttons pressed: 0x%X",
    ["opacité : toujours aucun élément d'effet à colorer après 1,5 s (opacité et fondu sans effet)"] = "opacity: still no effect element to colour after 1.5 s (opacity and fade have no effect)",
    ["effets sur les pions : ni « à la réussite » ni « à la fin » n'est cochée pour la lumière finale"] = "effects on pawns: neither \"on success\" nor \"at the end\" is ticked for the final light",
}
-- v0.2 : textes ajoutés dans cette version
for k, v in pairs({
    ["(en cyan : ce qui a changé en v0.5 — compatibilité Shards of Life v0.48)"] = "(in cyan: what changed in v0.5 — Shards of Life v0.48 compatibility)",
    ["Séquence de relevé en cours : phase %s"] = "Revive sequence in progress: phase %s",
    ["Default = « Réglages par défaut… » (configuration recommandée) ; Custom = tes 3 emplacements ci-dessous."] = "Default = \"Default settings…\" (recommended configuration); Custom = your 3 slots below.",
    ["Déroulé : début → incantation → lumière finale → pions relevés un par un → atterrissage."] = "Sequence: start → incantation → final light → pawns revived one by one → landing.",
    ["Dernier pion (quand il y en a plusieurs) :"] = "Last pawn (when there are several):",
    ["mis en valeur : temps plus long, ralenti approfondi relâché à son réveil"] = "highlighted: longer beat, deeper slow motion released when it wakes up",
    ["durée multipliée par"] = "duration multiplied by",
    ["ralenti approfondi tant que la caméra est sur lui"] = "deeper slow motion while the camera is on it",
    ["vitesse du jeu pendant ce ralenti"] = "game speed during this slow motion",
    ["orbite : la caméra glisse lentement autour du pion visé"] = "orbit: the camera slowly glides around the targeted pawn",
    ["vitesse (degrés par seconde)"] = "speed (degrees per second)",
    ["angle maximal (degrés)"] = "maximum angle (degrees)",
    ["coup de zoom au réveil de chaque pion"] = "zoom punch when each pawn wakes up",
    ["intensité (degrés en moins)"] = "intensity (degrees less)",
    ["durée (s)"] = "duration (s)",
    ["Essayer le coup de zoom"] = "Try the zoom punch",
    ["Tout remettre à la vitesse normale"] = "Reset everything to normal speed",
    ["dernier pion : ralenti approfondi (x%.2f) jusqu'à son réveil"] = "last pawn: deeper slow motion (x%.2f) until it wakes up",
    [", dernier pion"] = ", last pawn",
    ["lumière finale"] = "final light",
    ["RETIRER DES PV À UN PION (v0.3 — branchement incertain)"] = "REMOVE HP FROM A PAWN (v0.3 — wiring uncertain)",
    ["Le journal dit quelle méthode a fait baisser les PV, et si le pion est à terre 0,5 s après."] = "The log says which method actually lowered the HP, and whether the pawn is down 0.5 s later.",
    ["pourcentage des PV max retiré (100 = à terre)"] = "percentage of max HP removed (100 = down)",
    ["Méthode :"] = "Method:",
    ["auto (cascade)"] = "auto (cascade)",
    ["3 recoverHp(−)"] = "3 recoverHp(−)",
    ["4 coup factice"] = "4 fake hit",
    ["autoriser la méthode 4 « coup factice » (damageProc) — peut faire planter le jeu"] = "allow method 4 \"fake hit\" (damageProc) — may crash the game",
    ["Retirer %d %% à %s"] = "Remove %d %% from %s",
    ["PV %s / %s%s"] = "HP %s / %s%s",
    ["  — À TERRE"] = "  — DOWN",
    ["Pion %d : absent du groupe"] = "Pawn %d: not in the party",
    ["Retirer %d %% aux trois"] = "Remove %d %% from all three",
    ["dernière méthode qui a marché : "] = "last method that worked: ",
    ["Pion "] = "Pawn ",
}) do R.EN[k] = v end
R.cache_t, R.cache_n = {}, 0
-- réglage initial : config déjà existante → français (comme avant), sinon automatique
if cfg.langue ~= "fr" and cfg.langue ~= "en" and cfg.langue ~= "auto" then
    cfg.langue = (version_lue ~= nil) and "fr" or "auto"
end
function R.en_actif()
    local l = cfg.langue
    if l == "en" then return true end
    if l == "fr" then return false end
    return R.langue_jeu ~= "fr"            -- auto : anglais tant que le jeu n'a pas dit « français »
end
-- une lettre (ASCII ou lettre accentuée du français) : sert à ne pas couper un mot
function R.lettre_avant(s, i)              -- dernier octet du caractère précédent, en position i
    local b = s:byte(i)
    if b == nil then return false end
    if (b >= 48 and b <= 57) or (b >= 65 and b <= 90) or (b >= 97 and b <= 122) then return true end
    if b >= 0x80 and b <= 0xBF then
        local p = s:byte(i - 1)
        return p == 0xC3 or (p == 0xC5 and b == 0x93)
    end
    return false
end
function R.lettre_apres(s, i)              -- premier octet du caractère suivant, en position i
    local b = s:byte(i)
    if b == nil then return false end
    if (b >= 48 and b <= 57) or (b >= 65 and b <= 90) or (b >= 97 and b <= 122) then return true end
    return b == 0xC3 or (b == 0xC5 and s:byte(i + 1) == 0x93)
end
function R.traduire(s)
    local EN = R.EN
    local e = EN[s]
    if e then return e end
    local a, b = s:match("^(.-)(##.*)$")        -- « texte##identifiant » : on traduit le texte seulement
    if a then return R.traduire(a) .. b end
    local lead, core, trail = s:match("^(%s*)(.-)(%s*)$")
    if (lead ~= "" or trail ~= "") and core ~= "" then
        e = EN[core]
        if e then return lead .. e .. trail end
    end
    if R.EN_CLES == nil then
        local l = {}
        for k in pairs(EN) do if #k >= 2 then l[#l + 1] = k end end
        table.sort(l, function(x, y) if #x ~= #y then return #x > #y end return x < y end)
        R.EN_CLES = l
    end
    local rempl, out = {}, s
    for _, k in ipairs(R.EN_CLES) do
        if out:find(k, 1, true) then
            local parts, init = {}, 1
            local k1, k2 = k:byte(1), k:byte(#k)
            local debut_mot = R.lettre_apres(k, 1)
            local fin_mot = R.lettre_avant(k, #k)
            while true do
                local i, j = out:find(k, init, true)
                if not i then break end
                local ok = true
                if debut_mot and i > 1 and R.lettre_avant(out, i - 1) then ok = false end
                if fin_mot and R.lettre_apres(out, j + 1) then ok = false end
                if ok then
                    parts[#parts + 1] = out:sub(init, i - 1)
                    rempl[#rempl + 1] = EN[k]
                    parts[#parts + 1] = "\1" .. #rempl .. "\2"
                    init = j + 1
                else
                    parts[#parts + 1] = out:sub(init, i)
                    init = i + 1
                end
            end
            parts[#parts + 1] = out:sub(init)
            out = table.concat(parts)
        end
    end
    if #rempl > 0 then out = out:gsub("\1(%d+)\2", function(n) return rempl[tonumber(n)] end) end
    out = out:gsub("«%s?", '"'):gsub("%s?»", '"'):gsub(" : ", ": ")
    return out
end
function R.T(s)
    if type(s) ~= "string" or s == "" or not R.en_actif() then return s end
    local c = R.cache_t[s]
    if c then return c end
    if R.cache_n > 4000 then R.cache_t, R.cache_n = {}, 0 end
    local ok, r = pcall(R.traduire, s)
    if not ok or type(r) ~= "string" then r = s end
    R.cache_t[s] = r
    R.cache_n = R.cache_n + 1
    return r
end
function R.fmt(f, ...) return string.format(R.T(f), ...) end
function R.dtext(t, ...) return draw.text(R.T(t), ...) end
-- étiquette de widget : le texte change avec la langue, l'identifiant ImGui reste celui du français
function R.etiquette(s)
    if type(s) ~= "string" or not R.en_actif() then return s end
    local t = R.T(s)
    if t ~= s and not s:find("##", 1, true) then return t .. "##" .. s end
    return t
end
-- v0.11 : langue du jeu (réglage « Auto »)
function R.changer_langue(l)
    cfg.langue = l
    R.cache_t, R.cache_n = {}, 0
    sauver()
end
function R.detecter_langue()
    R.langue_essais = (R.langue_essais or 0) + 1
    local trouve, notes = nil, 0
    for _, nom in ipairs({ "app.OptionManager", "app.GuiManager", "app.GameManager", "app.SaveDataManager" }) do
        local obj, td = nil, nil
        pcall(function() obj = sdk.get_managed_singleton(nom); td = sdk.find_type_definition(nom) end)
        if obj and td then
            local ms = {}
            pcall(function() ms = td:get_methods() end)
            for _, m in ipairs(ms) do
                local n = m:get_name()
                local lis = false
                pcall(function()
                    lis = n:sub(1, 3) == "get" and n:lower():find("language", 1, true) ~= nil
                          and #m:get_param_types() == 0 and not m:is_static()
                end)
                if lis then
                    local ok, v = pcall(function() return m:call(obj) end)
                    if ok and type(v) == "number" then
                        local nomE = nil
                        pcall(function()
                            for _, f in ipairs(m:get_return_type():get_fields()) do
                                if f:is_static() and f:get_data(nil) == v then nomE = f:get_name() end
                            end
                        end)
                        if notes < 4 then
                            notes = notes + 1
                            R.evenement(string.format("langue du jeu : %s.%s = %s (%s)", nom, n, tostring(v), tostring(nomE)))
                        end
                        if nomE and not trouve then trouve = nomE:lower():find("french", 1, true) and "fr" or "en" end
                    end
                end
            end
        end
        if trouve then break end
    end
    if trouve then
        if R.langue_jeu ~= trouve then R.cache_t, R.cache_n = {}, 0 end
        R.langue_jeu = trouve
    end
    return trouve
end
function R.suivre_langue()
    if cfg.langue ~= "auto" or R.langue_jeu ~= nil then return end
    local now = os.clock()
    if (R.langue_essais or 0) >= 4 or now < (R.langue_prochain or 0) then return end
    R.langue_prochain = now + 4.0
    if not R.detecter_langue() and (R.langue_essais or 0) >= 4 then
        R.evenement("langue du jeu non détectée : anglais (choisis Français / English en haut du menu)")
    end
end
-- le menu et l'écran passent par ces enveloppes : les textes sont traduits au moment de l'affichage
local imgui = setmetatable({}, { __index = function(t, k)
    local f = rawget(_G, "imgui")[k]
    if type(f) ~= "function" then return f end
    local texte = (k == "text" or k == "text_colored" or k == "text_wrapped" or k == "bullet_text")
    local widget = (k == "button" or k == "small_button" or k == "checkbox" or k == "slider_float" or k == "slider_int"
        or k == "drag_float" or k == "drag_int" or k == "tree_node" or k == "color_edit4" or k == "color_edit3" or k == "color_picker"
        or k == "collapsing_header" or k == "selectable" or k == "radio_button" or k == "input_text")
    local w = f
    if texte then
        w = function(...)
            local n = select("#", ...)
            local a = { ... }
            for i = 1, n do if type(a[i]) == "string" then a[i] = R.T(a[i]) end end
            return f(table.unpack(a, 1, n))
        end
    elseif widget then
        w = function(...)
            local n = select("#", ...)
            local a = { ... }
            if type(a[1]) == "string" then a[1] = R.etiquette(a[1]) end
            if (k == "slider_float" or k == "slider_int") and type(a[5]) == "string" then a[5] = R.T(a[5]) end
            return f(table.unpack(a, 1, n))
        end
    end
    rawset(t, k, w)
    return w
end })
local t0 = os.clock()
local function maintenant() return os.clock() - t0 end

local energie = 0          -- points entiers (segments pleins)
local unites = 0           -- éclats de vie : entier 0 .. energie_max (v0.10 : plus d'unités)
local en_combat, mode_combat = false, 0
local compteur_hors_combat = 0.0
local derniere_image = nil

local membres = {}                -- adresse Character -> {nom, chr}
local dernier_rafraichissement = -10
local dernier_gain_par_pion = {}
local reanimations_du_mod = {}

local evenements = {}
local journal_sale = false
local function evenement(txt)
    table.insert(evenements, 1, string.format("[%7.1f] %s", maintenant(), R.T(txt)))
    if #evenements > 250 then table.remove(evenements) end
    journal_sale = true
end
R.evenement = evenement

-- v0.2 : plus de table ni de closure par appel (la fonction la plus sollicitée du mod)
local function appeler(obj, nom, ...)
    if obj == nil then return nil end
    local f = obj.call
    if f == nil then return nil end
    local ok, v = pcall(f, obj, nom, ...)
    if ok then return v end
end
local function adresse(obj)
    if obj == nil then return nil end
    local f = obj.get_address
    if f == nil then return nil end
    local ok, a = pcall(f, obj)
    if ok then return a end
end
local function elements(obj)
    if obj == nil then return {} end
    local ok, t = pcall(function() return obj:get_elements() end)
    if ok and type(t) == "table" and #t > 0 then return t end
    local res = {}
    local n = appeler(obj, "get_Count")
    if type(n) == "number" then
        for i = 0, n - 1 do
            local e = appeler(obj, "get_Item", i)
            if e ~= nil then res[#res + 1] = e end
        end
    end
    return res
end

-- v0.2 : l'Insurgé est lu une fois par image (cache ouvert au début de on_frame, fermé à la fin ;
-- en dehors, chaque appel relit le jeu)
local joueur_cache, joueur_cache_ok = nil, false
local function joueur()
    if joueur_cache_ok then return joueur_cache end
    return appeler(sdk.get_managed_singleton("app.CharacterManager"), "get_ManualPlayer")
end
local function joueur_cache_ouvrir()
    joueur_cache = appeler(sdk.get_managed_singleton("app.CharacterManager"), "get_ManualPlayer")
    joueur_cache_ok = true
end
local function joueur_cache_fermer() joueur_cache_ok = false; joueur_cache = nil end

local function rafraichir_groupe()
    local nouv = {}
    local pm = sdk.get_managed_singleton("app.PawnManager")
    for i, pw in ipairs(elements(appeler(pm, "getAllPartyPawn"))) do
        local c = appeler(pw, "get_CachedCharacter")
        local a = adresse(c)
        if a then nouv[a] = { nom = "Pion " .. i, chr = c } end
    end
    membres = nouv
end

local function position(chr)
    local tr = appeler(appeler(chr, "get_GameObject"), "get_Transform")
    local p = appeler(tr, "get_Position")
    if p == nil then return nil end
    local ok, x, y, z = pcall(function() return p.x, p.y, p.z end)
    if ok and type(x) == "number" then return { x = x, y = y, z = z } end
end
local function distance(a, b)
    if a == nil or b == nil then return math.huge end
    local dx, dy, dz = a.x - b.x, a.y - b.y, a.z - b.z
    return math.sqrt(dx * dx + dy * dy + dz * dz)
end

local function noeud_fsm(chr)
    local am = appeler(chr, "get_ActionManager")
    if am == nil then return "" end
    local ok, fsm = pcall(function() return am:get_field("Fsm") end)
    if not ok or fsm == nil then return "" end
    return appeler(fsm, "getCurrentNodeName", 0) or ""
end

-- ----------------------------------------------------------------------------
-- API publique (interface séparée, autres mods)
-- ----------------------------------------------------------------------------
-- API publique de ce mod + lien avec BardN Shards of Life (obligatoire)
-- ----------------------------------------------------------------------------
_G.BardN_UltimateBreathOfLife = _G.BardN_UltimateBreathOfLife or {}
local api = _G.BardN_UltimateBreathOfLife
api.version = "0.5"
-- les éclats appartiennent à Shards of Life : ce mod en garde une copie lue à chaque image (R.sync_sol)
R.sol = nil
local function ajuster(delta, raison)
    local S = R.sol
    if S == nil then return end
    S.changer_unites(delta, raison)
    unites = S.get_unites(); energie = unites
end
api.ajuster = ajuster
for k, v in pairs({
    ["Interface à l'écran (HUD)"] = "On-screen interface (HUD)",
    ["Aperçu en direct de tous les éléments tant que ce tiroir est ouvert"] = "Live preview of every element while this drawer is open",
    ["L'aperçu montre la jauge, la barre d'incantation, la frange d'écran, l'anneau et le cercle de portée, même sans lancer de sort."] = "The preview shows the gauge, cast bar, screen fringe, ring and range circle even without casting a spell.",
    ["RÉGLAGE DE GROUPE (tous les éléments d'un coup)"] = "GROUP SETTINGS (all elements at once)",
    ["Opacité de tous les éléments"] = "Opacity of all elements",
    ["Décalage horizontal de la jauge et de la barre (fraction de l'écran)"] = "Horizontal offset of the gauge and bar (fraction of the screen)",
    ["Décalage vertical de la jauge et de la barre (fraction de l'écran)"] = "Vertical offset of the gauge and bar (fraction of the screen)",
    ["Remettre le réglage de groupe par défaut"] = "Reset group settings to default",
    ["HUD CONTROLS"] = "HUD CONTROLS",
    ["Opacité de la jauge"] = "Gauge opacity",
    ["Épaisseur de la barre (px)"] = "Bar thickness (px)",
    ["Couleur de la barre"] = "Bar colour",
    ["Remettre la barre par défaut"] = "Reset the bar to default",
    ["Remettre la frange par défaut"] = "Reset the fringe to default",
    ["Cercle de portée de Breath of Life (rayon réglé aussi dans Breath of Life > Portée) :"] = "Breath of Life range circle (radius also set in Breath of Life > Range):",
    ["  pendant l'incantation"] = "  while casting",
    ["  aperçu quand le sort est utilisable"] = "  preview when the spell is usable",
    ["  toujours (pour régler le rayon)"] = "  always (to adjust the radius)",
    ["Épaisseur du trait du cercle de portée"] = "Range circle line thickness",
    ["Cercle d'incantation dessiné (anneau qui se resserre autour du personnage) :"] = "Drawn casting circle (ring that tightens around the character):",
    ["Épaisseur du trait de l'anneau (px)"] = "Ring line thickness (px)",
    ["Remettre les cercles par défaut"] = "Reset the circles to default",
    ["(La frange d'écran se règle dans le tiroir « Interface à l'écran (HUD) ».)"] = "(The screen fringe is set in the \"On-screen interface (HUD)\" drawer.)",
    ["(Cercle de portée et cercle d'incantation : tiroir « Interface à l'écran (HUD) ».)"] = "(Range circle and casting circle: \"On-screen interface (HUD)\" drawer.)",
    ["BardN Shards of Life — Barre d'incantation"] = "BardN Shards of Life — Cast bar",
    ["BardN Shards of Life — Frange d'écran"] = "BardN Shards of Life — Screen fringe",
    ["BardN Shards of Life — Cercles au sol"] = "BardN Shards of Life — Ground circles",
    ["Slow Time (ralentissement du temps)"] = "Slow Time (time slowdown)",
    ["Durée du ralentissement (s réelles)"] = "Slowdown duration (real seconds)",
    ["Vitesse du monde (0,2 = -80 %)"] = "World speed (0.2 = -80%)",
    ["Incantation avant l'effet (s)"] = "Casting time before the effect (s)",
    ["L'Insurgé garde sa vitesse normale (compensation)"] = "The Arisen keeps normal speed (compensation)",
    ["Animation de sauvetage pendant l'incantation"] = "Rescue animation while casting",
    ["Combinaison manette : 0x%X (défaut 0x40088 = croix droite + B) — boutons enfoncés : 0x%X"] = "Controller combo: 0x%X (default 0x40088 = D-pad right + B) — buttons held: 0x%X",
    ["Jamais en même temps que Breath of Life ou un autre ralenti."] = "Never at the same time as Breath of Life or another slowdown.",
    ["Arrêter maintenant"] = "Stop now",
    ["Lancer Slow Time (test, gratuit)"] = "Cast Slow Time (test, free)",
    ["Slow Time désactivé"] = "Slow Time disabled",
    ["Slow Time déjà actif"] = "Slow Time already active",
    ["Slow Time en cours"] = "Slow Time active",
    ["Rupture supprimée"] = "Rupture removed",
    ["un autre ralenti est en cours"] = "another slowdown is active",
    ["Slow Time : le monde passe à x%.2f pendant %.1f s (Insurgé %s)"] = "Slow Time: the world drops to x%.2f for %.1f s (Arisen %s)",
    ["compensé"] = "compensated",
    ["ralenti aussi"] = "slowed too",
    ["Slow Time terminé (%s)"] = "Slow Time ended (%s)",
    ["Insurgé introuvable"] = "Arisen not found",
    ["Insurgé à terre"] = "Arisen down",
    ["mod coupé"] = "mod off",
    ["durée écoulée"] = "time elapsed",
    ["arrêt manuel"] = "manual stop",
    ["compensation de l'Insurgé x%.2f sur %d couche(s)"] = "Arisen compensation x%.2f on %d layer(s)",
}) do R.EN[k] = v end

-- v0.1 : textes propres à ce mod
for k, v in pairs({
    ["BardN Shards of Life est REQUIS : installe-le et active-le (ce mod reste inactif sans lui)."] = "BardN Shards of Life is REQUIRED: install and enable it (this mod stays inactive without it).",
    ["BardN Ultimate Breath of Life : BardN Shards of Life est introuvable (requis)"] = "BardN Ultimate Breath of Life: BardN Shards of Life not found (required)",
    ["Shards of Life détecté (v%s) : %d éclat(s)"] = "Shards of Life detected (v%s): %d shard(s)",
    ["Aperçu en direct de tous les éléments tant que ce tiroir est ouvert"] = "Live preview of every element while this drawer is open",
    ["L'aperçu montre la barre d'incantation, la frange d'écran, l'anneau et le cercle de portée, même sans lancer de sort."] = "The preview shows the cast bar, screen fringe, ring and range circle, even without casting a spell.",
    ["Opacité de tous les éléments"] = "Opacity of all elements",
    ["1. BARRE D'INCANTATION (sous la jauge de Shards of Life, pour Breath of Life et Slow Time)"] = "1. CAST BAR (under the Shards of Life gauge, for Breath of Life and Slow Time)",
    ["Opacité de la barre"] = "Bar opacity",
    ["Décalage horizontal de la barre (px)"] = "Horizontal offset of the bar (px)",
    ["Décalage vertical de la barre (px)"] = "Vertical offset of the bar (px)",
    ["Fond de la barre##barre_c1"] = "Bar background##barre_c1",
    ["Progression de la barre##barre_c2"] = "Bar progress##barre_c2",
    ["Barre prête##barre_c3"] = "Bar ready##barre_c3",
    ["2. FRANGE D'ÉCRAN PENDANT L'INCANTATION"] = "2. SCREEN FRINGE WHILE CASTING",
    ["3. CERCLES AU SOL"] = "3. GROUND CIRCLES",
    ["Cercle de portée de Breath of Life (rayon réglé aussi dans Breath of Life > Portée) :"] = "Breath of Life range circle (radius also set in Breath of Life > Range):",
    ["  message « le cercle reste ouvert avec cette arme, le sort fonctionne quand même »"] = "  message \"the circle stays open with this weapon, the spell still works\"",
    ["  lumière finale de Breath of Life jouée sur l'Insurgé quand Shards of Life le relève (seconde vie)"] = "  Breath of Life final light played on the Arisen when Shards of Life revives them (second life)",
    ["BardN Ultimate Breath of Life — Barre d'incantation"] = "BardN Ultimate Breath of Life — Cast bar",
    ["BardN Ultimate Breath of Life — Frange d'écran"] = "BardN Ultimate Breath of Life — Screen fringe",
    ["BardN Ultimate Breath of Life — Cercles au sol"] = "BardN Ultimate Breath of Life — Ground circles",
    ["Éclats de vie : %d   |   %s%s"] = "Shards of Life: %d   |   %s%s",
    ["(La jauge d'éclats elle-même se règle dans BardN Shards of Life.)"] = "(The shards gauge itself is set in BardN Shards of Life.)",
    ["(le cercle de portée dessiné au sol se règle dans « Interface à l'écran (HUD) »)"] = "(the range circle drawn on the ground is set in \"On-screen interface (HUD)\")",
    ["(Pour gagner ou perdre des éclats : tiroir « Outils de test » de BardN Shards of Life.)"] = "(To gain or lose shards: \"Test tools\" drawer of BardN Shards of Life.)",
    ["Les éclats de vie se règlent dans le mod BardN Shards of Life."] = "Shards of Life are set in the BardN Shards of Life mod.",
}) do R.EN[k] = v end
-- ----------------------------------------------------------------------------
-- Réanimation par le mod (validée en v0.2)
-- ----------------------------------------------------------------------------
local function reanimer(chr)
    local hit = appeler(chr, "get_Hit")
    if hit == nil then return false, "pas de HitController" end
    local pv_max = appeler(hit, "get_ReducedMaxHp")
    if type(pv_max) ~= "number" or pv_max <= 0 then return false, "PV max illisibles" end
    if R.sol then R.sol.marquer_reanimation(adresse(chr) or -1) end   -- v0.1 : pas d'éclat pour une réanimation faite ici
    local ok, err = pcall(function()
        return hit:call("recoverHp(System.Single, System.Boolean, System.Int32, System.Boolean)",
            pv_max, true, 0, true)
    end)
    if not ok then
        ok, err = pcall(function() return hit:call("recoverHp", pv_max, true, 0, true) end)
    end
    if not ok then return false, tostring(err) end
    return true, R.fmt("PV %.0f", pv_max)
end
api.reanimer = reanimer

local function pions_morts()
    local morts, total = {}, 0
    for adr, m in pairs(membres) do
        total = total + 1
        if appeler(m.chr, "get_IsDead") == true then morts[#morts + 1] = m end
    end
    return morts, total
end

-- ----------------------------------------------------------------------------
-- Ralenti (via.Application GlobalSpeed)
-- ----------------------------------------------------------------------------
local app_td = sdk.find_type_definition("via.Application")
local function vitesse_globale(v)
    pcall(function()
        sdk.call_native_func(sdk.get_native_singleton("via.Application"), app_td, "set_GlobalSpeed", v)
    end)
end
-- v0.41 : gestionnaire de ralentis : chaque source (« ralenti » de Breath, « temps » de Slow Time,
-- futurs ralentis) déclare sa vitesse ; la vitesse du monde est la PLUS BASSE des sources actives.
-- Une source « comp » (compensée) fait accélérer l'Insurgé de 1/vitesse (voir R.vit_compenser).
R.vit = { src = {}, v = 1.0, comp = false, t = 0 }
function R.vit_actif() return next(R.vit.src) ~= nil end
function R.vit_calcul()
    local v, comp = 1.0, false
    for _, x in pairs(R.vit.src) do
        if x.v < v then v = x.v end
        if x.comp then comp = true end
    end
    return v, comp
end
function R.vit_appliquer(force)
    local v, comp = R.vit_calcul()
    local now = os.clock()
    if force or R.vit.v ~= v or now - R.vit.t > 0.5 then
        R.vit.v, R.vit.t = v, now
        vitesse_globale(v)
    end
    if comp then
        if R.vit_compenser then R.vit_compenser(1.0 / math.max(0.05, v)) end
    elseif R.vit.comp then
        if R.vit_compenser then R.vit_compenser(1.0) end
    end
    R.vit.comp = comp
end
function R.vit_poser(nom, v, comp)
    R.vit.src[nom] = { v = v, comp = comp == true }
    R.vit_appliquer(true)
end
function R.vit_retirer(nom)
    R.vit.src[nom] = nil
    R.vit_appliquer(true)
end
function R.vit_tout()
    R.vit.src = {}
    R.vit_appliquer(true)
end
local fin_ralenti = nil
local ralenti_a = nil                -- v0.57 : départ différé du ralenti
local function lancer_ralenti(immediat)
    if not cfg.ralenti_actif then return end
    if not immediat and (cfg.ralenti_delai or 0) > 0 then
        ralenti_a = os.clock() + cfg.ralenti_delai
        return
    end
    ralenti_a = nil
    R.vit_poser("ralenti", cfg.ralenti_vitesse, false)
    fin_ralenti = os.clock() + cfg.ralenti_duree
end
local function suivre_ralenti()
    if ralenti_a and os.clock() >= ralenti_a then lancer_ralenti(true) end
    if fin_ralenti and os.clock() >= fin_ralenti then
        R.vit_retirer("ralenti")
        fin_ralenti = nil
    end
end

-- ----------------------------------------------------------------------------
-- Animation native de sauvetage, jouée dans le vide
-- requestActionCore : les paramètres sont construits d'après la signature
-- réelle (consignée dans le journal au premier essai).
-- ----------------------------------------------------------------------------
-- v0.4 : on ENREGISTRE les arguments que le jeu envoie lui-même à
-- requestActionCore pendant une réanimation native (« RescuePawn »,
-- « RescuePawnEnd »), puis on les REJOUE pour la résurrection héroïque.
local am_td = sdk.find_type_definition("app.ActionManager")
local m_action = am_td and am_td:get_method("requestActionCore")
local types_action = {}
local valeur_action = {}    -- true si le paramètre est un type valeur (entier, enum…)
if m_action then
    pcall(function()
        for i, p in ipairs(m_action:get_param_types()) do
            local tn = p:get_full_name()
            types_action[i] = tn
            local v = false
            pcall(function() v = p:is_value_type() end)
            if not v then
                pcall(function() v = p:get_parent_type():get_full_name() == "System.Enum" end)
            end
            if tn == "System.String" then v = false end
            valeur_action[i] = v
        end
    end)
end
local signature_action = table.concat(types_action, ", ")
local captures = {}         -- nom d'action -> liste d'arguments rejouables
local am_joueur_adr = nil    -- adresse de l'ActionManager de l'Insurgé
local derniere_action_joueur, heure_action_joueur = "?", -100
local diag = { signature = signature_action, captures = {} }

local function nom_de(ptr)
    local ok, s = pcall(function()
        local o = sdk.to_managed_object(ptr)
        return o and o:call("ToString")
    end)
    if ok and s then return tostring(s) end
end

local function capturer(nom, args)
    local liste, descr = {}, {}
    for i, tn in ipairs(types_action) do
        local brut = args[2 + i]
        if tn == "System.String" then
            liste[i] = nom
            descr[i] = tn .. " = « " .. nom .. " »"
        elseif tn == "System.Single" or tn == "System.Double" then
            local ok, f = pcall(sdk.to_float, brut)
            liste[i] = ok and f or 0.0
            descr[i] = tn .. " = " .. tostring(liste[i])
        elseif tn == "System.Boolean" then
            local ok, v = pcall(sdk.to_int64, brut)
            liste[i] = ok and (v & 0xFF) ~= 0 or false
            descr[i] = tn .. " = " .. tostring(liste[i])
        elseif valeur_action[i] then
            local ok, v = pcall(sdk.to_int64, brut)
            liste[i] = ok and (v & 0xFFFFFFFF) or 0
            descr[i] = tn .. " = " .. tostring(liste[i])
        else
            local ok, o = pcall(sdk.to_managed_object, brut)
            if ok and o then pcall(function() o:add_ref() end) end
            liste[i] = ok and o or nil
            descr[i] = tn .. " = objet"
        end
    end
    captures[nom] = liste
    diag.captures[nom] = descr
    evenement("animation « " .. nom .. " » enregistrée (" .. table.concat(descr, " | ") .. ")")
end

if m_action then
    sdk.hook(m_action, function(args)
        local okA, a = pcall(sdk.to_int64, args[2])
        if okA and am_joueur_adr and a == am_joueur_adr then
            for i = 3, 2 + #types_action do
                local n = (types_action[i - 2] == "System.String") and nom_de(args[i]) or nil
                if n then
                    derniere_action_joueur, heure_action_joueur = n, maintenant()
                    if n == "RescuePawn" and not captures.RescuePawn then pcall(capturer, "RescuePawn", args) end
                    if n == "RescuePawnEnd" and not captures.RescuePawnEnd then pcall(capturer, "RescuePawnEnd", args) end
                end
            end
        end
        return sdk.PreHookResult.CALL_ORIGINAL
    end, function(r) return r end)
end

local function demander_action(chr, nom_action)
    local am = appeler(chr, "get_ActionManager")
    if am == nil then return false, "pas d'ActionManager" end
    if m_action == nil then return false, "requestActionCore introuvable" end
    local c = captures[nom_action]
    if c == nil then
        -- essai direct : texte = nom de l'action, valeurs = 0
        local essai = {}
        for i, tn in ipairs(types_action) do
            if tn == "System.String" then essai[i] = nom_action
            elseif tn == "System.Boolean" then essai[i] = false
            elseif tn == "System.Single" or tn == "System.Double" then essai[i] = 0.0
            elseif valeur_action[i] then
                -- priorité observée dans le jeu natif : 10 ; autres valeurs : 0
                essai[i] = string.find(tn, "Priority", 1, true) and 10 or 0
            else essai[i] = nil end
        end
        local ok, err = pcall(function() return m_action:call(am, table.unpack(essai, 1, #types_action)) end)
        if not ok then return false, "essai direct : " .. tostring(err) end
        return true, "essai direct (pas encore enregistrée)"
    end
    local ok, err = pcall(function() return m_action:call(am, table.unpack(c, 1, #types_action)) end)
    if not ok then return false, tostring(err) end
    return true, "ok"
end
api.demander_action = demander_action

-- appel direct requestActionCore(priorité, nom, couche) — comme Skill Maker (v0.11)
local function action_directe(chr, priorite, nom, couche)
    local am = appeler(chr, "get_ActionManager")
    if am == nil or m_action == nil then return false end
    local ok = pcall(function() return m_action:call(am, priorite, nom, couche) end)
    return ok
end

-- remet l'Insurgé dans un état sain (corps entier + haut du corps)
local function debloquer(chr, raison)
    if chr == nil then return end
    local a = action_directe(chr, 0, "DefaultCancelAction", 0)
    local b = action_directe(chr, 0, "UpperBodyDefault", 1)
    evenement(R.fmt("remise à zéro de l'Insurgé (%s) : annulation %s, haut du corps %s",
        raison, a and "ok" or "échec", b and "ok" or "échec"))
end
api.debloquer = debloquer

-- ----------------------------------------------------------------------------
-- Animation forcée (techniques reprises de Skill Maker, alphaZomega)
--  * forcer l'état : via.motion.MotionFsm2Layer.setCurrentNode(nom, SetNodeInfo,
--    SetMotionTransitionInfo) — contourne le refus de requestActionCore
--  * mouvement brut : FullBodyLayer.changeMotion(banque, id, image, interp, 2, 0)
-- ----------------------------------------------------------------------------
local canal = nil       -- canalisation en cours : {debut, paye, verif_anim}
local m_set_node, interp_info, set_node_info = nil, nil, nil
local erreur_init_noeud = nil
-- initialisation paresseuse, chaque étape journalisée (v0.8)
local function init_noeud()
    if m_set_node and interp_info and set_node_info then return true end
    local etapes = {}
    local ok, err = pcall(function()
        local td = sdk.find_type_definition("via.motion.MotionFsm2Layer")
        if td == nil then error("type via.motion.MotionFsm2Layer introuvable") end
        m_set_node = td:get_method("setCurrentNode(System.String, via.behaviortree.SetNodeInfo, via.motion.SetMotionTransitionInfo)")
        if m_set_node == nil then
            for _, m in ipairs(td:get_methods()) do
                if m:get_name() == "setCurrentNode" and m:get_num_params() == 3 then m_set_node = m; break end
            end
        end
        if m_set_node == nil then error("méthode setCurrentNode introuvable") end
    end)
    etapes[#etapes + 1] = "méthode " .. (ok and "ok" or tostring(err))
    if interp_info == nil then
        local ok2, err2 = pcall(function()
            local o = sdk.create_instance("via.motion.SetMotionTransitionInfo")
            if o == nil then o = sdk.create_instance("via.motion.SetMotionTransitionInfo", true) end
            if o == nil then error("create_instance a renvoyé nil") end
            interp_info = o:add_ref() or o
        end)
        etapes[#etapes + 1] = "transition " .. (ok2 and "ok" or tostring(err2))
    end
    if set_node_info == nil then
        local ok3, err3 = pcall(function()
            local td = sdk.find_type_definition("via.behaviortree.SetNodeInfo")
            if td == nil then error("type SetNodeInfo introuvable") end
            if ValueType == nil then error("ValueType absent de cette version de REFramework") end
            set_node_info = ValueType.new(td)
        end)
        etapes[#etapes + 1] = "infos de nœud " .. (ok3 and "ok" or tostring(err3))
    end
    erreur_init_noeud = table.concat(etapes, " ; ")
    return m_set_node ~= nil and interp_info ~= nil and set_node_info ~= nil
end

local function couche_fsm(chr)
    local am = appeler(chr, "get_ActionManager")
    if am == nil then return nil end
    local ok, fsm = pcall(function() return am:get_field("Fsm") end)
    if not ok or fsm == nil then return nil end
    return appeler(fsm, "getLayer", 0)
end

local function forcer_noeud(chr, nom)
    if not init_noeud() then
        return false, "setCurrentNode indisponible (" .. tostring(erreur_init_noeud) .. ")"
    end
    local couche = couche_fsm(chr)
    if couche == nil then return false, "couche FSM introuvable" end
    pcall(function() interp_info:call("set_InterpolationFrame", 12.0) end)
    local ok, err = pcall(function() return m_set_node:call(couche, nom, set_node_info, interp_info) end)
    if not ok then return false, tostring(err) end
    return true, "ok"
end
api.forcer_noeud = forcer_noeud

local function couche_corps(chr)
    local ok, c = pcall(function() return chr:get_field("FullBodyLayer") end)
    if ok and c then return c end
    local okM, mot = pcall(function() return chr:call("get_Motion") end)
    if okM and mot then return appeler(mot, "getLayer", 0) end
end

local mouvement_precedent, mouvement_en_cours = nil, false
local function jouer_mouvement(chr, image, interp)
    if cfg.anim_bank < 0 or cfg.anim_id < 0 then
        return false, "aucun mouvement enregistré : fais une réanimation normale une fois"
    end
    local couche = couche_corps(chr)
    if couche == nil then return false, "couche de mouvement introuvable" end
    -- mémorise le mouvement en cours pour pouvoir le remettre à l'interruption
    -- (jamais l'animation de sauvetage elle-même : bug de la v0.9)
    if not mouvement_en_cours then
        local mn = appeler(couche, "get_HighestWeightMotionNode")
        local b0, i0 = appeler(mn, "get_MotionBankID"), appeler(mn, "get_MotionID")
        if type(b0) == "number" and type(i0) == "number" and not (b0 == cfg.anim_bank and i0 == cfg.anim_id) then
            mouvement_precedent = { b0, i0 }
        else
            mouvement_precedent = nil
        end
    end
    local ok, err = pcall(function()
        return couche:call("changeMotion(System.UInt32, System.UInt32, System.Single, System.Single, via.motion.InterpolationMode, via.motion.InterpolationCurve)",
            cfg.anim_bank, cfg.anim_id, image or 0.0, interp or 20.0, 2, 0)
    end)
    if not ok then
        if not mouvement_en_cours then mouvement_precedent = nil end
        return false, tostring(err)
    end
    mouvement_en_cours = true
    return true, "ok"
end

-- mouvement réellement joué en ce moment (v0.22)
local function mouvement_actuel(chr)
    local couche = couche_corps(chr)
    local mn = appeler(couche, "get_HighestWeightMotionNode")
    return appeler(mn, "get_MotionBankID"), appeler(mn, "get_MotionID")
end

-- coupe le mouvement brut : remet le mouvement d'avant (v0.9)
local function arreter_mouvement(chr)
    if not mouvement_en_cours then return false end
    mouvement_en_cours = false
    local couche = couche_corps(chr)
    if couche == nil or mouvement_precedent == nil then return false end
    local p = mouvement_precedent
    mouvement_precedent = nil
    pcall(function()
        couche:call("changeMotion(System.UInt32, System.UInt32, System.Single, System.Single, via.motion.InterpolationMode, via.motion.InterpolationCurve)",
            p[1], p[2], 0.0, 10.0, 2, 0)
    end)
    return true
end

-- enregistre le mouvement joué pendant une réanimation native (une fois suffit)
local function enregistrer_mouvement()
    if canal or cfg.anim_bank >= 0 then return end       -- v0.2 : déjà relevé → rien à lire
    local pj = joueur()
    if pj == nil or noeud_fsm(pj) ~= "RescuePawn" then return end
    local couche = couche_corps(pj)
    local mn = appeler(couche, "get_HighestWeightMotionNode")
    if mn == nil then return end
    local bank, id = appeler(mn, "get_MotionBankID"), appeler(mn, "get_MotionID")
    if cfg.anim_bank < 0 and type(bank) == "number" and type(id) == "number" then
        cfg.anim_bank, cfg.anim_id = math.tointeger(bank) or bank, math.tointeger(id) or id
        cfg.anim_fin = appeler(couche, "get_EndFrame") or 0.0
        sauver()
        evenement(R.fmt("mouvement de sauvetage enregistré : banque %d, id %d", cfg.anim_bank, cfg.anim_id))
    end
end

local function demarrer_animation(chr)
    local m = cfg.methode_animation
    if m == 1 then
        local ok, info = forcer_noeud(chr, "RescuePawn")
        if ok then return true, "état RescuePawn forcé" end
        evenement("forcer l'état : " .. info .. " → essai du mouvement brut")
        m = 2
    end
    if m == 2 then
        local ok, info = jouer_mouvement(chr)
        if ok then return true, "mouvement brut joué" end
        return false, info
    end
    return demander_action(chr, "RescuePawn")
end

-- ----------------------------------------------------------------------------
-- Effets visuels du jeu (« shells ») — méthode reprise de Skill Maker (alphaZomega)
-- ShellManager.requestCreateShell(GameObject, position, rotation,
--   ShellCreateInfo{ShellParamIdHash}, ShellParamData, nil, nil)
-- La taille passe par ShellBaseParam.UseScale/Scale, la durée par UseLifeTime/LifeTime
-- (modifiés juste le temps de la création puis remis).
-- ----------------------------------------------------------------------------
local F_MAGIE = "AppSystem/shell/userdata/humanshellparamdata_jobmagic.user"
local F_LICHE = "AppSystem/ch/ch227/userdata/ch227shellparamdata.user"
-- liste triée avec l'utilisateur le 21/10 (retirés : chant et base de la Liche
-- = plantage / pose en T ; Zone des dieux = vide l'endurance ; point de soin,
-- purification niv. 1, hâte, bouclier : rejetés ; brise-sort et explosion de
-- l'éclat sacré = frappent les ennemis)
-- v0.26 : l'utilisateur ne garde que l'effet de la Liche (+ sceau magique à essayer)
local DEF_EFFET = { canal = false, reussite = false, taille = 1.0, copies = 1, emplacement = 1,
    ecart = 0.0, opacite_croissante = true, opacite_min = 0.1, inverse_reussite = true,
    fin_mode = 2, hauteur = 0.0, final = false, coeur = false, deco_mode = 1 }   -- v0.27 : 1 immédiate, 2 fondu, 3 rétrécir, 4 grandir + fondu, 5 fin naturelle
local function def_effet(over)
    local d = {}
    for k, v in pairs(DEF_EFFET) do d[k] = v end
    for k, v in pairs(over or {}) do d[k] = v end
    return d
end
local EFFETS = {
    -- v0.39 : grande lumière finale, jouée APRÈS le ralenti, purement visuelle
    { cle = "final",       nom = "Lumière finale (lumière intense)", choix = "final", decoratif = true,
      def = def_effet({ final = true, hauteur = 1.0, taille = 1.0, deco_mode = 1 }), note = "visuel seulement" },
}
-- réglages par effet (complétés avec les valeurs par défaut)
local function completer_effets()
    if cfg.effets == defauts.effets then cfg.effets = copie_profonde(BASE.effets) end   -- v0.14
    if type(cfg.effets) ~= "table" then cfg.effets = {} end
    for _, e in ipairs(EFFETS) do
        local r = cfg.effets[e.cle]
        if type(r) ~= "table" then r = {}; cfg.effets[e.cle] = r end
        for k, v in pairs(e.def) do
            if type(r[k]) ~= type(v) then r[k] = v end
        end
        r.copies = math.max(1, math.min(6, math.floor(r.copies)))
    end
end
completer_effets()
if version_lue ~= nil and version_lue < 34 then cfg.cfg_version = 34; sauver() end
if cfg.cfg_version < 35 then                     -- v0.4 : anciens défauts de l'orbite / du coup de zoom
    if cfg.focus_orbite_vitesse == 12.0 then cfg.focus_orbite_vitesse = 6.0 end
    if cfg.focus_orbite_max == 40.0 then cfg.focus_orbite_max = 12.0 end
    if cfg.focus_punch_duree == 0.5 then cfg.focus_punch_duree = 0.3 end
    cfg.cfg_version = 35
    sauver()
end
cfg.cfg_version = 34

local gest_shell = nil
local donnees_shell = {}           -- chemin -> ShellParamData
local restaurations = {}           -- {base, sauvegarde, heure}

-- v0.39 : sources possibles de la lumière finale (fichier, n°, nom)
-- v0.53 : liste élargie ; plusieurs sources cumulables (cfg.final_choix[cle] = {on, taille, hauteur})
local F_ARCHER_M = "AppSystem/shell/userdata/humanshellparamdata_job08.user"
local F_ESCROC  = "AppSystem/shell/userdata/humanshellparamdata_job09.user"
local F_GRIMOIRE = "AppSystem/shell/userdata/humanshellparamdata_magicbook.user"
local F_LANCIER = "AppSystem/shell/userdata/humanshellparamdata_job07.user"
R.SOURCES_FINAL = {
    -- lumière sacrée / soin (Mage)
    { cle = "holy",      f = F_MAGIE, id = 24, nom = "Éclat sacré" },
    { cle = "holy2",     f = F_MAGIE, id = 27, nom = "Éclat sacré niv. 2" },
    { cle = "empyree",   f = F_MAGIE, id = 32, nom = "Empyrée" },
    { cle = "cure",      f = F_MAGIE, id = 20, nom = "Purification" },
    { cle = "cure2",     f = F_MAGIE, id = 21, nom = "Purification niv. 2" },
    { cle = "soin",      f = F_MAGIE, id = 17, nom = "Point de soin" },
    { cle = "hate",      f = F_MAGIE, id = 22, nom = "Hâte" },
    { cle = "hate2",     f = F_MAGIE, id = 23, nom = "Hâte niv. 2" },
    { cle = "bouclier",  f = F_MAGIE, id = 19, nom = "Bouclier (Guard bit)" },
    { cle = "brise",     f = F_MAGIE, id = 30, nom = "Brise-sort" },
    { cle = "brise2",    f = F_MAGIE, id = 31, nom = "Brise-sort niv. 2" },
    -- grimoire (versions « livre » des sorts)
    { cle = "g_soin",    f = F_GRIMOIRE, id = 0,  nom = "Grimoire : Point de soin" },
    { cle = "g_cure",    f = F_GRIMOIRE, id = 2,  nom = "Grimoire : Purification" },
    { cle = "g_empyree", f = F_GRIMOIRE, id = 13, nom = "Grimoire : Empyrée" },
    { cle = "g_holy",    f = F_GRIMOIRE, id = 14, nom = "Grimoire : Éclat sacré" },
    -- autres vocations / monstres
    { cle = "sceau",     f = F_LANCIER, id = 5,  nom = "Lancier mystique : sceau magique" },
    { cle = "dragon",    f = F_ESCROC,  id = 19, nom = "Escroc : dragon de fumée (corps)" },
    { cle = "dragon2",   f = F_ESCROC,  id = 20, nom = "Escroc : dragon de fumée (souffle)" },
    { cle = "liche",     f = F_LICHE,   id = 2,  nom = "Liche : signe de résurrection" },
}
local function source_effet(e)
    if e.perso then return cfg.effet_perso_fichier, cfg.effet_perso_id end
    if e.choix == "final" then
        local src = e.src or R.SOURCES_FINAL[math.max(1, math.min(#R.SOURCES_FINAL, cfg.final_source))]
        return src.f, src.id
    end
    return e.f, e.id
end

R.dernier_sort = "resurrection"     -- v0.28 : sort des effets en cours (aussi après la fin du canal)
local function taille_effet(mult, progression)
    local t
    if cfg.effet_suivre_rayon then t = cfg.rayon / math.max(0.1, cfg.effet_rayon_base)
    else t = cfg.effet_echelle_fixe end
    if progression then t = t * math.max(0.03, math.min(1, progression)) end
    return math.max(0.01, t * (mult or 1.0))
end

-- ----------------------------------------------------------------------------
-- Suivi des effets créés (v0.20) : retrouvés dans ShellManager.ShellList,
-- taille ajustée chaque image pour suivre l'onde, supprimés à l'interruption
-- ----------------------------------------------------------------------------
local attentes = {}          -- {avant = {adresse=true}, positions = {...}, fin, mult, dyn}
local suivis = {}            -- {shell, mult, dyn}
local effets_diag_ok, effets_diag_ko = false, false

local function liste_shells()
    local res = {}
    local gm = sdk.get_managed_singleton("app.ShellManager")
    if gm == nil then return res end
    local l = nil
    pcall(function() l = gm:get_field("ShellList") end)
    if l == nil then pcall(function() l = gm.ShellList end) end
    if l == nil then return res end
    local n = nil
    pcall(function() n = l:call("get_Count") end)
    if type(n) == "number" then
        for i = 0, n - 1 do
            local sh = nil
            pcall(function() sh = l:call("get_Item", i) end)
            if sh then res[#res + 1] = sh end
        end
    else
        pcall(function()
            for _, sh in pairs(l._items) do if sh then res[#res + 1] = sh end end
        end)
    end
    return res
end

local function adresses_shells()
    local a = {}
    for _, sh in ipairs(liste_shells()) do
        local ad = adresse(sh)
        if ad then a[ad] = true end
    end
    return a
end

local function transform_shell(sh)
    local tr = nil
    pcall(function() tr = sh:call("get_GameObject"):call("get_Transform") end)
    return tr
end

-- opacité (et teinte) des effets : via.Color appliquée aux effets créés par le shell
-- (méthode Skill Maker : EffectManager2 → CreatedEffectDataList → list → setRootColor)
local type_couleur = sdk.find_type_definition("via.Color")
local function liste_elements(l)
    local res = {}
    if l == nil then return res end
    local n = nil
    pcall(function() n = l:call("get_Count") end)
    if type(n) == "number" then
        for i = 0, n - 1 do
            local x = nil
            pcall(function() x = l:call("get_Item", i) end)
            if x then res[#res + 1] = x end
        end
        return res
    end
    pcall(function() for _, x in pairs(l._items) do if x then res[#res + 1] = x end end end)
    return res
end
local couleur_signalee = false
local function colorer_shell(sh, a)
    local col = nil
    pcall(function()
        col = ValueType.new(type_couleur)
        col:call(".ctor(via.vec4)", Vector4f.new(1.0, 1.0, 1.0, math.max(0, math.min(1, a))))
    end)
    if col == nil then return 0 end
    local efx2 = nil
    pcall(function() efx2 = sh:get_field("<EffectManager2>k__BackingField") end)
    if efx2 == nil then pcall(function() efx2 = sh["<EffectManager2>k__BackingField"] end) end
    if efx2 == nil then
        R.coul_debut = R.coul_debut or os.clock()
        if not R.coul_ok and not R.coul_efx2 and os.clock() - R.coul_debut > 1.5 then
            R.coul_efx2 = true
            local tn = "?"
            pcall(function() tn = sh:get_type_definition():get_full_name() end)
            evenement("opacité : EffectManager2 introuvable sur l'effet (" .. tn .. ") — opacité et fondu sans effet")
        end
        return 0
    end
    local n = 0
    local donnees = nil
    pcall(function() donnees = efx2:get_field("CreatedEffectDataList") end)
    if donnees == nil then pcall(function() donnees = efx2.CreatedEffectDataList end) end
    for _, d in ipairs(liste_elements(donnees)) do
        local l = nil
        pcall(function() l = d:get_field("list") end)
        if l == nil then pcall(function() l = d.list end) end
        for _, ce in ipairs(liste_elements(l)) do
            if pcall(function() ce:call("setRootColor", col) end) then n = n + 1
            elseif pcall(function() ce:call("set_Color", col) end) then n = n + 1 end
        end
    end
    -- v0.31 : diagnostic fiable (les éléments d'effet n'existent pas encore à la création)
    R.coul_debut = R.coul_debut or os.clock()
    if n > 0 and not R.coul_ok then
        R.coul_ok = true
        evenement(R.fmt("opacité : %d élément(s) d'effet colorés (alpha %.2f)", n, a))
    elseif n == 0 and not R.coul_ok and not couleur_signalee and os.clock() - R.coul_debut > 1.5 then
        couleur_signalee = true
        evenement("opacité : toujours aucun élément d'effet à colorer après 1,5 s (opacité et fondu sans effet)")
    end
    return n
end

local function suivre_effets()
    -- 1) retrouver nos effets par leur numéro de demande (méthode Skill Maker v0.21) :
    --    ShellManager["<InstantiatedShellDict>k__BackingField"][n°]["<Shell>k__BackingField"]
    if #attentes > 0 then
        local gm = sdk.get_managed_singleton("app.ShellManager")
        local dict = nil
        pcall(function() dict = gm:get_field("<InstantiatedShellDict>k__BackingField") end)
        if dict == nil then pcall(function() dict = gm["<InstantiatedShellDict>k__BackingField"] end) end
        local reste = {}
        for _, at in ipairs(attentes) do
            local trouve = false
            if dict then
                local present = false
                pcall(function() present = dict:call("ContainsKey", at.id) end)
                if present then
                    local inst = nil
                    pcall(function() inst = dict:call("get_Item", at.id) end)
                    if inst == nil then pcall(function() inst = dict[at.id] end) end
                    local sh = nil
                    pcall(function() sh = inst:get_field("<Shell>k__BackingField") end)
                    if sh == nil then pcall(function() sh = inst["<Shell>k__BackingField"] end) end
                    if sh then
                        pcall(function() sh:add_ref() end)
                        suivis[#suivis + 1] = { shell = sh, mult = at.mult, dyn = at.dyn, r = at.r,
                            dx = at.dx or 0, dz = at.dz or 0, au_sol = at.au_sol }
                        trouve = true
                        if not effets_diag_ok then
                            effets_diag_ok = true
                            evenement("suivi des effets : effet retrouvé (taille dynamique active)")
                        end
                    end
                end
            end
            if not trouve then
                if os.clock() < at.fin then
                    reste[#reste + 1] = at
                elseif not effets_diag_ko then
                    effets_diag_ko = true
                    evenement("suivi des effets : effet n° " .. tostring(at.id) .. " non retrouvé ("
                        .. (dict and "registre lu" or "registre InstantiatedShellDict illisible") .. ")")
                end
            end
        end
        attentes = reste
    end
    -- 2) taille, position et opacité qui suivent l'onde ; effet « à l'envers » au lancement
    if #suivis == 0 then return end
    local garder = {}
    local pj = joueur()
    local centre = pj and position(pj)
    for _, s2 in ipairs(suivis) do
        local tr = transform_shell(s2.shell)
        local r = s2.r or DEF_EFFET
        if tr == nil and s2.inverse_debut and not R.fin_diag then
            R.fin_diag = true
            evenement(R.fmt("effet supprimé par le JEU %.2f s après le début de sa disparition (mode %d)",
                os.clock() - s2.inverse_debut, s2.fin_mode or 0))
        end
        if tr and s2.inverse_debut and not s2.diag_fin then
            s2.diag_fin = true
            evenement(R.fmt("disparition de l'effet : mode %d sur %.1f s", s2.fin_mode or 0, cfg.inverse_duree))
        end
        if tr then
            if s2.inverse_debut then
                -- v0.27 : disparition selon le mode choisi pour l'effet
                local q = (os.clock() - s2.inverse_debut) / math.max(0.05, cfg.inverse_duree)
                local mode = s2.fin_mode or 2
                if q >= 1 then
                    pcall(function() local go = s2.shell:call("get_GameObject"); go:call("destroy", go) end)
                else
                    local k = 1 - q
                    local t0 = s2.taille_lancement
                    local t = t0
                    if mode == 3 then t = math.max(0.01, t0 * k)                       -- rétrécir
                    elseif mode == 4 then t = t0 * (1 + cfg.fin_expansion * q) end    -- grandir
                    if mode == 3 or mode == 4 then
                        pcall(function() tr:call("set_LocalScale", Vector3f.new(t, t, t)) end)
                    end
                    if mode == 3 and centre and s2.au_sol and (s2.dx ~= 0 or s2.dz ~= 0) then
                        pcall(function() tr:call("set_Position", Vector3f.new(centre.x + s2.dx * k, centre.y + cfg.effet_hauteur, centre.z + s2.dz * k)) end)
                    end
                    if mode ~= 5 then colorer_shell(s2.shell, (1 - q ^ math.max(0.2, cfg.fondu_courbe)) * (s2.alpha_lancement or 1)) end
                    garder[#garder + 1] = s2
                end
            elseif canal then
                local p = canal.prep and 0 or math.max(0, math.min(1, (maintenant() - canal.debut) / math.max(0.1, R.duree_sort())))
                if s2.dyn and not canal.prep then
                    local t = taille_effet(s2.mult, p)
                    pcall(function() tr:call("set_LocalScale", Vector3f.new(t, t, t)) end)
                end
                if centre and s2.au_sol and (s2.dx ~= 0 or s2.dz ~= 0) then
                    local f = s2.dyn and math.max(0.03, p) or 1
                    pcall(function() tr:call("set_Position", Vector3f.new(centre.x + s2.dx * f, centre.y + cfg.effet_hauteur, centre.z + s2.dz * f)) end)
                end
                if r.opacite_croissante then
                    colorer_shell(s2.shell, r.opacite_min + (1 - r.opacite_min) * p)
                end
                garder[#garder + 1] = s2
            end
            -- sinon : on arrête de suivre (l'effet vit sa vie)
        end
    end
    suivis = garder
end

-- v0.26 : au lancement, les effets marqués « à l'envers » rétrécissent au lieu d'être supprimés
-- v0.27 : fin naturelle — on demande à l'effet du jeu de se terminer lui-même
local methode_fin_naturelle = nil
local fin_naturelle_signalee = false
local function finir_naturellement(sh)
    local noms = methode_fin_naturelle and { methode_fin_naturelle }
        or { "requestFinish", "setFinish", "finish", "requestEnd", "endShell", "requestKill", "kill" }
    for _, n in ipairs(noms) do
        if pcall(function() sh:call(n) end) then
            if methode_fin_naturelle == nil then
                methode_fin_naturelle = n
                evenement("fin naturelle des effets : méthode « " .. n .. " »")
            end
            return true
        end
    end
    return false
end

-- lance la disparition des effets suivis selon le mode de chacun ; renvoie le nombre
local function lancer_fin_effets(raison)
    local n = 0
    local garder = {}
    for _, s2 in ipairs(suivis) do
        local r = s2.r or DEF_EFFET
        local mode = r.fin_mode or 2
        if s2.inverse_debut then
            garder[#garder + 1] = s2
        elseif mode == 1 then
            pcall(function() local go = s2.shell:call("get_GameObject"); go:call("destroy", go) end)
        else
            if mode == 5 and not finir_naturellement(s2.shell) then
                mode = 2                       -- aucune méthode : on retombe sur le fondu
                if not fin_naturelle_signalee then
                    fin_naturelle_signalee = true
                    evenement("fin naturelle indisponible : fondu utilisé à la place")
                end
            end
            s2.inverse_debut = os.clock()
            s2.fin_mode = mode
            s2.taille_lancement = s2.dyn and taille_effet(s2.mult, 1) or taille_effet(s2.mult)
            s2.alpha_lancement = 1.0
            garder[#garder + 1] = s2
            n = n + 1
        end
    end
    suivis = garder
    return n
end
local function effets_a_l_envers() return lancer_fin_effets("sort lancé") end

local function supprimer_effets_suivis(raison)
    local n = 0
    local reste = {}
    for _, s2 in ipairs(suivis) do
        if s2.inverse_debut then
            reste[#reste + 1] = s2                  -- en train d'être joué à l'envers
        else
            local ok = pcall(function()
                local go = s2.shell:call("get_GameObject")
                go:call("destroy", go)
            end)
            if ok then n = n + 1 end
        end
    end
    suivis, attentes = reste, {}
    if n > 0 then evenement(n .. " effet(s) supprimé(s) (" .. (raison or "interruption") .. ")") end
end

-- lecture d'un élément de la liste ShellParams, par plusieurs chemins (v0.15)
local function liste_params(ud)
    local l = nil
    pcall(function() l = ud:get_field("ShellParams") end)
    if l == nil then pcall(function() l = ud.ShellParams end) end
    return l
end
local function nb_params(l)
    local n = nil
    pcall(function() n = l:call("get_Count") end)
    if n == nil then pcall(function() n = l:get_field("_size") end) end
    return n
end
local function param_n(l, id)
    local p = nil
    pcall(function() p = l:call("get_Item", id) end)
    if p == nil then pcall(function() p = l:get_field("_items"):get_element(id) end) end
    if p == nil then pcall(function() p = l._items[id] end) end
    return p
end
local function champ_objet(o, nom)
    local v = nil
    pcall(function() v = o:get_field(nom) end)
    if v == nil then pcall(function() v = o[nom] end) end
    return v
end

local function charger_fichier(f)
    local ud = donnees_shell[f]
    if ud == nil then
        ud = sdk.create_userdata("app.ShellParamData", f)
        if ud == nil then return nil end
        pcall(function() ud = ud:add_ref() or ud end)
        donnees_shell[f] = ud
    end
    return ud
end
-- préchargement de tous les fichiers de la liste (laisse le temps au jeu de les lire)
local precharge = false
local joueur_precharge = nil
local function precharger()
    -- v0.23 : seulement quand l'Insurgé est en jeu ; nouveau chargement de partie
    -- (Insurgé différent) → on oublie les données et on recharge
    local pj = joueur()
    if pj == nil then return end
    local a = adresse(pj)
    if a ~= joueur_precharge then
        joueur_precharge = a
        donnees_shell = {}
        precharge = false
    end
    if precharge then return end
    precharge = true
    local vus = {}
    for _, e in ipairs(EFFETS) do
        if e.f and not vus[e.f] then vus[e.f] = true; pcall(charger_fichier, e.f) end
    end
    -- v0.51 : aussi les sources de la lumière finale et l'effet personnalisé
    for _, src in ipairs(R.SOURCES_FINAL or {}) do
        if not vus[src.f] then vus[src.f] = true; pcall(charger_fichier, src.f) end
    end
    if cfg.effet_perso_fichier and not vus[cfg.effet_perso_fichier] then pcall(charger_fichier, cfg.effet_perso_fichier) end
end

-- v0.38 : effet décoratif (méthode Skill Maker « is_decorative ») :
--   shell["<ColliderStep>k__BackingField"] = 99999 ; HitCtrl:get_CachedRequestSetCollider():set_Enabled(false)
--   + multiplicateur d'attaque à 0 par sécurité
function R.decorer(sh, mode)
    -- mode 1 : collision coupée + dégâts à 0 ; mode 2 : dégâts à 0 seulement (si l'effet
    -- a besoin de sa collision pour éclater) ; mode 3 : rien (l'effet peut toucher)
    if mode == 3 then return false, false, false end
    local ok1 = mode ~= 2 and pcall(function() sh["<ColliderStep>k__BackingField"] = 99999 end)
    local hc = nil
    pcall(function() hc = sh:call("get_HitCtrl") end)
    if hc == nil then pcall(function() hc = sh["<HitCtrl>k__BackingField"] end) end
    local ok2 = mode ~= 2 and hc ~= nil and pcall(function() hc:call("get_CachedRequestSetCollider"):call("set_Enabled", false) end)
    local ok3 = hc ~= nil and pcall(function() hc["<AttackRate>k__BackingField"] = 0.0 end)
    return ok1, ok2, ok3
end
function R.suivre_deco()
    if R.deco == nil or #R.deco == 0 then return end
    local gm = sdk.get_managed_singleton("app.ShellManager")
    local dict = nil
    pcall(function() dict = gm:get_field("<InstantiatedShellDict>k__BackingField") end)
    if dict == nil then pcall(function() dict = gm["<InstantiatedShellDict>k__BackingField"] end) end
    local reste = {}
    for _, d in ipairs(R.deco) do
        local fait = false
        if dict then
            local present = false
            pcall(function() present = dict:call("ContainsKey", d.id) end)
            if present then
                local inst, sh = nil, nil
                pcall(function() inst = dict:call("get_Item", d.id) end)
                pcall(function() sh = inst:get_field("<Shell>k__BackingField") end)
                if sh == nil then pcall(function() sh = inst["<Shell>k__BackingField"] end) end
                if sh then
                    local a, b, c = R.decorer(sh, d.mode or 1)
                    fait = true
                    if not R.deco_note then
                        R.deco_note = true
                        evenement(R.fmt("effet visuel seulement (%s) : collision %s, dégâts %s",
                            d.nom or "?", (a or b) and "coupée" or "NON coupée", c and "à 0" or "NON modifiés"))
                    end
                end
            end
        end
        if not fait then
            if os.clock() < d.fin then reste[#reste + 1] = d
            else evenement("effet visuel seulement : effet « " .. (d.nom or "?") .. " » introuvable, collision non coupée") end
        end
    end
    R.deco = reste
end

local function creer_effet(e, duree, raison, mult, copies, emplacement, dynamique, r)
    if e == nil then return false, "aucun effet" end
    local fichier, numero = source_effet(e)
    local dyn = dynamique and cfg.effet_dynamique and cfg.effet_suivre_rayon
    local t_eff = dyn and taille_effet(mult, 0) or taille_effet(mult)
    copies = copies or 1
    local pj = joueur()
    if pj == nil then return false, "Insurgé introuvable" end
    local etape = "début"
    local ok, err = pcall(function()
        etape = "ShellManager"
        gest_shell = gest_shell or sdk.get_managed_singleton("app.ShellManager")
        if gest_shell == nil then error("ShellManager introuvable") end
        etape = "chargement du fichier"
        local ud = charger_fichier(fichier)
        if ud == nil then error("fichier d'effet introuvable : " .. tostring(fichier)) end
        etape = "liste des effets"
        local l = liste_params(ud)
        local n = l and nb_params(l)
        if l == nil or (n ~= nil and n <= numero) then
            -- v0.23 : données périmées (vidées par le jeu au chargement de la partie) → recharger
            etape = "rechargement du fichier"
            donnees_shell[fichier] = nil
            ud = charger_fichier(fichier)
            if ud == nil then error("fichier d'effet introuvable : " .. tostring(fichier)) end
            l = liste_params(ud)
            if l == nil then error("liste ShellParams illisible même après rechargement (réessaie dans quelques secondes)") end
            n = nb_params(l)
            evenement("fichier d'effets rechargé : " .. tostring(fichier))
        end
        if n ~= nil and n <= numero then
            error(R.fmt("le fichier ne contient que %d effets (pas encore chargé ? réessaie)", n))
        end
        etape = "effet n° " .. numero
        local param = param_n(l, numero)
        if param == nil then error("effet n° " .. numero .. " illisible (liste de " .. tostring(n) .. ")") end
        etape = "identifiant de l'effet"
        local hash = champ_objet(param, "_ShellParamIdHash")
        if hash == nil then error("_ShellParamIdHash illisible") end
        etape = "demande de création"
        local req = sdk.create_instance("app.ShellRequest.ShellCreateInfo")
        if req == nil then error("ShellCreateInfo impossible à créer") end
        pcall(function() req = req:add_ref() or req end)
        local okH = pcall(function() req:set_field("ShellParamIdHash", hash) end)
        if not okH then req.ShellParamIdHash = hash end
        -- taille et durée, le temps de la création
        etape = "taille et durée"
        local base = nil
        pcall(function() base = champ_objet(champ_objet(param, "_ShellParameterBase"), "ShellBaseParam") end)
        if base then
            local sauvegarde = {}
            pcall(function()
                sauvegarde = { UseScale = base.UseScale, Scale = base.Scale, UseLifeTime = base.UseLifeTime, LifeTime = base.LifeTime }
                local t = t_eff
                base.UseScale = true
                base.Scale = Vector3f.new(t, t, t)
                if duree and duree > 0 then base.UseLifeTime = true; base.LifeTime = duree end
            end)
            restaurations[#restaurations + 1] = { base, sauvegarde, os.clock() }
        else
            evenement("effet : taille non modifiable (ShellBaseParam illisible)")
        end
        etape = "position"
        local go = pj:call("get_GameObject")
        -- v0.57 : effet sur un pion → le pion est le « propriétaire » de l'effet
        if r and r.chr_cible and cfg.effet_pion_proprietaire then
            local g2 = appeler(r.chr_cible, "get_GameObject")
            if g2 then go = g2 end
        end
        local tr = go:call("get_Transform")
        local rot = tr:call("get_Rotation")
        -- emplacement : 1 = au sol, 2 = main droite, 3 = main gauche, 4 = les deux mains (v0.19)
        local positions = {}
        local function articulation(noms)
            for _, n in ipairs(noms) do
                local j = nil
                pcall(function() j = tr:call("getJointByName", n) end)
                if j then
                    local p = nil
                    pcall(function() p = j:call("get_Position") end)
                    if p then return p end
                end
            end
        end
        local droite = { "R_Hand_Palm", "R_PropA", "R_Arm_Lower" }
        local gauche = { "L_Hand_Palm", "L_PropA", "L_Arm_Lower" }
        if emplacement == 2 or emplacement == 4 then positions[#positions + 1] = articulation(droite) end
        if emplacement == 3 or emplacement == 4 then positions[#positions + 1] = articulation(gauche) end
        if #positions == 0 then
            if emplacement and emplacement > 1 then evenement("main introuvable : effet placé au sol") end
            local p = (r and r.pos_cible) or tr:call("get_Position")   -- v0.54 : effet sur un pion
            positions[1] = Vector3f.new(p.x, p.y + cfg.effet_hauteur + ((r and r.hauteur) or 0), p.z)
        end
        etape = "requestCreateShell"
        local ecart = (r and r.ecart or 0)
        local au_sol = not emplacement or emplacement == 1
        for _, pos in ipairs(positions) do
            for k = 1, copies do
                -- v0.26 : copies réparties en cercle autour de l'Insurgé (écart > 0)
                local dx, dz = 0, 0
                if au_sol and ecart > 0 and copies > 1 then
                    local ang = (k - 1) / copies * math.pi * 2
                    dx, dz = math.cos(ang) * ecart, math.sin(ang) * ecart
                end
                local pk = Vector3f.new(pos.x + dx, pos.y, pos.z + dz)
                R.creation_mod = true
                local id = gest_shell:call("requestCreateShell(via.GameObject, via.vec3, via.Quaternion, app.ShellRequest.ShellCreateInfo, app.ShellParamData, app.ShellRequest.EventCreateShellSuccess, app.ShellRequest.EventBeforeShellInstantiate)",
                    go, pk, rot, req, ud, nil, nil)
                R.creation_mod = false
                if id ~= nil and r and (r.duree_vie or 0) > 0 then   -- v0.53 : durée de vie imposée
                    R.a_tuer = R.a_tuer or {}
                    R.a_tuer[#R.a_tuer + 1] = { id = id, t = os.clock() + r.duree_vie, fondu = r.fondu_vie or 0.4 }
                end
                if (e.decoratif or e.perso) and id ~= nil and ((r and r.deco_mode) or 1) ~= 3 then   -- v0.38 : rendu inoffensif
                    R.deco = R.deco or {}
                    R.deco[#R.deco + 1] = { id = id, fin = os.clock() + 2.0, nom = e.nom, mode = (r and r.deco_mode) or 1 }
                    pcall(R.suivre_deco)
                end
                if dynamique and id ~= nil then        -- tous les effets de canalisation sont suivis
                    attentes[#attentes + 1] = { id = id, fin = os.clock() + 2.0, mult = mult, dyn = dyn, r = r,
                        dx = dx, dz = dz, au_sol = au_sol }
                end
            end
        end
    end)
    if not ok then
        evenement("effet « " .. (e.nom or "?") .. " » impossible à l'étape « " .. etape .. " » : " .. tostring(err))
        return false, tostring(err)
    end
    if e.compenser and cfg.compenser_endurance then
        api._compenser_jusqua = math.max(api._compenser_jusqua or 0, os.clock() + (duree and duree > 0 and duree or 6.0) + 1.0)
    end
    evenement(R.fmt("effet « %s » lancé (%s, taille %.2f, %d copie%s)", e.nom or "?", raison or "", t_eff, copies, copies > 1 and "s" or ""))
    return true
end
api.creer_effet = creer_effet

-- v0.53 : effets tués après leur durée de vie (court fondu puis suppression)
function R.suivre_tuer()
    if not R.a_tuer or #R.a_tuer == 0 then return end
    local gm = sdk.get_managed_singleton("app.ShellManager")
    local dict = champ_objet(gm, "<InstantiatedShellDict>k__BackingField")
    local now, reste = os.clock(), {}
    for _, k in ipairs(R.a_tuer) do
        if now < k.t then
            reste[#reste + 1] = k
        else
            if k.sh == nil and dict then
                local present = false
                pcall(function() present = dict:call("ContainsKey", k.id) end)
                if present then
                    local inst = nil
                    pcall(function() inst = dict:call("get_Item", k.id) end)
                    k.sh = inst and champ_objet(inst, "<Shell>k__BackingField")
                end
            end
            local q = k.fondu > 0 and (now - k.t) / k.fondu or 1
            if k.sh and q < 1 then
                pcall(colorer_shell, k.sh, 1 - q)
                reste[#reste + 1] = k
            elseif k.sh then
                pcall(function() local go = k.sh:call("get_GameObject"); go:call("destroy", go) end)
            end
        end
    end
    R.a_tuer = reste
end

-- lance tous les effets cochés pour un moment donné ("canal" ou "reussite")
-- v0.26 : cercle d'incantation des sorts de Mage / Sorcier — on demande au HAUT du
-- corps (couche 1) la préparation d'un sort ; le corps entier garde l'animation
-- de sauvetage. Expérimental : l'action peut aussi jouer un geste de bras.
local CERCLES = { "Job03_PrepareCureSpot", "Job03_PrepareHolyShine", "Job03_PrepareSpellBreak",
            "Job03_PrepareGuardBit", "Job06_PrepareSalamander", "Job06_PrepareBlizzard",
            "Job06_PrepareSaintDrain" }
local function lancer_cercle(pj, raison)
    if pj == nil then return false end
    local nom = "Job03_PrepareHolyShine"       -- v0.35 : modèle retenu par l'utilisateur
    local ok = action_directe(pj, 0, nom, 1)
    evenement("cercle d'incantation (" .. nom .. ", " .. (raison or "") .. ") : " .. (ok and "demandé" or "échec"))
    return ok
end

local function duree_effets_canal()
    local d = cfg.duree_incantation
    if cfg.lancer_au_relachement then
        return d + (cfg.maintien_max > 0 and cfg.maintien_max or 60.0)
    end
    return d
end

local function lancer_effets(moment, duree)
    local sort = (canal and canal.sort) or "resurrection"
    for _, e in ipairs(EFFETS) do
        local r = cfg.effets[e.cle]
        if r and r[moment] and (e.sort or "resurrection") == sort then
            local raison = moment == "canal" and "canalisation" or (moment == "final" and "lumière finale" or (moment == "coeur" and "battement de cœur" or "réussite"))
            local liste = { { e = e, taille = r.taille, r = r } }
            if e.choix == "final" then liste = R.sources_choisies(e, r, 1) end
            for _, it in ipairs(liste) do
            local ok, err = creer_effet(it.e, duree, raison, it.taille, r.copies, r.emplacement, moment == "canal", it.r)
            -- v0.51 : fichier d'effets pas encore chargé → nouvel essai pendant 3 s
            if not ok and moment ~= "canal" and err and (string.find(err, "charg", 1, true) or string.find(err, "illisible", 1, true) or string.find(err, "loaded", 1, true) or string.find(err, "unreadable", 1, true)) then
                R.reessais = R.reessais or {}
                R.reessais[#R.reessais + 1] = { e = it.e, duree = duree, raison = raison, r = it.r, taille = it.taille, fin = os.clock() + 3.0, prochain = os.clock() + 0.2 }
            end
            end
        end
    end
end
-- v0.53 : sources cochées de la lumière finale (chacune avec sa taille et sa hauteur)
function R.choix_final(cle)
    cfg.final_choix = type(cfg.final_choix) == "table" and cfg.final_choix or {}
    local c = cfg.final_choix[cle]
    if type(c) ~= "table" then
        c = { on = false, taille = 1.0, hauteur = 0.0 }
        cfg.final_choix[cle] = c
    end
    return c
end
function R.sources_choisies(e, r, cible)
    local res = {}
    for k, src in ipairs(R.SOURCES_FINAL) do
        local c = R.choix_final(src.cle)
        local moi, pion = R.cible_de(c)
        if c.on and (cible == nil or (cible == 1 and moi) or (cible == 2 and pion)) then
            local r2 = setmetatable({ hauteur = (r.hauteur or 0) + (c.hauteur or 0), duree_vie = c.duree_vie or 0 }, { __index = r })
            res[#res + 1] = { e = setmetatable({ src = src, nom = "Lumière finale : " .. src.nom }, { __index = e }),
                taille = r.taille * (c.taille or 1), r = r2 }
        end
    end
    return res
end
-- v0.54 : effets de la lumière finale joués sur le pion relevé (cible = pions)
function R.effets_sur_pion(chr, essai)
    local e = nil
    for _, x in ipairs(EFFETS) do if x.choix == "final" then e = x end end
    local r = e and cfg.effets[e.cle]
    if not r then return end
    -- v0.58 : la lumière peut être réglée « à la réussite » ou « à la fin » : les deux valent
    if not (r.final or r.reussite or essai) then
        evenement("effets sur les pions : ni « à la réussite » ni « à la fin » n'est cochée pour la lumière finale")
        return
    end
    local p = position(chr)
    if p == nil then
        evenement("effets sur les pions : position du pion illisible")
        return
    end
    local liste = R.sources_choisies(e, r, 2)
    if #liste == 0 then evenement("effets sur les pions : aucun effet coché avec la cible « les pions »") end
    for _, it in ipairs(liste) do
        rawset(it.r, "pos_cible", { x = p.x, y = p.y, z = p.z })
        rawset(it.r, "chr_cible", chr)
        local ok, err = creer_effet(it.e, 0, "sur le pion", it.taille, 1, 1, false, it.r)
        evenement(R.fmt("effet « %s » sur le pion (%.1f, %.1f, %.1f) : %s", it.e.nom or "?", p.x, p.y, p.z,
            ok and "lancé" or ("ÉCHEC " .. tostring(err))))
    end
end
-- essai : sur tous les pions du groupe
function R.essai_sur_pions()
    rafraichir_groupe()
    local n = 0
    for _, m in pairs(membres) do n = n + 1; R.effets_sur_pion(m.chr, true) end
    if n == 0 then evenement("essai sur les pions : aucun pion trouvé") end
end
function R.suivre_reessais()
    if not R.reessais or #R.reessais == 0 then return end
    local now, reste = os.clock(), {}
    for _, q in ipairs(R.reessais) do
        if now >= q.prochain then
            local ok, err = creer_effet(q.e, q.duree, q.raison .. " (nouvel essai)", q.taille or q.r.taille, q.r.copies, q.r.emplacement, false, q.r)
            if not ok and now < q.fin then q.prochain = now + 0.2; reste[#reste + 1] = q end
        else
            reste[#reste + 1] = q
        end
    end
    R.reessais = reste
end

local function suivre_restaurations()
    if #restaurations == 0 then return end
    local reste = {}
    for _, r in ipairs(restaurations) do
        if os.clock() - r[3] > 0.2 then
            pcall(function()
                for k, v in pairs(r[2]) do r[1][k] = v end
            end)
        else
            reste[#reste + 1] = r
        end
    end
    restaurations = reste
end

-- ----------------------------------------------------------------------------
-- Résurrection héroïque
-- ----------------------------------------------------------------------------

local NOMS_SORTS = { resurrection = "Breath of Life", temps = "Slow Time" }
local function cout_sort(sort) return sort == "temps" and cfg.temps_cout or cfg.cout end

local function peut_lancer(sort)
    sort = sort or "resurrection"
    if canal then return false, "déjà en cours" end
    if sort == "temps" then
        if not (cfg.actif and cfg.temps_actif) then return false, "Slow Time désactivé" end
        if R.temps then return false, "Slow Time déjà actif" end
        if R.vit_actif() or fin_ralenti or ralenti_a or R.post or R.coeur_fin then return false, "un autre ralenti est en cours" end
        if energie < cfg.temps_cout then return false, R.fmt("énergie insuffisante (%d/%d)", energie, cfg.temps_cout) end
        if not en_combat and not cfg.utilisable_hors_combat then return false, "hors combat" end
        local pj = joueur()
        if pj == nil or appeler(pj, "get_IsDead") == true then return false, "Insurgé indisponible" end
        return true
    end
    if R.temps then return false, "Slow Time en cours" end
    if not (cfg.actif and cfg.capacite_active) then return false, "capacité désactivée" end
    if energie < cfg.cout then return false, R.fmt("énergie insuffisante (%d/%d)", energie, cfg.cout) end
    if not en_combat and not cfg.utilisable_hors_combat then return false, "hors combat" end
    local pj = joueur()
    if pj == nil or appeler(pj, "get_IsDead") == true then return false, "Insurgé indisponible" end
    if appeler(pj, "get_IsRescuePawn") == true then return false, "réanimation native en cours" end
    rafraichir_groupe()
    local morts, total = pions_morts()
    if total == 0 then return false, "aucun pion dans le groupe" end
    if cfg.condition_lancement == 2 and #morts == 0 then return false, "aucun pion à terre" end
    if cfg.condition_lancement == 3 and #morts < total then
        return false, R.fmt("tous les pions ne sont pas à terre (%d/%d)", #morts, total)
    end
    return true
end

function R.anim_sort()
    if canal and canal.sort == "temps" then return cfg.jouer_animation and cfg.temps_animation end
    if canal and cfg.levitation then return false end   -- v0.36
    return cfg.jouer_animation
end
-- v0.36 : lévitation (actions natives JobMagicUser_StartLevitate / KeepLevitate / EndLevitate)
function R.lever(pj)
    if canal == nil or canal.sort ~= "resurrection" or not cfg.levitation then return end
    if cfg.saut_avant_elevation then                 -- v0.44 : saut, puis élévation
        local okS = action_directe(pj, 0, "VerticalJump", 0)
        canal.levit = { t = maintenant(), der = maintenant(), relances = 0, note = false,
            attente = maintenant() + cfg.saut_delai }
        R.fin_speciale = { levit = true }
        evenement("saut avant l'élévation : " .. (okS and "demandé" or "ÉCHEC"))
        return
    end
    local ok = action_directe(pj, 0, "JobMagicUser_StartLevitate", 0)
    canal.levit = { t = maintenant(), der = maintenant(), relances = 0, note = false }
    R.fin_speciale = { levit = true }
    evenement("lévitation : " .. (ok and "demandée" or "ÉCHEC de la demande"))
end
function R.suivre_levitation(pj, t)
    local lv = canal and canal.levit
    if lv == nil then return end
    if cfg.levitation_endurance then
        api._compenser_jusqua = math.max(api._compenser_jusqua or 0, os.clock() + 0.5)
    end
    if lv.attente then
        if t < lv.attente then return end
        lv.attente = nil
        lv.t, lv.der = t, t
        local ok = action_directe(pj, 0, "JobMagicUser_StartLevitate", 0)
        evenement("élévation : " .. (ok and "demandée" or "ÉCHEC"))
        if canal.cercle_differe then pcall(R.demarrer_cercle, pj) end
        return
    end
    local n0 = noeud_fsm(pj)
    -- v0.29 : sans cercle du jeu, la lévitation reste en StartLevitate (pas de pilotage au joystick) : on demande KeepLevitate
    if not lv.keep and string.find(n0, "StartLevitate", 1, true) and t - lv.t > 0.45 then
        lv.keep = t
        local okK = action_directe(pj, 0, "JobMagicUser_KeepLevitate", 0)
        evenement(R.fmt("lévitation : encore en StartLevitate après %.2f s, KeepLevitate demandé (%s)", t - lv.t, okK and "demande acceptée" or "ÉCHEC"))
    end
    if lv.keep and not lv.keep_note and t - lv.keep > 0.5 then
        lv.keep_note = true
        evenement("lévitation : état 0,5 s après la demande de KeepLevitate = " .. n0)
    end
    if not lv.note and t - lv.t > 0.5 then
        lv.note = true
        evenement("lévitation : état après 0,5 s = " .. n0)
    end
    if not string.find(n0, "Levitate", 1, true) and t - lv.der > 0.4 and lv.relances < 6 then
        lv.der = t
        lv.relances = lv.relances + 1
        local nom = lv.relances % 2 == 1 and "JobMagicUser_KeepLevitate" or "JobMagicUser_StartLevitate"
        local ok = action_directe(pj, 0, nom, 0)
        if lv.relances <= 2 then
            evenement(R.fmt("lévitation interrompue par le jeu (%s) : %s %s", n0, nom, ok and "redemandée" or "ÉCHEC"))
        end
    end
end
function R.duree_sort()
    if canal and canal.sort == "temps" then return cfg.temps_canal end
    -- v0.37 : calé sur le cercle de Mage (durée native mesurée)
    if cfg.cercle_mage and cfg.cercle_sync == 1 and cfg.cercle_duree_mesuree > 0.3 then return cfg.cercle_duree_mesuree end
    return cfg.duree_incantation
end
-- v0.66 : avancement de l'incantation affiché — il suit le cercle lui-même
function R.progression()
    if canal == nil then return 0 end
    if canal.sort == "resurrection" and cfg.cercle_mage then
        local d = cfg.cercle_duree_mesuree > 0.3 and cfg.cercle_duree_mesuree or 5.5
        if canal.cercle == nil then return 0 end
        if canal.cercle.pret then return 1 end
        return math.max(0, math.min(0.98, (maintenant() - canal.cercle.t) / d))
    end
    return math.max(0, math.min(1, (maintenant() - canal.debut) / math.max(0.1, R.duree_sort())))
end
-- v0.37 : état du cercle (couche 1) ; mesure de sa durée ; accélération éventuelle
function R.suivre_cercle(pj, t)
    local c = canal and canal.cercle
    if c == nil then return end
    local am = appeler(pj, "get_ActionManager")
    local fsm = am and champ_objet(am, "Fsm")
    local n1 = tostring(appeler(fsm, "getCurrentNodeName", 1) or "")
    -- v0.16 : diagnostic — chaque changement d'état du haut du corps, puis un point à 2 / 4 / 6 s
    if c.dernier_n1 ~= n1 then
        c.dernier_n1 = n1
        evenement(R.fmt("cercle : haut du corps → %s (%.2f s)", n1, t - c.t))
    end
    c.marq = c.marq or { 2.0, 4.0, 6.0 }
    if c.marq[1] and t - c.t >= c.marq[1] then
        local m = table.remove(c.marq, 1)
        evenement(R.fmt("cercle : à %.0f s, haut du corps = %s", m, n1))
    end
    -- v0.50 : si le haut du corps n'est pas (ou plus) dans la préparation du sort, le cercle
    -- reste figé et ne se referme jamais → on relance la préparation (3 fois au plus)
    if not c.pret and t - c.t > 0.4 and not string.find(n1, "HolyShine", 1, true) then
        c.relances = (c.relances or 0) + 1
        if c.relances <= 3 then
            evenement(R.fmt("cercle : le haut du corps est en « %s » au lieu de la préparation → relance %d", n1, c.relances))
            lancer_cercle(pj, "relance")
            c.t = t
        end
    end
    -- v0.18 : le jeu n'a pas fait passer la préparation à « prêt » à l'heure : une seule demande de l'état « prêt »
    if not c.pret and not c.pret_force and string.find(n1, "HolyShine", 1, true) and not string.find(n1, "Ready", 1, true)
        and cfg.cercle_duree_mesuree > 0.3 and t - c.t >= cfg.cercle_duree_mesuree + 0.4 then
        c.pret_force = true
        local ok = action_directe(pj, 0, "Job03_ReadyHolyShine", 1)
        evenement(R.fmt("cercle bloqué sur la préparation après %.1f s : état « prêt » demandé (%s)", t - c.t, ok and "demande acceptée" or "échec"))
        if cfg.message_cercle_casse then
            R.message2 = { lignes = { "Le cercle du jeu reste ouvert avec cette arme (il ne se referme qu'avec un bâton de mage).", "Le sort fonctionne quand même." }, fin = os.clock() + 6.0 }
        end
    end
    if not c.pret and t - c.t > 0.3 and string.find(n1, "Ready", 1, true) then
        c.pret = true
        local d = t - c.t
        if d > 0.3 and not c.pret_force and math.abs(d - cfg.cercle_duree_mesuree) > 0.05 then
            cfg.cercle_duree_mesuree = d
            sauver()
        end
        evenement(R.fmt("cercle refermé après %.2f s d'incantation (%s)", d, n1))
    end
    if cfg.cercle_sync == 2 and cfg.cercle_duree_mesuree > 0.3 then
        local k = math.max(0.2, math.min(5.0, cfg.cercle_duree_mesuree / math.max(0.3, cfg.duree_incantation)))
        local couche = champ_objet(pj, "UpperBodyLayer")
        if couche and not c.pret then
            local ok = pcall(function() couche:call("set_Speed", k) end)
            c.vitesse = ok and couche or nil
            if not c.note_v then
                c.note_v = true
                evenement(R.fmt("cercle accéléré ×%.2f : %s", k, ok and "ok" or "IMPOSSIBLE"))
            end
        elseif c.vitesse and c.pret then
            pcall(function() c.vitesse:call("set_Speed", 1.0) end); c.vitesse = nil
        end
    end
end
function R.fin_cercle(c)
    if c and c.vitesse then pcall(function() c.vitesse:call("set_Speed", 1.0) end) end
end

function R.vocation(pj)
    local h = appeler(pj, "get_Human")
    local ctx = appeler(h, "get_JobContext")
    local job = appeler(ctx, "get_Job")
    if type(job) ~= "number" and ctx ~= nil then
        for _, nom in ipairs({ "CurrentJob", "<CurrentJob>k__BackingField", "_CurrentJob", "<Job>k__BackingField" }) do
            local ok, v = pcall(function() return ctx:get_field(nom) end)
            if ok and type(v) == "number" then job = v; break end
        end
    end
    return job
end
local function lancer(sort)
    sort = sort or "resurrection"
    local ok, raison = peut_lancer(sort)
    if not ok then evenement(NOMS_SORTS[sort] .. " impossible : " .. raison); return end
    R.vol = nil                                                -- v0.78 : nouveau sort : fin du maintien précédent
    evenement(R.fmt("lancement : sort précédent = %s", R.dernier_fin or "aucun"))   -- v0.16 : diagnostic
    do
        local ok, v = pcall(R.vocation, joueur())
        evenement(R.fmt("lancement : vocation = %s (3 = Mage, dont le cercle est repris ici)", ok and tostring(v) or "illisible"))
    end
    canal = { debut = maintenant(), paye = false, sort = sort, cree = maintenant() }
    pcall(function() canal.voc = R.vocation(joueur()) end)       -- v0.20 : pour l'anneau du mod
    pcall(function() canal.sol = position(joueur()) end)    -- v0.76 : pieds au sol, avant le saut
    R.dernier_sort = sort
    -- v0.42 : l'énergie n'est JAMAIS prise au lancement : seulement quand le sort part
    if cfg.rengainer and cfg.jouer_animation and sort ~= "temps" then
        -- rengainer d'abord ; la canalisation (et son minuteur) démarre ensuite
        local ok = action_directe(joueur(), 0, "FastSheatheWeapon", 1)
        evenement("rengainer : " .. (ok and "demandé" or "échec"))
        canal.debut = maintenant() + cfg.delai_rengainer
        canal.prep = true
        return
    end
    evenement(NOMS_SORTS[canal.sort or "resurrection"] .. " : canalisation…")
    lancer_effets("canal", duree_effets_canal())
    R.lever(joueur())
    if R.anim_sort() then
        local okA, info = demarrer_animation(joueur())
        evenement(okA and ("animation : " .. info) or ("animation impossible : " .. info))
        canal.verif_anim = cfg.methode_animation == 1 and okA
    end
    -- v0.19 : le cercle d'incantation démarre aussi quand on ne rengaine pas (même logique que la suite du rengainage)
    if cfg.cercle_mage and canal.sort == "resurrection" then
        if cfg.levitation and cfg.saut_avant_elevation then
            canal.cercle_differe = true
        else
            pcall(R.demarrer_cercle, joueur())
        end
    end
end
api.lancer_resurrection = lancer

local function terminer_animation()
    local pj = joueur()
    pcall(R.fin_cercle, R.cercle_courant)
    R.cercle_courant = nil
    -- v0.36 : fin de la lévitation / du cercle (sans animation de sauvetage)
    local sp = R.fin_speciale
    R.fin_speciale = nil
    if sp and pj and not mouvement_en_cours and string.sub(noeud_fsm(pj), 1, 7) ~= "Damage." then
        if sp.levit and cfg.levitation_fin == 1 then
            local ok = action_directe(pj, 0, "JobMagicUser_EndLevitate", 0)
            if not R.geste then action_directe(pj, 0, "UpperBodyDefault", 1) end   -- v0.76 : le geste du sort garde le haut du corps
            evenement("fin de la lévitation : descente " .. (ok and "demandée" or "ÉCHEC → remise à zéro"))
            if not ok then debloquer(pj, "fin de lévitation") end
            if ok and cfg.controle_atterrissage then R.atterro = { t0 = os.clock(), calme = 0, y = nil } end   -- v0.82
        else
            debloquer(pj, "fin de canalisation (lévitation / cercle)")
        end
        return
    end
    if pj == nil or not cfg.jouer_animation then return end
    local noeud = noeud_fsm(pj)
    if noeud == "RescuePawn" then
        local ok = forcer_noeud(pj, "RescuePawnEnd")
        if not ok then demander_action(pj, "NormalLocomotion") end
    elseif string.sub(noeud, 1, 7) == "Damage." then
        mouvement_en_cours, mouvement_precedent = false, nil   -- le coup a déjà pris la main
    elseif not string.find(noeud, "RescuePawn", 1, true) then
        local etait = mouvement_en_cours
        arreter_mouvement(pj)                                    -- fin du mouvement brut
        if etait and cfg.debloquer_apres then
            -- v0.29 : la remise à zéro (annulation d'action) peut supprimer les effets de
            -- l'Insurgé : on attend la fin de leur disparition
            local en_fin = false
            for _, s2 in ipairs(suivis) do if s2.inverse_debut then en_fin = true end end
            if en_fin and cfg.attendre_fin_effets then
                R.deblocage_differe = os.clock() + cfg.inverse_duree + 0.05
            else
                debloquer(pj, "fin de canalisation")
            end
        end
    end
end

local function bilan_animation()
    if canal and (canal.relances or 0) > 0 then
        evenement("animation relancée " .. canal.relances .. " fois pendant cette canalisation")
    end
end

local deblocage_apres_coup = nil    -- heure limite : remise à zéro quand le coup est fini (v0.13)
local function interrompre(raison)
    R.dernier_fin = R.fmt("interrompu (%s)", raison)
    R.natif = nil
    pcall(bilan_animation)
    evenement(NOMS_SORTS[(canal and canal.sort) or "resurrection"] .. " interrompue : " .. raison)
    if canal and canal.paye then                     -- sécurité : rembourser tout paiement anticipé
        ajuster(cout_sort(canal.sort), "remboursement (sort interrompu)")
        canal.paye = false
    end
    evenement("aucune énergie consommée (sort non exécuté)")
    local etait_prep = canal and canal.prep
    canal = nil
    ralenti_a = nil                                  -- v0.2 : un ralenti programmé ne doit pas partir après coup
    R.final_a = nil
    terminer_animation()
    if cfg.effet_couper_interruption then
        if cfg.fin_meme_a_l_interruption then pcall(lancer_fin_effets, "interruption") end
        pcall(supprimer_effets_suivis)
    end
    if cfg.debloquer_apres then
        if raison == "coup reçu" then
            deblocage_apres_coup = maintenant() + 6.0
        elseif etait_prep then
            debloquer(joueur(), "interrompu pendant le rengainage")
        end
    end
end

-- remise à zéro différée : dès que l'animation de dégâts est terminée
function R.suivre_deblocage_differe()
    if R.deblocage_differe and os.clock() >= R.deblocage_differe then
        R.deblocage_differe = nil
        if canal == nil then debloquer(joueur(), "fin de canalisation, après la disparition des effets") end
    end
end
local function suivre_deblocage_apres_coup()
    if deblocage_apres_coup == nil then return end
    local pj = joueur()
    if maintenant() > deblocage_apres_coup or pj == nil or appeler(pj, "get_IsDead") == true then
        deblocage_apres_coup = nil
        return
    end
    if string.sub(noeud_fsm(pj), 1, 7) ~= "Damage." then
        deblocage_apres_coup = nil
        debloquer(pj, "après le coup reçu")
    end
end

-- ----------------------------------------------------------------------------
-- v0.3 : OUTIL DE TEST — retirer des PV à un pion. Branchement INCERTAIN :
-- plusieurs méthodes sont essayées dans l'ordre jusqu'à ce que les PV lus baissent.
-- ----------------------------------------------------------------------------
local function lire_pv(chr)
    local hit = appeler(chr, "get_Hit")
    local pv, max = appeler(hit, "get_Hp"), appeler(hit, "get_ReducedMaxHp")
    if type(pv) ~= "number" then pv = nil end
    if type(max) ~= "number" then max = nil end
    return hit, pv, max
end
function R.pions_ordonnes()
    local l = {}
    for _, m in pairs(membres) do l[#l + 1] = m end
    table.sort(l, function(a, b) return a.nom < b.nom end)
    return l
end
-- chaque méthode : f(hit, chr, pv_cible, pv_actuel) → ok (appel accepté) ; la réussite réelle est
-- jugée ensuite sur la relecture des PV
R.PV_METHODES = {
    { nom = "HitController.set_Hp(cible)", risque = false,
      f = function(hit, chr, cible) return (pcall(hit.call, hit, "set_Hp", cible)) end },
    { nom = "HitController.setHp(cible)", risque = false,
      f = function(hit, chr, cible) return (pcall(hit.call, hit, "setHp", cible)) end },
    { nom = "HitController.recoverHp(-perte)", risque = false,
      f = function(hit, chr, cible, actuel)
          return (pcall(hit.call, hit, "recoverHp(System.Single, System.Boolean, System.Int32, System.Boolean)", cible - actuel, true, 0, true)) end },
    { nom = "coup factice : damageProc(DamageInfo{Damage = perte})", risque = true,
      f = function(hit, chr, cible, actuel)
          local info = sdk.create_instance("app.HitController.DamageInfo")
          if info == nil then return false end
          pcall(function() info = info:add_ref() end)
          local okD = pcall(info.set_field, info, "Damage", actuel - cible)
          if not okD then return false end
          pcall(info.set_field, info, "AttackHitController", hit)   -- attaquant = lui-même, pour éviter un vide
          return (pcall(hit.call, hit, "damageProc", info)) end },
}
R.pv_verifs = {}      -- relectures différées (0,5 s) pour le journal
function R.retirer_pv(idx, pct)
    local l = R.pions_ordonnes()
    local m = l[idx]
    if m == nil then evenement(R.fmt("retirer PV : pas de pion n°%d (%d dans le groupe)", idx, #l)); return false end
    local hit, pv, max = lire_pv(m.chr)
    if hit == nil or pv == nil then evenement(m.nom .. " : PV illisibles (pas de HitController ou get_Hp)"); return false end
    if appeler(m.chr, "get_IsDead") == true then evenement(m.nom .. " : déjà à terre"); return false end
    local perte = (max or pv) * math.max(0, math.min(100, pct)) / 100
    local cible = math.max(0, pv - perte)
    if pct >= 100 then cible = 0 end
    evenement(R.fmt("retirer PV : %s, %.0f → %.0f (max %.0f, %d %%)", m.nom, pv, cible, max or -1, pct))
    local ordre = {}
    if cfg.test_pv_methode >= 1 and cfg.test_pv_methode <= #R.PV_METHODES then ordre = { cfg.test_pv_methode }
    else for i = 1, #R.PV_METHODES do ordre[#ordre + 1] = i end end
    for _, i in ipairs(ordre) do
        local me = R.PV_METHODES[i]
        if me.risque and not cfg.test_pv_risque then
            evenement("  " .. i .. ". " .. me.nom .. " : ignorée (case « méthode risquée » décochée)")
        else
            local okA, accepte = pcall(me.f, hit, m.chr, cible, pv)
            local _, apres = lire_pv(m.chr)
            local baisse = apres ~= nil and apres < pv - 0.5
            evenement(R.fmt("  %d. %s : appel %s, PV relus %s", i, me.nom,
                (okA and accepte) and "accepté" or "REFUSÉ", apres and R.fmt("%.0f", apres) or "?"))
            if baisse then
                R.pv_verifs[#R.pv_verifs + 1] = { chr = m.chr, nom = m.nom, heure = os.clock() + 0.5, methode = me.nom }
                R.pv_methode_ok = me.nom
                return true
            end
        end
    end
    evenement("  → AUCUNE méthode n'a fait baisser les PV")
    return false
end
function R.suivre_pv_verifs()
    if #R.pv_verifs == 0 then return end
    local now, reste = os.clock(), {}
    for _, v in ipairs(R.pv_verifs) do
        if now >= v.heure then
            local _, pv = lire_pv(v.chr)
            local mort = appeler(v.chr, "get_IsDead") == true
            evenement(R.fmt("  %s 0,5 s après (%s) : PV %s, %s, nœud %s", v.nom, v.methode,
                pv and R.fmt("%.0f", pv) or "?", mort and "À TERRE" or "debout", noeud_fsm(v.chr)))
        else reste[#reste + 1] = v end
    end
    R.pv_verifs = reste
end
api.retirer_pv = function(i, pct) return R.retirer_pv(i, pct or cfg.test_pv_pct) end
api.lancer_temps = function() lancer("temps") end

-- v0.41 : Slow Time -------------------------------------------------------
function R.reussir_temps()
    if not canal.paye then ajuster(-cfg.temps_cout, "Slow Time lancé") end
    lancer_effets("reussite", 0)
    canal = nil
    if cfg.temps_animation then terminer_animation() end
    R.temps_demarrer()
end
function R.temps_demarrer()
    R.temps = { debut = os.clock(), fin = os.clock() + cfg.temps_duree, v = cfg.temps_vitesse }
    R.vit_poser("temps", cfg.temps_vitesse, cfg.temps_compenser)
    evenement(R.fmt("Slow Time : le monde passe à x%.2f pendant %.1f s (Insurgé %s)", cfg.temps_vitesse, cfg.temps_duree,
        cfg.temps_compenser and "compensé" or "ralenti aussi"))
end
function R.temps_arreter(raison)
    if R.temps == nil then return end
    R.temps = nil
    R.vit_retirer("temps")
    evenement(R.fmt("Slow Time terminé (%s)", raison))
end
function R.suivre_temps()
    if R.temps == nil then return end
    local pj = joueur()
    if pj == nil then R.temps_arreter("Insurgé introuvable"); return end
    if appeler(pj, "get_IsDead") == true then R.temps_arreter("Insurgé à terre"); return end
    if not cfg.actif then R.temps_arreter("mod coupé"); return end
    if os.clock() >= R.temps.fin then R.temps_arreter("durée écoulée"); return end
    R.vit_appliquer(false)
end
-- vitesse de lecture des couches de mouvement de l'Insurgé (NickCore la remet à 1.0 à chaque action : on la réimpose à chaque image)
function R.vit_compenser(k)
    local pj = joueur()
    if pj == nil then return end
    local c = R.vit.couches
    if c == nil or c.pj ~= pj or os.clock() - c.t > 1.5 then
        c = { pj = pj, t = os.clock(), liste = {} }
        pcall(function()
            local mot = pj:call("get_Motion")
            local n = mot:call("getLayerCount")
            if type(n) ~= "number" or n < 1 or n > 8 then n = 3 end
            for i = 0, n - 1 do
                local okL, l = pcall(function() return mot:call("getLayer", i) end)
                if okL and l then c.liste[#c.liste + 1] = l end
            end
        end)
        R.vit.couches = c
    end
    for _, l in ipairs(c.liste) do pcall(function() l:call("set_Speed", k) end) end
    if not R.vit.note_comp then
        R.vit.note_comp = true
        evenement(R.fmt("compensation de l'Insurgé x%.2f sur %d couche(s)", k, #c.liste))
    end
    if k == 1.0 then R.vit.note_comp = nil; R.vit.couches = nil end
end

function R.demarrer_cercle(pj)
    -- v0.50 : attendre la fin du rengainage (couche 1) avant de préparer le sort
    local am = appeler(pj, "get_ActionManager")
    local fsm = am and champ_objet(am, "Fsm")
    local n1 = tostring(appeler(fsm, "getCurrentNodeName", 1) or "")
    if (string.find(n1, "Sheathe", 1, true) or string.find(n1, "Draw", 1, true))
        and maintenant() - (canal.cercle_attente_t or maintenant()) < cfg.cercle_attente_max then
        canal.cercle_attente_t = canal.cercle_attente_t or maintenant()
        canal.cercle_differe = true
        if canal.attente_n1 ~= n1 then                     -- v0.79 : ce qui fait attendre le cercle
            canal.attente_n1 = n1
            evenement("cercle en attente : haut du corps = " .. n1)
        end
        return
    end
    if canal.cercle_attente_t then
        evenement(R.fmt("cercle : attente de %.2f s (%s)", maintenant() - canal.cercle_attente_t,
            (string.find(n1, "Sheathe", 1, true) or string.find(n1, "Draw", 1, true)) and "maximum atteint" or ("haut du corps libre : " .. n1)))
    end
    canal.cercle_differe = nil
    lancer_cercle(pj, "canalisation")
    R.fin_speciale = R.fin_speciale or {}
    R.fin_speciale.cercle = true
    canal.cercle = { t = maintenant() }
    R.cercle_courant = canal.cercle
    R.natif = { fin = math.huge }                  -- v0.90 : repérage de l'effet natif
end

-- ----------------------------------------------------------------------------
-- v0.44 : battement de cœur pendant l'incantation
-- ----------------------------------------------------------------------------
function R.battement(n)
    if R.C then R.C.pulse_t = os.clock() end
    lancer_effets("coeur", 0)
    if cfg.coeur_vitesse < 0.99 then
        vitesse_globale(cfg.coeur_vitesse)
        R.coeur_fin = os.clock() + 0.45
    end
    evenement("battement de cœur " .. n)
end
function R.suivre_coeur(t)
    if not (canal and cfg.coeur_actif and canal.sort == "resurrection") or canal.prep then return end
    local p = (t - canal.debut) / math.max(0.1, R.duree_sort())
    canal.coeurs = canal.coeurs or {}
    if not canal.coeurs[1] and p >= cfg.coeur_1 then canal.coeurs[1] = true; R.battement(1) end
    if not canal.coeurs[2] and cfg.coeur_2 > cfg.coeur_1 and p >= cfg.coeur_2 then canal.coeurs[2] = true; R.battement(2) end
end


-- v0.76 : GESTE DU SORT — au relâchement, on demande au haut du corps le vrai lancer
-- d'Éclat sacré (nom de l'action cherché parmi des candidats, chaque essai journalisé),
-- puis la lumière part quand le geste se termine (ou après geste_delai).
R.GESTES = { "Job03_HolyShine", "Job03_ShotHolyShine", "Job03_ShootHolyShine", "Job03_FireHolyShine",
             "Job03_ReleaseHolyShine", "Job03_CastHolyShine", "Job03_HolyShineShot", "Job03_HolyShineFire",
             "Job03_HolyShineRelease", "Job03_HolyShineAttack", "Job03_HolyShineStart", "Job03_ActivateHolyShine" }
function R.couches(pj)
    local am = appeler(pj, "get_ActionManager")
    local fsm = nil
    pcall(function() fsm = am:get_field("Fsm") end)
    return tostring(appeler(fsm, "getCurrentNodeName", 0) or ""), tostring(appeler(fsm, "getCurrentNodeName", 1) or "")
end
function R.geste_lancer()
    R.geste = { t0 = os.clock(), i = 0, t = 0, frappe = false, journal = 0, n0 = nil, n1 = nil }
    if cfg.geste_nom ~= "" then R.geste.i = -1 end      -- nom déjà trouvé : essayé d'abord
end
function R.suivre_geste()
    local g = R.geste
    if g == nil then return end
    local now = os.clock()
    local pj = joueur()
    local n0, n1 = R.couches(pj)
    if (n0 ~= g.n0 or n1 ~= g.n1) and g.journal < 14 then
        g.journal = g.journal + 1
        evenement(R.fmt("geste : couche 0 = %s | couche 1 = %s", n0, n1))
    end
    g.n0, g.n1 = n0, n1
    local est_geste = n1:find("HolyShine", 1, true) and not n1:find("Prepare", 1, true) and not n1:find("Ready", 1, true)
    if g.trouve then
        local fini = not est_geste
        if (cfg.geste_delai > 0 and now - g.debut >= cfg.geste_delai) or fini or now - g.debut > 3.0 then
            if not g.frappe then g.frappe = true; evenement(R.fmt("geste du sort : frappe après %.2f s", now - g.debut)) end
            if fini or now - g.debut > 3.0 then
                action_directe(pj, 0, "UpperBodyDefault", 1)
                R.geste = nil
            end
        end
        return
    end
    if est_geste then
        g.trouve, g.debut = n1, now
        local nom = g.dernier or "?"
        if cfg.geste_nom ~= nom then cfg.geste_nom = nom; sauver() end
        evenement("geste du sort TROUVÉ : " .. nom .. " → " .. n1)
        return
    end
    if now < g.t then return end
    g.i = g.i + 1
    local nom = (g.i == 0 or g.i == -1) and cfg.geste_nom or R.GESTES[g.i]
    if g.i == 0 then g.i = 0 end
    if nom == nil then
        evenement("geste du sort introuvable : lumière tout de suite (envoie-moi le journal)")
        g.frappe = true
        action_directe(pj, 0, "UpperBodyDefault", 1)
        R.geste = nil
        return
    end
    g.dernier = nom
    local ok, r = pcall(function() return m_action:call(appeler(pj, "get_ActionManager"), 0, nom, 1) end)
    if g.journal < 14 then
        g.journal = g.journal + 1
        evenement(R.fmt("geste : essai %s → %s", nom, ok and tostring(r) or "erreur"))
    end
    g.t = now + 0.12
end
-- v0.90 : EFFET NATIF DE FIN D'INCANTATION — les effets (shells) que le jeu crée pour
-- l'Insurgé entre le cercle prêt et 2,5 s après le relâchement sont notés au journal ;
-- si « garder la lumière sacrée du jeu » est décoché, ils sont bloqués (essai).
R.natif = nil          -- { debut, fin }
pcall(function()
    local sm = sdk.find_type_definition("app.ShellManager")
    for _, m in ipairs(sm:get_methods()) do
        if m:get_name() == "requestCreateShell" then
            local premier = ""
            pcall(function() premier = m:get_param_types()[1]:get_full_name() end)
            if premier == "via.GameObject" then
                sdk.hook(m, function(args)
                    local n = R.natif
                    if n == nil or R.creation_mod or os.clock() > n.fin then return end
                    local ok, go = pcall(sdk.to_managed_object, args[3])
                    local gp = appeler(joueur(), "get_GameObject")
                    if not (ok and go and gp and adresse(go) == adresse(gp)) then return end
                    local nom = "?"
                    pcall(function() nom = sdk.to_managed_object(args[7]):get_type_definition():get_full_name() end)
                    local bloque = n.pret and not cfg.natif_fin
                    n.vus = (n.vus or 0) + 1
                    if n.vus <= 6 then
                        evenement(R.fmt("effet natif du jeu %s (%s) : %s", n.pret and "après le cercle" or "pendant le cercle", nom, bloque and "BLOQUÉ" or "laissé"))
                    end
                    if bloque then return sdk.PreHookResult.SKIP_ORIGINAL end
                end, nil)
            end
        end
    end
end)
-- v0.90 : aides du nouveau menu
function R.cible_de(c)
    local ci = c.cible or 1
    return c.on and (ci == 1 or ci == 3) or false, c.on and (ci == 2 or ci == 3) or false
end
function R.cible_fixer(c, moi, pion)
    c.on = moi or pion
    c.cible = (moi and pion) and 3 or (pion and 2 or 1)
end
function R.effet_final()
    for _, x in ipairs(EFFETS) do if x.choix == "final" then return x end end
end
function R.essayer_source(e, r, k, qui)
    local sauve = {}
    for k2, src2 in ipairs(R.SOURCES_FINAL) do
        local c2 = R.choix_final(src2.cle)
        sauve[k2] = { on = c2.on, cible = c2.cible }
        if k2 ~= k then c2.on = false else c2.on = true; c2.cible = qui end
    end
    if qui == 2 then pcall(R.essai_sur_pions)
    else
        for _, it in ipairs(R.sources_choisies(e, r, 1)) do
            creer_effet(it.e, 0, "essai", it.taille, r.copies, r.emplacement, false, it.r)
        end
    end
    for k2, src2 in ipairs(R.SOURCES_FINAL) do
        local c2 = R.choix_final(src2.cle)
        c2.on, c2.cible = sauve[k2].on, sauve[k2].cible
    end
end
-- réglages imposés depuis le nettoyage (fonctions retirées du menu)
function R.imposer()
    cfg.sonde_touche = nil                -- v0.43 : plus de sonde
    if cfg.temps_vitesse < 0.05 then cfg.temps_vitesse = 0.05 elseif cfg.temps_vitesse > 0.95 then cfg.temps_vitesse = 0.95 end
    cfg.levitation = true                 -- l'ancienne animation de sauvetage est supprimée
    cfg.levitation_fin = 1                -- descente naturelle + contrôle rendu au sol
    cfg.cercle_sync = 1
    cfg.cercle_mage = true                -- v0.30
    local fe = type(cfg.effets) == "table" and cfg.effets.final
    if type(fe) == "table" then fe.canal, fe.reussite, fe.final = false, false, true end
    if type(cfg.effets) == "table" and type(cfg.effets.sceau) == "table" then
        cfg.effets.sceau.canal, cfg.effets.sceau.reussite, cfg.effets.sceau.final = false, false, false
    end
end
-- v0.75 : presets (enveloppes avec journal)
function R.preset_info(nom) return PRESETS.info(nom) end
function R.preset_sauver(nom, libelle)
    local ok = PRESETS.sauver(nom, libelle)
    evenement(R.fmt("%s : réglages %s", libelle, ok and "sauvés" or "NON sauvés (erreur d'écriture)"))
end
function R.preset_charger(nom)
    local ok = PRESETS.charger(nom)
    if ok then pcall(completer_effets); pcall(R.imposer); sauver() end
    evenement(R.fmt("preset « %s » %s", nom, ok and "chargé" or "illisible"))
end
-- ----------------------------------------------------------------------------
-- v0.44 : après le lancement — retombée, lumière intense, pions relevés un par un
-- ----------------------------------------------------------------------------
function R.au_sol()
    local n0 = noeud_fsm(joueur())
    for _, mot in ipairs({ "Levitate", "Jump", "Fall", "Landing" }) do
        if string.find(n0, mot, 1, true) then return false end
    end
    return true
end
function R.suivre_post()
    if R.coeur_fin and os.clock() >= R.coeur_fin then
        R.coeur_fin = nil
        if not fin_ralenti and not R.vit.src.temps then vitesse_globale(1.0) end
    end
    local po = R.post
    if po == nil then return end
    local now = os.clock()
    local par_pion = math.max(cfg.focus_duree, cfg.focus_reveil + 0.3)
    local limite = 6.0 + cfg.chute_max + (cfg.ralenti_actif and (cfg.ralenti_duree + (cfg.ralenti_delai or 0)) or 0)
        + cfg.final_delai + cfg.focus_delai + #po.cibles * par_pion
        + (cfg.dernier_pion_special and par_pion * math.max(0, cfg.dernier_pion_duree_mult - 1) or 0)   -- v0.2
    if now - po.t0 > limite then
        evenement(R.fmt("séquence de relevé bloquée (phase %s) : pions restants relevés d'un coup", tostring(po.phase)))
        for _, c in ipairs(po.cibles) do
            if appeler(c.chr, "get_IsDead") == true then
                local okR, ok, info = pcall(reanimer, c.chr)
                evenement(R.fmt("%s %s (secours, %s)", tostring(c.nom), (okR and ok) and "relevé" or "ÉCHEC", tostring(info)))
            end
        end
        if R.C then R.C.focus_chr = nil end
        R.vit_retirer("dernier")                                     -- v0.2 : sécurité
        R.post = nil
        return
    end
    if po.phase == "chute" then
        local pret
        local fa = cfg.final_apres
        if fa == 1 then pret = now >= po.fin_ralenti
        elseif fa == 2 and R.vol then pret = false                             -- v0.78 : « au sol » attend la descente
        elseif fa == 3 then pret = true                                         -- v0.76 : au relâchement, en plein vol
        elseif fa == 4 then pret = now - po.t0 >= cfg.final_delai_relache       -- v0.76 : délai réglable
        elseif fa == 5 then pret = (R.geste and R.geste.frappe) or now - po.t0 > 4.0   -- v0.76 : geste du sort
        else pret = (now - po.t0 > 0.25 and R.au_sol()) or now - po.t0 > cfg.chute_max end
        if pret then
            local LIB = { "fin du ralenti", "retour au sol", "au relâchement", "après le délai", "geste du sort" }
            evenement((LIB[fa] or "?") .. " : lumière finale")
            lancer_effets("final", 0)
            po.phase, po.t = "lumiere", now + cfg.final_delai + cfg.focus_delai
        end
    elseif po.phase == "lumiere" then
        if now >= po.t then
            po.phase, po.i, po.t = "focus", 1, now
            evenement(R.fmt("relevé des pions : %d pion(s) à relever, un par un", #po.cibles))
        end
    elseif po.phase == "focus" then
        local c = po.cibles[po.i]
        if c == nil then
            if R.C then R.C.focus_chr = nil end
            R.vit_retirer("dernier")
            R.post = nil
            return
        end
        -- v0.2 : le DERNIER pion (s'il y en a plusieurs) a droit à un temps plus long et à un ralenti
        -- approfondi tant que la caméra est sur lui ; le ralenti est relâché pile à son réveil
        local dernier = cfg.dernier_pion_special and #po.cibles > 1 and po.i == #po.cibles
        local mult = dernier and math.max(1, cfg.dernier_pion_duree_mult) or 1
        local reveil = cfg.focus_reveil * mult
        if R.C then
            if R.C.focus_chr ~= c.chr then R.C.focus_depuis = now end           -- v0.2 : départ de l'orbite
            R.C.focus_chr = c.chr
        end
        if dernier and cfg.dernier_pion_ralenti and not po.dernier_ralenti and not R.vit.src.temps then
            po.dernier_ralenti = true
            R.vit_poser("dernier", cfg.dernier_pion_ralenti_vitesse, false)
            evenement(R.fmt("dernier pion : ralenti approfondi (x%.2f) jusqu'à son réveil", cfg.dernier_pion_ralenti_vitesse))
        end
        if not c.fait and now - po.t >= reveil then
            c.fait = true
            if po.dernier_ralenti then R.vit_retirer("dernier"); po.dernier_ralenti = false end
            if R.C and cfg.focus_punch then R.C.punch_t = now end               -- v0.2 : coup de zoom au réveil
            if appeler(c.chr, "get_IsDead") == true then
                pcall(R.effets_sur_pion, c.chr)
                local okR, ok, info = pcall(reanimer, c.chr)
                if not okR then ok, info = false, "erreur : " .. tostring(ok) end
                if ok and not po.ralenti_fait and cfg.ralenti_moment == 2 then   -- v0.77
                    po.ralenti_fait = true
                    lancer_ralenti(true)
                end
                evenement(R.fmt("%s %s (%.1f m, %s%s)", tostring(c.nom), ok and "relevé" or "ÉCHEC", c.d or 0, tostring(info), dernier and ", dernier pion" or ""))
            else
                evenement(c.nom .. " déjà relevé")
            end
        end
        -- v0.72 : on ne passe au pion suivant qu'une fois celui-ci relevé
        -- (avant : si « délai avant de relever » > « durée par pion », le pion était sauté)
        if c.fait and now - po.t >= math.max(cfg.focus_duree, cfg.focus_reveil + 0.3) * mult then po.i, po.t = po.i + 1, now end
    end
end

local function reussir()
    R.dernier_fin = "réussi"
    if R.natif then R.natif.pret, R.natif.fin = true, os.clock() + 2.5 end   -- v0.90
    bilan_animation()
    local n_inv = 0
    pcall(function() n_inv = effets_a_l_envers() end)
    if cfg.lancer_au_relachement then pcall(supprimer_effets_suivis, "sort lancé") end
    if canal and canal.sort == "temps" then return R.reussir_temps() end
    rafraichir_groupe()
    local pj = joueur()
    local centre = position(pj)
    local n = 0
    local cibles = {}
    -- v0.76 : portée en CYLINDRE (rayon à plat + hauteur vers le haut / le bas, depuis les pieds
    -- au sol au début du sort) ; sinon l'ancienne sphère autour de l'Insurgé
    local sol = (canal and canal.sol) or centre
    for _, m in ipairs((pions_morts())) do
        local pp = position(m.chr)
        local dedans, d, info
        if cfg.portee_cylindre and pp and centre and sol then
            local dx, dz = pp.x - centre.x, pp.z - centre.z
            d = math.sqrt(dx * dx + dz * dz)
            local dy = pp.y - sol.y
            dedans = d <= cfg.rayon and dy <= cfg.portee_haut and dy >= -cfg.portee_bas
            info = R.fmt("%.1f m à plat (max %.1f), %+.1f m en hauteur (max +%.0f / -%.0f)", d, cfg.rayon, dy, cfg.portee_haut, cfg.portee_bas)
        else
            d = distance(centre, pp)
            dedans = d <= cfg.rayon
            info = R.fmt("%.1f m > %.1f m", d, cfg.rayon)
        end
        if dedans then
            cibles[#cibles + 1] = { nom = m.nom, chr = m.chr, d = d }
        else
            evenement(R.fmt("%s hors de portée (%s)", m.nom, info))
        end
    end
    table.sort(cibles, function(a, b) return a.d < b.d end)
    if not cfg.focus_actif then
        for _, c in ipairs(cibles) do
            pcall(R.effets_sur_pion, c.chr)
            local ok, info = reanimer(c.chr)
            evenement(R.fmt("%s %s (%.1f m, %s)", c.nom, ok and "relevé" or "ÉCHEC", c.d, info))
            if ok then n = n + 1 end
        end
    else
        n = #cibles
    end
    if n > 0 then
        if not canal.paye then ajuster(-cfg.cout, "Breath of Life réussi") end
        -- v0.77 : ralenti au relevé du premier pion (par défaut) ou au lancement
        if cfg.ralenti_moment ~= 2 or not cfg.focus_actif then
            lancer_ralenti(cfg.ralenti_moment == 2)
        end
        lancer_effets("reussite", 0)
        -- v0.44 : retombée → lumière intense → pions relevés un par un (caméra sur chacun)
        local fin_r = os.clock() + ((cfg.ralenti_actif and cfg.ralenti_moment ~= 2) and (cfg.ralenti_duree + (cfg.ralenti_delai or 0)) or 0)
        R.post = { phase = "chute", t0 = os.clock(), fin_ralenti = fin_r,
            cibles = cfg.focus_actif and cibles or {}, i = 0 }
        if cfg.final_apres == 5 then R.geste_lancer() end
    else
        evenement("aucun pion dans la zone : énergie conservée")
        if canal.paye then ajuster(cfg.cout, "remboursement") end
    end
    canal = nil
    -- v0.78 : rester en lévitation après l'incantation (lumière, caméra sur les pions,
    -- ralenti) ; la descente n'est demandée qu'à la fin
    if n > 0 and cfg.vol_maintien and R.fin_speciale and R.fin_speciale.levit then
        R.vol = { t0 = os.clock(), der = 0, relances = 0 }
        evenement(cfg.vol_fin == 1 and R.fmt("maintien en l'air : %.1f s", cfg.vol_duree)
            or "maintien en l'air jusqu'au dernier pion relevé")
        return
    end
    terminer_animation()
end
-- v0.82 : CONTRÔLE RENDU À L'ATTERRISSAGE — dès que l'Insurgé touche le sol après la
-- lévitation (hauteur stable ou état d'atterrissage), on coupe l'animation de chute /
-- de réception (annulation native) : plus de chute mimée au sol ni de marche forcée.
function R.suivre_atterrissage()
    local a = R.atterro
    if a == nil then return end
    local now = os.clock()
    local pj = joueur()
    local n0 = noeud_fsm(pj)
    local p = position(pj)
    if p then
        if a.y and math.abs(p.y - a.y) < 0.02 then a.calme = a.calme + 1 else a.calme = 0 end
        a.y = p.y
    end
    if string.sub(n0, 1, 7) == "Damage." then R.atterro = nil; return end   -- un coup : le jeu garde la main
    local en_vol = string.find(n0, "Levitate", 1, true) ~= nil
    local recu = string.find(n0, "Landing", 1, true) ~= nil
    local pose = now - a.t0 > 0.15 and not en_vol and a.calme >= 4
    if recu or pose or now - a.t0 > 4.0 then
        R.atterro = nil
        action_directe(pj, 0, "DefaultCancelAction", 0)
        if not R.geste then action_directe(pj, 0, "UpperBodyDefault", 1) end
        evenement(R.fmt("atterrissage : contrôle rendu après %.2f s (%s)", now - a.t0, n0))
    end
end
function R.suivre_vol()
    local v = R.vol
    if v == nil then return end
    local now = os.clock()
    local pj = joueur()
    local n0 = noeud_fsm(pj)
    if cfg.levitation_endurance then
        api._compenser_jusqua = math.max(api._compenser_jusqua or 0, now + 0.5)
    end
    local fin, raison = false, nil
    if string.sub(n0, 1, 7) == "Damage." then fin, raison = true, "coup reçu"
    elseif now - v.t0 > 20 then fin, raison = true, "sécurité 20 s"
    elseif cfg.vol_fin == 1 then
        fin = now - v.t0 >= cfg.vol_duree
    else
        local po = R.post
        if po == nil or (po.phase == "chute" and cfg.final_apres == 2) then
            v.fini = v.fini or now
            fin = now - v.fini >= cfg.vol_apres
        end
    end
    if fin then
        R.vol = nil
        evenement(R.fmt("fin du maintien en l'air après %.1f s%s", now - v.t0, raison and (" (" .. raison .. ")") or ""))
        terminer_animation()
        return
    end
    if not string.find(n0, "Levitate", 1, true) and now - v.der > 0.4 and v.relances < 8 then
        v.der, v.relances = now, v.relances + 1
        local ok = action_directe(pj, 0, "JobMagicUser_KeepLevitate", 0)
        if v.relances <= 2 then evenement("maintien en l'air : lévitation " .. (ok and "redemandée" or "ÉCHEC") .. " (" .. n0 .. ")") end
    end
end

-- ----------------------------------------------------------------------------
-- Entrées : manette (masque de boutons) et clavier
-- ----------------------------------------------------------------------------
local pad_td = sdk.find_type_definition("via.hid.GamePad")
local function boutons()
    local ok, dev = pcall(function()
        return sdk.call_native_func(sdk.get_native_singleton("via.hid.GamePad"), pad_td, "get_LastInputDevice")
    end)
    if not ok or dev == nil then return 0 end
    local okB, b = pcall(function() return dev:call("get_Button") end)
    if okB and type(b) == "number" then return b end
    return 0
end
local function touche(vk)
    if vk == nil or vk <= 0 then return false end
    local ok, v = pcall(function() return reframework:is_key_down(vk) end)
    return ok and v == true
end

local vu_bit = {}           -- bit -> dernière heure où il était enfoncé
local debut_combo = nil
local combo_consomme = false
local capture = nil         -- {masque} pendant la capture de la combinaison
local capture_clavier = false

local function bits(masque)
    local l, b = {}, 1
    while b <= masque and b > 0 do
        if masque & b ~= 0 then l[#l + 1] = b end
        b = b << 1
    end
    return l
end

local function lire_entrees()
    local t = maintenant()
    local b = boutons()

    -- capture d'une nouvelle combinaison
    if capture then
        if b ~= 0 then capture.masque = capture.masque | b
        elseif capture.masque ~= 0 then
            local cle = capture.cle or "combo_manette"
        if cle == "annulation_bouton" then capture.masque = b ~= 0 and b or capture.masque end
            cfg[cle] = capture.masque
            sauver()
            evenement(R.fmt("nouvelle combinaison manette (%s) : 0x%X", cle, capture.masque))
            capture = nil
        end
        return false, false, false, false
    end
    if capture_clavier then
        for vk = 8, 254 do
            if vk ~= 0x2D and touche(vk) then      -- 0x2D = Inser (menu REFramework)
                local cle = type(capture_clavier) == "string" and capture_clavier or "touche_clavier"
                cfg[cle] = vk; sauver(); capture_clavier = false
                evenement(R.fmt("nouvelle touche clavier (%s) : %d", cle, vk))
                break
            end
        end
        return false, false, false, false
    end

    for _, bit in ipairs(bits(b)) do vu_bit[bit] = t end
    -- tous les boutons de la combinaison sont tenus (ou l'ont été très récemment) ;
    -- le dernier bouton (B) doit rester enfoncé. « recent » = dernier appui sur un
    -- bouton propre à cette combinaison (départage croix gauche / croix droite).
    local function etat(masque, autre)
        if masque == 0 then return false, false, -1 end
        local complet, tenu, recent = true, false, -1
        -- v0.45 : le maintien ne dépend que des boutons hors croix directionnelle (B)
        local hors_croix = masque & ~0xF
        for _, bit in ipairs(bits(masque)) do
            local v = vu_bit[bit]
            if b & bit ~= 0 and (hors_croix == 0 or bit & hors_croix ~= 0) then tenu = true
            elseif not (v and t - v <= cfg.tolerance_enchainement) then complet = false end
            if autre & bit == 0 and v and v > recent then recent = v end
        end
        return complet and (b & masque) ~= 0, tenu, recent
    end
    local m2 = (cfg.actif and cfg.temps_actif) and cfg.temps_combo or 0
    local a1, t1, r1 = etat(cfg.combo_manette, m2)
    local a2, t2, r2 = etat(m2, cfg.combo_manette)
    if a1 and a2 then
        if r2 > r1 then a1 = false else a2 = false end
    end
    local k1, k2 = touche(cfg.touche_clavier), touche(cfg.temps_touche_clavier)
    return a1 or k1, t1 or k1, a2 or k2, t2 or k2
end

R.sort_combo = nil
local function suivre_declencheur(appui, tenu, appui2, tenu2)
    local t = maintenant()
    -- v0.45 : annulation de l'incantation avec LT (comme les sorts de Mage / Sorcier)
    if canal and cfg.annulation_active and cfg.annulation_bouton ~= 0 and (boutons() & cfg.annulation_bouton) ~= 0 then
        interrompre("annulée (bouton d'annulation)")
        return
    end
    if canal and canal.sort == "temps" then tenu = tenu2 end
    if canal then
        -- canalisation en cours
        local pj = joueur()
        local noeud = noeud_fsm(pj)
        if cfg.interrompre_si_touche and string.sub(noeud, 1, 7) == "Damage." then
            interrompre("coup reçu"); return
        end
        if pj == nil or appeler(pj, "get_IsDead") == true then interrompre("Insurgé à terre"); return end
        if canal.prep then
            if cfg.interrompre_si_relache and not tenu then interrompre("touche relâchée"); return end
            if t < canal.debut then return end
            canal.prep = false
            evenement(NOMS_SORTS[canal.sort or "resurrection"] .. " : canalisation…")
            lancer_effets("canal", duree_effets_canal())
            R.lever(pj)
            if R.anim_sort() then
                local okA, info = demarrer_animation(pj)
                evenement(okA and ("animation : " .. info) or ("animation impossible : " .. info))
                canal.verif_anim = cfg.methode_animation == 1 and okA
            end
            if cfg.cercle_mage and canal.sort == "resurrection" then
                if cfg.levitation and cfg.saut_avant_elevation then
                    canal.cercle_differe = true          -- v0.49 : lancé à l'élévation (le saut le figeait)
                else
                    R.demarrer_cercle(pj)
                end
            end
            return
        end
        pcall(R.suivre_levitation, pj, t)
        if canal.cercle_differe and not (canal.levit and canal.levit.attente) then pcall(R.demarrer_cercle, pj) end
        pcall(R.suivre_cercle, pj, t)
        -- v0.22 : l'animation peut être écrasée par le jeu (déplacement, fin du
        -- rengainage…) ; si elle n'est plus jouée, on la relance à l'image où elle
        -- devrait en être.
        if cfg.jouer_animation and cfg.maintenir_animation and mouvement_en_cours and t > canal.debut then
            local b, i = mouvement_actuel(pj)
            if b ~= nil and not (b == cfg.anim_bank and (i == cfg.anim_id or i == cfg.anim_id - 1)) then
                canal.ecarts = (canal.ecarts or 0) + 1
                if canal.ecarts >= 3 and t - (canal.derniere_relance or -10) > 0.3 then
                    canal.derniere_relance = t
                    canal.ecarts = 0
                    local image = canal.pret and cfg.boucle_image
                        or math.min((t - canal.debut) * 60.0, math.max(0, (cfg.anim_fin or 260) - 1))
                    local ok = jouer_mouvement(pj, image, 6.0)
                    canal.relances = (canal.relances or 0) + 1
                    if canal.relances == 1 then
                        evenement(R.fmt("animation écrasée par le jeu (mouvement %s/%s) : relancée à l'image %.0f",
                            tostring(b), tostring(i), image) .. (ok and "" or " — ÉCHEC"))
                    end
                end
            else
                canal.ecarts = 0
            end
        end
        if canal.verif_anim and t - canal.debut > 0.3 then
            canal.verif_anim = false
            if mouvement_en_cours then
                -- le mouvement brut joue déjà : ne pas le relancer
            elseif noeud ~= "RescuePawn" then
                evenement("l'état forcé n'a pas tenu (" .. noeud .. ") → mouvement brut")
                local ok, info = jouer_mouvement(pj)
                if not ok then evenement("mouvement brut impossible : " .. info) end
            else
                evenement("état RescuePawn actif : animation en cours")
            end
        end
        -- v0.24 : sort chargé → il part au relâchement (comme les sorts de Mage / Sorcier)
        if canal.pret then
            if not tenu then reussir(); return end
            if cfg.maintien_max > 0 and t - canal.pret_depuis >= cfg.maintien_max then
                evenement("maintien maximal atteint : le sort part")
                reussir(); return
            end
            -- l'animation reboucle tant que le sort est maintenu
            if cfg.jouer_animation and mouvement_en_cours then
                local couche = couche_corps(pj)
                local img = appeler(couche, "get_Frame")
                if type(img) == "number" and img >= (cfg.anim_fin or 260) - 4 then
                    jouer_mouvement(pj, cfg.boucle_image, 10.0)
                end
            end
            return
        end
        if cfg.interrompre_si_relache and not tenu then interrompre("touche relâchée"); return end
        local charge = t - canal.debut >= R.duree_sort()
        if cfg.cercle_sync == 1 and canal.cercle then
            -- prêt quand le cercle est refermé (sécurité : durée mesurée + 2 s, ou durée réglée + 6 s)
            local secu = (cfg.cercle_duree_mesuree > 0.3 and cfg.cercle_duree_mesuree + 2.0) or (cfg.duree_incantation + 6.0)
            charge = canal.cercle.pret or (t - canal.cercle.t >= secu)
        elseif cfg.cercle_sync == 2 and cfg.cercle_mage and canal.sort == "resurrection" then
            -- v0.52 : cercle accéléré : prêt à sa fermeture, ou à la durée voulue comptée depuis son départ
            charge = canal.cercle ~= nil and (canal.cercle.pret or t - canal.cercle.t >= cfg.duree_incantation + 0.3)
        end
        if charge then
            if cfg.lancer_au_relachement and canal.sort == "resurrection" then
                canal.pret, canal.pret_depuis = true, t
                if cfg.cercle_sync == 1 and canal.cercle and not canal.cercle.pret then   -- v0.16 : diagnostic
                    evenement(R.fmt("ATTENTION : le jeu n'a jamais atteint « prêt » après %.1f s (haut du corps = %s) : sort déclaré chargé par la sécurité",
                        t - canal.cercle.t, tostring(canal.cercle.dernier_n1)))
                end
                if R.natif then R.natif.pret = true end
                evenement("sort chargé : relâche la combinaison pour le lancer")
            else
                reussir()
            end
        end
        return
    end
    local sort = appui and "resurrection" or (appui2 and "temps") or nil
    if sort then
        if debut_combo == nil or R.sort_combo ~= sort then debut_combo, R.sort_combo = t, sort end
        if not combo_consomme and t - debut_combo >= cfg.maintien then
            combo_consomme = true
            lancer(sort)
        end
    elseif not tenu and not tenu2 then
        debut_combo, combo_consomme, R.sort_combo = nil, false, nil
    end
end

-- ----------------------------------------------------------------------------
-- Jauge de flux : endurance (lecture reprise de KH HUD)
-- ----------------------------------------------------------------------------
local function lire_nombre(obj, methodes, champs)
    if obj == nil then return nil end
    for _, n in ipairs(methodes) do
        local ok, v = pcall(function() return obj:call(n) end)
        if ok and type(v) == "number" then return v end
    end
    for _, n in ipairs(champs) do
        local ok, v = pcall(function() return obj:get_field(n) end)
        if ok and type(v) == "number" then return v end
    end
end
local function lire_endurance(chr)
    if chr == nil then return nil end
    local function valeurs(m)
        if m == nil then return nil end
        local c = lire_nombre(m, { "get_RemainingAmount", "get_CurrentValue", "get_Stamina", "get_Value" },
            { "RemainingAmount", "CurrentValue", "<RemainingAmount>k__BackingField" })
        local x = lire_nombre(m, { "get_MaxValue", "get_MaxStamina", "get_StaminaMax" },
            { "MaxValue", "MaxStamina", "<MaxValue>k__BackingField" })
        if c and x and x > 0 then return c, x end
    end
    local m = appeler(chr, "get_StaminaManager")
    if m == nil then pcall(function() m = chr:get_field("<StaminaManager>k__BackingField") end) end
    local c, x = valeurs(m)
    if c then return c, x end
    local sc = appeler(chr, "get_StatusContext")
    local js = appeler(sc, "getJobStatusParam") or appeler(sc, "get_JobStatusParam")
    return valeurs(js)
end
api.lire_endurance = lire_endurance

-- compensation de l'endurance consommée par un effet « vrai sort » (Empyrée)
local endurance_figee = nil
local methode_compensation = nil
local function remettre_endurance(chr, cible)
    local m = appeler(chr, "get_StaminaManager")
    if m == nil then return false end
    local actuelle = lire_endurance(chr)
    if actuelle == nil or actuelle >= cible then return true end
    local delta = cible - actuelle
    local essais = {
        { "set_RemainingAmount", cible }, { "setRemainingAmount", cible }, { "setValue", cible },
        { "recover", delta }, { "recoverStamina", delta }, { "add", delta }, { "addValue", delta },
    }
    if methode_compensation then
        for _, e in ipairs(essais) do
            if e[1] == methode_compensation then
                return pcall(function() m:call(e[1], e[2]) end)
            end
        end
    end
    for _, e in ipairs(essais) do
        local ok = pcall(function() m:call(e[1], e[2]) end)
        local apres = lire_endurance(chr)
        if ok and apres and apres > actuelle then
            methode_compensation = e[1]
            evenement("compensation de l'endurance : méthode « " .. e[1] .. " »")
            return true
        end
    end
    local okF = pcall(function() m:set_field("<RemainingAmount>k__BackingField", cible) end)
    if okF then
        local apres = lire_endurance(chr)
        if apres and apres > actuelle then methode_compensation = "champ"; return true end
    end
    return false
end
local echec_signale = false
local function suivre_compensation()
    local fin = api._compenser_jusqua
    local pj = joueur()
    if fin == nil or pj == nil then return end
    if os.clock() > fin then
        api._compenser_jusqua, endurance_figee = nil, nil
        return
    end
    local c = lire_endurance(pj)
    if c == nil then return end
    if endurance_figee == nil then endurance_figee = c end
    if c < endurance_figee then
        local ok = remettre_endurance(pj, endurance_figee)
        if not ok and not echec_signale then
            echec_signale = true
            evenement("compensation de l'endurance impossible (aucune méthode ne fonctionne)")
        end
    end
end

local function mettre_a_jour()
    local t = maintenant()
    if t - dernier_rafraichissement > 1.0 then
        dernier_rafraichissement = t
        pcall(rafraichir_groupe)
    end
    pcall(enregistrer_mouvement)
    pcall(R.suivre_langue)
    if t - (R.am_adr_t or -1) > 0.5 then                  -- v0.2 : toutes les 0,5 s, plus à chaque image
        R.am_adr_t = t
        am_joueur_adr = adresse(appeler(joueur(), "get_ActionManager"))
    end
    pcall(suivre_deblocage_apres_coup)
    pcall(suivre_restaurations)
    pcall(suivre_compensation)
    pcall(suivre_effets)
    if t > 3 and t - (R.precharge_t or -1) > 1.0 then R.precharge_t = t; pcall(precharger) end
end

-- ----------------------------------------------------------------------------
-- Lien avec BardN Shards of Life : éclats, combat, seconde vie
-- ----------------------------------------------------------------------------
function R.sur_seconde_vie()
    if cfg.actif and cfg.seconde_vie_effet then pcall(lancer_effets, "final", 0) end
end
function R.sync_sol()
    local S = rawget(_G, "BardN_ShardsOfLife")
    if type(S) == "table" and S.api_niveau and S.get_unites and S.changer_unites then
        R.sol = S
        unites = S.get_unites(); energie = unites
        en_combat = S.est_en_combat() == true
        S.incantation = (canal ~= nil)
        if type(S.abonnes_seconde_vie) ~= "table" then S.abonnes_seconde_vie = {} end
        S.abonnes_seconde_vie.UltimateBreathOfLife = R.sur_seconde_vie
        return true
    end
    R.sol = nil
    unites, energie, en_combat = 0, 0, false
    return false
end
function R.dessiner_alerte()
    local ok, taille = pcall(imgui.get_display_size)
    local sw, sh = 1920, 1080
    if ok and taille then sw, sh = taille.x, taille.y end
    local txt = "BardN Ultimate Breath of Life : BardN Shards of Life est introuvable (requis)"
    R.dtext(txt, sw * 0.5 - (utf8.len(R.T(txt)) or #txt) * 3.6, sh * 0.12, 0xFF4040FF)
end

-- ----------------------------------------------------------------------------
-- Interface à l'écran : HUD Controls (Nexus DD2 n° 105) et barre d'incantation
-- La jauge d'éclats (et son id HUD Controls) appartient à BardN Shards of Life ; ce mod déclare ses propres
-- éléments : barre d'incantation, frange d'écran, cercles au sol.
-- ----------------------------------------------------------------------------
R.hc = { api = nil, statut = "HUD Controls non détecté", essai = -100, els = {} }
R.HC_ELEMENTS = {
    { "barre",   "bardn_breath_cast",    "BardN Ultimate Breath of Life — Barre d'incantation" },
    { "frange",  "bardn_breath_frange",  "BardN Ultimate Breath of Life — Frange d'écran" },
    { "cercles", "bardn_breath_cercles", "BardN Ultimate Breath of Life — Cercles au sol" },
}
function R.hc_brancher()
    if R.hc.api or not cfg.use_hud_controls then return end
    local now = os.clock()
    if now - R.hc.essai < 2.0 then return end
    R.hc.essai = now
    local hc = rawget(_G, "hud_controls")
    if type(hc) ~= "table" or type(hc.define_ui) ~= "function" or type(hc.calculate_alpha) ~= "function" then return end
    local n = 0
    for _, e in ipairs(R.HC_ELEMENTS) do
        local ok = pcall(function() R.hc.els[e[1]] = { def = hc.define_ui(e[2], { label = R.T(e[3]) }), alpha = 1.0, t = nil } end)
        if ok and R.hc.els[e[1]] then n = n + 1 end
    end
    if n > 0 then
        R.hc.api = hc
        R.hc.statut = "connecté à HUD Controls (" .. n .. " éléments « BardN Ultimate Breath of Life — … »)"
        evenement("HUD Controls : éléments déclarés")
    else
        R.hc.statut = "erreur HUD Controls : éléments non déclarés"
    end
end
-- facteur d'affichage d'un composant (opacité de groupe x règles de HUD Controls lissées).
-- « force » (aperçu / essai du menu) ignore HUD Controls pour qu'on voie le réglage.
R.hud = { apercu = true, vu = -10, boucle = false }
function R.hud_apercu_actif() return R.hud.apercu and os.clock() - R.hud.vu < 0.4 end
function R.hud_k(nom, force)
    local k = math.max(0, math.min(1, cfg.hud_opacite or 1))
    if force or R.hud_apercu_actif() then return k end
    local e = R.hc.els[nom]
    if not (e and e.def and R.hc.api and cfg.use_hud_controls) then return k end
    local now = os.clock()
    if e.t ~= now then
        local dt = e.t and math.min(0.1, now - e.t) or 0
        e.t = now
        local cible = 1.0
        if not canal then
            local ok, a = pcall(R.hc.api.calculate_alpha, e.def, nil)
            if ok and type(a) == "number" then cible = a > 0 and 1.0 or 0.0 end
        end
        local v = dt / 0.25
        if e.alpha < cible then e.alpha = math.min(cible, e.alpha + v) else e.alpha = math.max(cible, e.alpha - v) end
    end
    return k * e.alpha
end

local function melange_couleur(a, b, t)
    local function ch(c, d) return (c >> d) & 0xFF end
    local function mix(d) return math.floor(ch(a, d) + (ch(b, d) - ch(a, d)) * t + 0.5) end
    return (mix(24) << 24) | (mix(16) << 16) | (mix(8) << 8) | mix(0)
end
-- v0.13 : rectangle à dégradé vertical (c1 en haut, c2 en bas), en bandes contiguës
function R.degrade(x, y, w, h, c1, c2, alpha)
    if w <= 0 or h <= 0 then return end
    local a = alpha or 1
    local n = (c1 == c2) and 1 or math.max(1, math.min(16, math.floor(h)))
    if n == 1 then
        draw.filled_rect(x, y, w, h, (a >= 0.999) and c1 or ((math.floor(((c1 >> 24) & 0xFF) * a) << 24) | (c1 & 0xFFFFFF)))
        return
    end
    for i = 0, n - 1 do
        local y0 = y + math.floor(h * i / n + 0.5)
        local y1 = y + math.floor(h * (i + 1) / n + 0.5)
        if y1 > y0 then
            local c = melange_couleur(c1, c2, (i + 0.5) / n)
            if a < 0.999 then c = (math.floor(((c >> 24) & 0xFF) * a) << 24) | (c & 0xFFFFFF) end
            draw.filled_rect(x, y0, w, y1 - y0, c)
        end
    end
end
local function couleur_alpha(col, a)
    if a >= 0.999 then return col end
    local base = (col >> 24) & 0xFF
    return (math.floor(base * a) << 24) | (col & 0xFFFFFF)
end

-- barre d'incantation : sous la jauge de Shards of Life (position, échelle et transparence de transition venant de api.jauge)
function R.dessiner_barre()
    local S = R.sol
    local g = S and S.jauge
    if type(g) ~= "table" then return end
    local apercu = R.hud_apercu_actif()
    local ag = apercu and 1.0 or (g.alpha or 0)
    if ag <= 0.01 then return end
    local sw, sh = g.sw or 1920, g.sh or 1080
    if R.message2 and os.clock() < R.message2.fin then
        local a = math.min(1, (R.message2.fin - os.clock()) / 0.6)
        for i, l in ipairs(R.message2.lignes) do
            local largeur = (utf8.len(R.T(l)) or #l) * 7.2                 -- estimation : texte centré en bas de l'écran
            R.dtext(l, sw * 0.5 - largeur * 0.5, sh * 0.80 + (i - 1) * 20, couleur_alpha(0xFF40D0FF, a * math.max(0, math.min(1, cfg.hud_opacite or 1))))
        end
    end
    if not canal and not apercu then return end
    local alpha_barre = ag * R.hud_k("barre") * math.max(0, math.min(1, cfg.barre_opacite or 1))
    if alpha_barre <= 0.01 then return end
    local ech = g.ech or 1
    local epc = (cfg.barre_epaisseur or 4) * ech
    local x = g.x + (cfg.barre_decalage_x or 0)
    local yb = g.y + g.h + 3 + (cfg.barre_decalage_y or 0)
    local largeur = g.w
    local f1, f2 = cfg.barre_col_fond, cfg.barre_col_fond2 or cfg.barre_col_fond
    local n1, n2 = cfg.barre_col_progres, cfg.barre_col_progres2 or cfg.barre_col_progres
    local r1, r2 = cfg.barre_col_pret, cfg.barre_col_pret2 or cfg.barre_col_pret
    if canal and canal.pret then
        R.degrade(x, yb, largeur, epc, r1, r2, alpha_barre)
        if cfg.barre_texte_incantation then R.dtext("PRÊT — relâche pour lancer", x, yb + 2 + epc, couleur_alpha(0xFFFFFFFF, alpha_barre)) end
    elseif canal then
        local p = R.progression()
        R.degrade(x, yb, largeur, epc, f1, f2, alpha_barre)
        R.degrade(x, yb, largeur * p, epc, n1, n2, alpha_barre)
    elseif apercu then                                              -- aperçu de la barre à 60 %
        R.degrade(x, yb, largeur, epc, f1, f2, alpha_barre)
        R.degrade(x, yb, largeur * 0.6, epc, n1, n2, alpha_barre)
    end
end

local derniere_ecriture = 0
local function ecrire_journal()
    if not journal_sale or maintenant() - derniere_ecriture < 2.0 then return end
    journal_sale = false
    derniere_ecriture = maintenant()
    pcall(json.dump_file, DOSSIER .. "journal.json", { version = api.version, diag = diag, journal = evenements })
end

-- ----------------------------------------------------------------------------
-- v0.26 : FRANGE D'ÉCRAN — bandes emboîtées sur les bords (technique de Enemy Break Equipment),
-- plus larges et plus opaques à mesure que le sort se charge, flash intense quand il est prêt.
-- ----------------------------------------------------------------------------
R.frange = { dernier = nil, fin = nil, debut = nil, pret_t = nil, essai = nil }
function R.frange_dessiner(pct, opa, col)
    if opa <= 0.003 or pct <= 0 then return end
    local okT, taille = pcall(imgui.get_display_size)
    if not okT or taille == nil then return end
    local sw, sh = taille.x, taille.y
    if not sw or sw < 100 then return end
    local band = math.max(4, math.min(sw, sh) * pct / 100)
    local n = math.floor(math.max(24, math.min(140, band)))      -- couches de 1 à 2 px, sans recouvrement
    local ex = math.max(0.5, cfg.frange_douceur)
    local rgb = col & 0xFFFFFF
    local fw, fh = math.floor(sw), math.floor(sh)
    local prec = 0
    for i = 0, n - 1 do
        local suiv = math.floor(band * (i + 1) / n + 0.5)
        local e = suiv - prec
        if e > 0 then
            local k = (prec + e * 0.5) / band
            local a = opa * (1 - k) ^ ex
            if a > 0.003 then
                local c = (math.floor(math.min(1, a) * 255 + 0.5) << 24) | rgb
                local w, h = fw - 2 * prec, fh - 2 * prec
                if w > 2 * e and h > 2 * e then
                    draw.filled_rect(prec, prec, w, e, c)                          -- haut
                    draw.filled_rect(prec, prec + h - e, w, e, c)                  -- bas
                    draw.filled_rect(prec, prec + e, e, h - 2 * e, c)              -- gauche
                    draw.filled_rect(prec + w - e, prec + e, e, h - 2 * e, c)      -- droite
                end
            end
        end
        prec = suiv
    end
end
function R.dessiner_frange()
    local F = R.frange
    local t = os.clock()
    local etat = nil                                  -- { p, pret }
    if F.essai then
        local d = cfg.cercle_duree_mesuree > 0.3 and cfg.cercle_duree_mesuree or 5.5
        local e = t - F.essai
        if e < d then etat = { p = e / d, pret = false }
        elseif e < d + 2.0 then etat = { p = 1, pret = true }
        else F.essai = nil end
    elseif cfg.actif and cfg.frange_actif and canal ~= nil and canal.sort == "resurrection" then
        local p = R.progression()
        etat = { p = p, pret = (p >= 1) or canal.pret == true }
    end
    local k = 1
    if etat then
        F.fin = nil
        F.debut = F.debut or t
        F.dernier = etat
        if etat.pret then F.pret_t = F.pret_t or t else F.pret_t = nil end
    else
        if F.dernier == nil then F.debut = nil; return end
        F.fin = F.fin or t
        k = 1 - (t - F.fin) / math.max(0.05, cfg.frange_fondu)
        if k <= 0 then F.dernier, F.fin, F.debut, F.pret_t = nil, nil, nil, nil; return end
        k = k * k * (3 - 2 * k)
        etat = F.dernier
    end
    local entree = math.min(1, (t - (F.debut or t)) / 0.3)
    entree = entree * entree * (3 - 2 * entree)
    local pct, opa
    if etat.pret then
        local age = t - (F.pret_t or t)
        pct = cfg.frange_largeur_prete
        opa = cfg.frange_opa_prete * (1 - 0.2 * math.min(1, age / 0.4)) * (1 + 0.04 * math.sin(t * 8))   -- « bam » puis léger souffle
    else
        local p = math.max(0, math.min(1, etat.p))
        pct = cfg.frange_largeur_min + (cfg.frange_largeur_max - cfg.frange_largeur_min) * p
        opa = cfg.frange_opa_min + (cfg.frange_opa_max - cfg.frange_opa_min) * p
        opa = opa * entree
    end
    R.frange_dessiner(pct, opa * k * R.hud_k("frange", F.essai ~= nil), math.tointeger(cfg.frange_col) or defauts.frange_col)
end

-- ----------------------------------------------------------------------------
-- Cercle de zone (feedback de canalisation), rayon = rayon réel du sort
-- ----------------------------------------------------------------------------
local COUL_ZONE = { 0x40D0FF, 0xFFFFFF }      -- doré (BGR), blanc
local function vers_ecran(x, y, z)
    local ok, p = pcall(draw.world_to_screen, Vector3f.new(x, y, z))
    if ok and p then return p.x, p.y end
end
-- v0.2 : cos/sin pré-calculés par nombre de segments, couleur calculée une fois,
-- épaisseur de trait testée une seule fois (plus de pcall par segment)
local TRIGO = {}
local function trigo(seg)
    local t = TRIGO[seg]
    if t then return t end
    t = {}
    for i = 0, seg do
        local a = (i / seg) * math.pi * 2
        t[i] = { math.cos(a), math.sin(a) }
    end
    TRIGO[seg] = t
    return t
end
local ligne_epaisse = nil          -- nil = pas encore su, true/false ensuite
local function ligne(x1, y1, x2, y2, col, ep)
    if ligne_epaisse == nil then
        ligne_epaisse = pcall(draw.line, x1, y1, x2, y2, col, ep)
        if ligne_epaisse then return end
    end
    if ligne_epaisse then draw.line(x1, y1, x2, y2, col, ep) else draw.line(x1, y1, x2, y2, col) end
end
local function dessiner_cercle(c, r, couleur, alpha, segments)
    local px, py
    local col = (math.floor(alpha * (R.kz or 1) * 255) << 24) | couleur
    local tr = trigo(segments)
    local ep = cfg.zone_epaisseur
    for i = 0, segments do
        local cs = tr[i]
        local x, y = vers_ecran(c.x + cs[1] * r, c.y + 0.05, c.z + cs[2] * r)
        if x and px then ligne(px, py, x, y, col, ep) end
        px, py = x, y
    end
end
local function dessiner_zone()
    local apercu = R.hud_apercu_actif()
    local montrer = (canal and cfg.zone_pendant_canalisation) or cfg.zone_toujours or apercu
    if not montrer and cfg.zone_quand_prete then                -- v0.2 : relu 4 fois par seconde, pas à chaque image
        local t0 = os.clock()
        if t0 - (R.pret_t or -1) > 0.25 then R.pret_t = t0; R.pret_v = (peut_lancer()) == true end
        montrer = R.pret_v
    end
    if not montrer then return end
    R.kz = R.hud_k("cercles", apercu or cfg.zone_toujours)
    if R.kz <= 0.003 then return end
    local c = position(joueur())
    if c == nil then return end
    local t = os.clock()
    local pulse = 0.55 + 0.35 * math.sin(t * 6.0)
    if canal then
        local p = R.progression()
        dessiner_cercle(c, cfg.rayon, COUL_ZONE[1], pulse, 72)                 -- limite de la zone
        dessiner_cercle(c, cfg.rayon * p, COUL_ZONE[2], 0.8, 48)              -- onde qui grandit
        dessiner_cercle(c, cfg.rayon * 0.15, COUL_ZONE[1], 0.9, 24)           -- cœur
        if canal.pret then                                                      -- sort chargé
            local pp = 0.5 + 0.5 * math.sin(t * 10.0)
            dessiner_cercle(c, cfg.rayon * (0.97 + 0.03 * pp), COUL_ZONE[2], 0.6 + 0.4 * pp, 72)
        end
    else
        dessiner_cercle(c, cfg.rayon, COUL_ZONE[1], 0.45, 72)
    end
end


-- ----------------------------------------------------------------------------
-- v0.20 : anneau d'incantation dessiné par le mod (se resserre avec R.progression())
-- ----------------------------------------------------------------------------
-- v0.21 : fin automatique de l'essai du cercle (sinon le personnage restait bloqué en préparation)
function R.suivre_essai_cercle()
    if R.essai_cercle_fin == nil then return end
    if canal ~= nil then R.essai_cercle_fin = nil; return end          -- un vrai sort a pris le relais
    if os.clock() >= R.essai_cercle_fin then
        R.essai_cercle_fin = nil
        debloquer(joueur(), "fin de l'essai du cercle")
    end
end
function R.anneau_cercle(c, r, col, ep, seg, rot, tirets)
    local px, py
    local cr, sr = math.cos(rot), math.sin(rot)          -- v0.2 : rotation appliquée à la table pré-calculée
    local tr = trigo(seg)
    for i = 0, seg do
        local cs = tr[i]
        local ca, sa = cs[1] * cr - cs[2] * sr, cs[2] * cr + cs[1] * sr
        local x, y = vers_ecran(c.x + ca * r, c.y + 0.05, c.z + sa * r)
        if x and px and ((not tirets) or i % 2 == 1) then ligne(px, py, x, y, col, ep) end
        px, py = x, y
    end
end
function R.dessiner_anneau()
    local t = os.clock()
    local essai = R.anneau_essai
    local p, pret_age, debut
    if essai then
        local d = cfg.cercle_duree_mesuree > 0.3 and cfg.cercle_duree_mesuree or 5.5
        local e = t - essai
        if e > d + 0.8 then R.anneau_essai = nil; return end
        p, debut = math.min(0.98, e / d), essai
        if e >= d then pret_age = e - d end
    else
        if not cfg.actif or cfg.anneau_affichage == 2 then return end
        if canal == nil or canal.sort ~= "resurrection" then return end
        if cfg.cercle_mage then
            if canal.cercle == nil then return end
            if cfg.anneau_affichage == 3 and (canal.voc == 3 or canal.voc == 5) then return end
            p, debut = R.progression(), canal.cercle.t
            if canal.cercle.pret then
                canal.anneau_pret_t = canal.anneau_pret_t or t
                pret_age = t - canal.anneau_pret_t
            end
        else                                                      -- v0.25 : sans le cercle du jeu, l'anneau suit la durée réglée
            p, debut = R.progression(), canal.debut
            if canal.pret then
                canal.anneau_pret_t = canal.anneau_pret_t or t
                pret_age = t - canal.anneau_pret_t
            end
        end
        if not canal.anneau_log then
            canal.anneau_log = true
            evenement(R.fmt("anneau du mod : affiché (mode %d, vocation %s)", cfg.anneau_affichage, tostring(canal.voc)))
        end
    end
    if pret_age and pret_age > 0.6 then return end
    local c = position(joueur())
    if c == nil then return end
    local r0, r1 = cfg.anneau_rayon_debut, cfg.anneau_rayon_fin
    local r = r0 + (r1 - r0) * (pret_age and 1 or p)
    local a = math.min(1, math.max(0, (t - (debut or t)) / 0.35)) * (pret_age and math.max(0, 1 - pret_age / 0.6) or 1)
    a = a * R.hud_k("cercles", essai ~= nil)
    if a <= 0.003 then return end
    local col1 = math.tointeger(cfg.anneau_col) or defauts.anneau_col
    local col2 = math.tointeger(cfg.anneau_col2) or defauts.anneau_col2
    local ep = cfg.anneau_epaisseur
    local rot = t * 1.2
    R.anneau_cercle(c, r0, couleur_alpha(col2, a * 0.22), 1.5, 48, 0, true)          -- repère : rayon de départ
    R.anneau_cercle(c, r, couleur_alpha(col1, a), ep, 64, 0, false)                    -- anneau qui se resserre
    R.anneau_cercle(c, r * 0.78, couleur_alpha(col2, a * 0.9), ep * 0.6, 48, rot, true) -- anneau intérieur qui tourne
    for i = 0, 7 do                                                                     -- repères qui tournent à contre-sens
        local an = -rot * 0.7 + i * math.pi / 4
        local xa, ya = vers_ecran(c.x + math.cos(an) * r * 0.5, c.y + 0.05, c.z + math.sin(an) * r * 0.5)
        local xb, yb = vers_ecran(c.x + math.cos(an) * r * 0.68, c.y + 0.05, c.z + math.sin(an) * r * 0.68)
        if xa and xb then pcall(draw.line, xa, ya, xb, yb, couleur_alpha(col1, a * 0.8), ep * 0.7) end
    end
    if pret_age then                                                                    -- sort prêt : onde qui s'étend
        local k = pret_age / 0.6
        R.anneau_cercle(c, r1 * (1 + 2.2 * k), couleur_alpha(col2, a), ep * 1.4, 64, 0, false)
    end
end

-- ----------------------------------------------------------------------------
-- v0.29 : caméra — dézoom progressif tant que la résurrection est maintenue,
-- puis retour en douceur à la caméra du jeu. Appliqué juste avant le rendu,
-- après la mise à jour de la caméra par le jeu.
-- ----------------------------------------------------------------------------
local C = { niveau = 0.0, dernier = nil, tenu = nil, offset = nil, sauve = nil, signale = false }
R.C = C
function C.cible()
    if C.essai_fin then
        local r = C.essai_fin - os.clock()
        if r > 0 then local x = math.min(1, (3.0 - r) / 0.8, r / 0.8); x = math.max(0, x); return x * x * (3 - 2 * x) end
        C.essai_fin = nil
    end
    if not (cfg.actif and cfg.camera_actif) then return 0.0 end
    if canal == nil or canal.sort ~= "resurrection" then return 0.0 end
    local x = math.max(0, math.min(1, (maintenant() - (canal.cree or canal.debut) - cfg.camera_delai) / math.max(0.1, cfg.camera_duree_zoom)))
    return x * x * (3 - 2 * x)                       -- départ et arrivée en douceur
end
function C.avancer()
    local t = os.clock()
    local dt = C.dernier and math.min(0.1, t - C.dernier) or 0
    C.dernier = t
    local cible = C.cible()
    if cible >= C.niveau then C.niveau = cible
    else C.niveau = math.max(cible, C.niveau - dt / math.max(0.05, cfg.camera_retour)) end
end
-- v0.31 : méthode de Skill Maker / DragonCore — on agit sur les RÉGLAGES de la caméra
-- du joueur (distance), pas sur la caméra elle-même :
--   CameraManager._MainCameraControllers[0]._CurrentCameraController
--   → <CurrentLevelInfo>k__BackingField._Distance (lieu étroit)
--     ou _PlayerCameraSettings._CameraDistance (normal)
--   hauteur : _MainCameraControllers[0]["<BaseOffset>k__BackingField"]
function C.reglages()
    local mgr = sdk.get_managed_singleton("app.CameraManager")
    local main = mgr and mgr._MainCameraControllers[0]
    local ctrl = main and main._CurrentCameraController
    if ctrl == nil then return nil end
    local etroit = ctrl["<CurrentLevelInfo>k__BackingField"]
    if etroit then return etroit, "_Distance", main end
    return ctrl._PlayerCameraSettings, "_CameraDistance", main
end
function C.rendre()
    local h = C.tenu
    C.tenu = nil
    C.ecrit, C.diag_vrai = nil, false
    if h then pcall(function() h.obj[h.champ] = h.propre end) end
    local o = C.offset
    C.offset = nil
    if o then pcall(function() o.main["<BaseOffset>k__BackingField"] = o.propre end) end
end
function C.distance(sans_avancer)
    -- v0.61 : recul réel par le réglage natif « distance de caméra » des options,
    -- trouvé par la sonde : CameraManager._DistanceOffset (0 → 1 dans le menu,
    -- ≈ 1 m de recul par unité). On ajoute notre recul, puis on rend la valeur du joueur.
    if not sans_avancer then C.avancer() end
    local mgr = sdk.get_managed_singleton("app.CameraManager")
    if mgr == nil then return end
    local veut = C.niveau > 0.001 and cfg.camera_distance_on and cfg.camera_distance_ajout > 0
    if not veut then
        if C.dist_propre ~= nil then C.rendre_distance() end
        return
    end
    if C.dist_propre == nil then
        local v = mgr:get_field("_DistanceOffset")
        if type(v) ~= "number" then return end
        C.dist_propre = v
        if not C.dist_note then
            C.dist_note = true
            evenement(R.fmt("caméra : distance du joueur %.2f → jusqu'à %.2f pendant le sort", v, v + cfg.camera_distance_ajout))
        end
    end
    local cible = C.dist_propre + cfg.camera_distance_ajout * C.niveau
    local lu = mgr:get_field("_DistanceOffset")
    if C.dist_ecrit and type(lu) == "number" and math.abs(lu - C.dist_ecrit) > 0.001 and not C.dist_reecrit then
        C.dist_reecrit = true
        evenement(R.fmt("caméra : le jeu a ramené la distance à %.2f (on la réécrit)", lu))
    end
    mgr:set_field("_DistanceOffset", cible)
    C.dist_ecrit = cible
end
function C.rendre_distance()
    local v = C.dist_propre
    C.dist_propre, C.dist_ecrit, C.dist_reecrit = nil, nil, false
    if v == nil then return end
    pcall(function() sdk.get_managed_singleton("app.CameraManager"):set_field("_DistanceOffset", v) end)
end
-- champ de vision (expérimental) : appliqué le temps du rendu
function C.restituer()
    local sv = C.sauve
    C.sauve = nil
    if sv then pcall(function() sv.cam:call("set_FOV", sv.fov) end) end
end
function C.pulsation()
    -- v0.44 : « boum-boum » du battement de cœur
    if not C.pulse_t then return 0 end
    local x = os.clock() - C.pulse_t
    if x > 0.7 then C.pulse_t = nil; return 0 end
    return math.exp(-((x - 0.04) / 0.06) ^ 2) + 0.7 * math.exp(-((x - 0.30) / 0.07) ^ 2)
end
function C.punch()
    -- v0.2 : coup de zoom bref au réveil d'un pion (monte vite, redescend en douceur)
    if not C.punch_t or not cfg.focus_punch then return 0 end
    local d = math.max(0.1, cfg.focus_punch_duree)
    local x = (os.clock() - C.punch_t) / d
    if x >= 1 then C.punch_t = nil; return 0 end
    local m = 0.18
    local k = x < m and (x / m) or (1 - (x - m) / (1 - m))
    return cfg.focus_punch_fov * k * k * (3 - 2 * k)
end
function C.fov()
    C.restituer()
    local ajout = 0
    if C.niveau > 0.001 and cfg.camera_methode ~= 1 then ajout = ajout + cfg.camera_fov * C.niveau end
    ajout = ajout - cfg.focus_zoom * (C.focus_niv or 0)
    ajout = ajout - C.punch()
    if math.abs(ajout) < 0.01 then return end
    local cam = sdk.get_primary_camera()
    local fov = appeler(cam, "get_FOV")
    if type(fov) ~= "number" then return end
    C.sauve = { cam = cam, fov = fov }
    appeler(cam, "set_FOV", math.max(5, math.min(150, fov + ajout)))
end
-- v0.44 : caméra tournée vers le pion relevé. Rotation écrite après la mise à jour de
-- la caméra par le jeu (LateUpdateBehavior), rendue avant la suivante (UpdateBehavior).
function C.rendre_rot()
    local r = C.rot_sauve
    C.rot_sauve = nil
    if r then pcall(function() r.tr:call("set_Rotation", r.rot) end) end
    local q = C.pos_sauve                                      -- v0.2 : position rendue aussi
    C.pos_sauve = nil
    if q then pcall(function() q.tr:call("set_Position", q.pos) end) end
end
function C.viser()
    C.rendre_rot()
    local now = os.clock()
    local dt = C.focus_t and math.min(0.1, now - C.focus_t) or 0
    C.focus_t = now
    local cible = (C.focus_chr and cfg.focus_camera) and 1 or 0
    local v = dt / math.max(0.05, cfg.focus_transition)
    C.focus_niv = C.focus_niv or 0
    if C.focus_niv < cible then C.focus_niv = math.min(cible, C.focus_niv + v) else C.focus_niv = math.max(cible, C.focus_niv - v) end
    if C.focus_niv <= 0.001 then C.vise = nil; C.orb_niv = 0; C.focus_depuis = nil; return end
    local chr = C.focus_chr or C.focus_dernier
    if C.focus_chr then C.focus_dernier = C.focus_chr end
    local pc, pj = position(chr), position(joueur())
    -- v0.79 : point visé lissé (glisse d'un pion à l'autre, suit le pion qui se relève)
    if pc then
        local tx, ty, tz = pc.x, pc.y + cfg.focus_hauteur, pc.z
        local a = 1 - math.exp(-dt / math.max(0.01, cfg.focus_douceur))
        if C.vise == nil or dt == 0 then C.vise = { x = tx, y = ty, z = tz }
        else C.vise = { x = C.vise.x + (tx - C.vise.x) * a, y = C.vise.y + (ty - C.vise.y) * a, z = C.vise.z + (tz - C.vise.z) * a } end
        pc = { x = C.vise.x, y = C.vise.y - 1.0, z = C.vise.z }
    end
    local cam = sdk.get_primary_camera()
    local tr = appeler(appeler(cam, "get_GameObject"), "get_Transform")
    local p = appeler(tr, "get_Position")
    local e = appeler(tr, "get_EulerAngle")
    local rot = appeler(tr, "get_Rotation")
    if not (pc and pj and p and e and rot) then return end
    local function lacet(x, z) return math.atan(-x, -z) end
    local function tangage(x, y, z) return math.atan(y, math.sqrt(x * x + z * z)) end
    local ax, ay, az = pj.x - p.x, pj.y + 1.4 - p.y, pj.z - p.z
    local dx, dy, dz = pc.x - p.x, pc.y + 1.0 - p.y, pc.z - p.z
    local dl = lacet(dx, dz) - lacet(ax, az)
    while dl > math.pi do dl = dl - 2 * math.pi end
    while dl < -math.pi do dl = dl + 2 * math.pi end
    local dtg = tangage(dx, dy, dz) - tangage(ax, ay, az)
    local k = C.focus_niv * C.focus_niv * (3 - 2 * C.focus_niv) * math.max(0, math.min(1, cfg.focus_force))
    -- v0.2 : orbite — la caméra glisse lentement autour du pion visé (position ET visée),
    -- angle borné ; position rendue au jeu à chaque image comme la rotation
    local orb = 0
    if cfg.focus_orbite and C.focus_chr and C.focus_depuis then
        orb = math.rad(math.min(cfg.focus_orbite_max, cfg.focus_orbite_vitesse * (now - C.focus_depuis))) * k
    end
    C.orb_niv = C.orb_niv or 0
    local vo = dt / math.max(0.05, cfg.focus_transition)
    if orb > C.orb_niv then C.orb_niv = math.min(orb, C.orb_niv + vo * 2) else C.orb_niv = math.max(orb, C.orb_niv - vo * 2) end
    if C.orb_niv > 0.0005 and pc then
        local rx, rz = p.x - pc.x, p.z - pc.z
        local co, so = math.cos(C.orb_niv), math.sin(C.orb_niv)
        local nx, nz = pc.x + rx * co - rz * so, pc.z + rx * so + rz * co
        C.pos_sauve = { tr = tr, pos = p }
        if pcall(function() tr:call("set_Position", Vector3f.new(nx, p.y, nz)) end) then
            dl = dl + C.orb_niv                                   -- la visée suit le déplacement
        else
            C.pos_sauve = nil
        end
    end
    C.rot_sauve = { tr = tr, rot = rot }
    local ok = pcall(function()
        tr:call("set_EulerAngle", Vector3f.new(e.x + dtg * k * cfg.focus_sens_v, e.y + dl * k * cfg.focus_sens_h, e.z))
    end)
    if not C.focus_note then
        C.focus_note = true
        evenement("caméra : visée du pion " .. (ok and "appliquée" or "IMPOSSIBLE"))
    end
end
do
    local ok = false
    if re.on_application_entry then
        ok = pcall(re.on_application_entry, "UpdateBehavior", function()
            local okD, err = pcall(C.distance)
            if not okD and not C.signale then C.signale = true; evenement("caméra : erreur " .. tostring(err)) end
        end)
        pcall(re.on_application_entry, "EndRendering", function() pcall(C.restituer) end)
        pcall(re.on_application_entry, "LateUpdateBehavior", function() pcall(C.viser) end)
    end
    if not ok then re.on_frame(function() pcall(C.distance) end) end
    if re.on_pre_application_entry then
        -- deuxième écriture juste avant la mise à jour de la caméra (sans avancer le temps)
        pcall(re.on_pre_application_entry, "LateUpdateBehavior", function() pcall(C.distance, true) end)
        pcall(re.on_pre_application_entry, "BeginRendering", function() pcall(C.fov) end)
        if pcall(re.on_pre_application_entry, "UpdateBehavior", function() pcall(C.restituer); pcall(C.rendre_rot); pcall(R.suivre_deco) end) then
            R.deco_par_hook = true                 -- v0.2 : on_frame ne le refait plus
        end
    end
end
if re.on_script_reset then re.on_script_reset(function() pcall(C.restituer); pcall(C.rendre); pcall(C.rendre_distance); pcall(C.rendre_rot) end) end

function R.hud_apercu_tick()
    if R.hud_apercu_actif() then
        R.hud.boucle = true
        local t = os.clock()
        if not R.frange.essai then R.frange.essai = t end
        if not R.anneau_essai then R.anneau_essai = t end
    elseif R.hud.boucle then
        R.hud.boucle = false
        R.frange.essai, R.anneau_essai = nil, nil
    end
end
re.on_frame(function()
    R.creation_mod = false
    joueur_cache_ouvrir()                                 -- v0.2
    local avec_shards = R.sync_sol()
    pcall(R.hc_brancher)
    pcall(R.hud_apercu_tick)
    if not R.impose_fait then R.impose_fait = true; pcall(R.imposer); pcall(completer_effets) end
    if not avec_shards then          -- Shards of Life absent : ce mod reste inactif
        pcall(R.suivre_langue)
        pcall(R.dessiner_alerte)
        pcall(ecrire_journal)
        joueur_cache_fermer()
        return
    end
    pcall(dessiner_zone)
    pcall(R.dessiner_anneau)
    pcall(R.dessiner_frange)
    pcall(R.suivre_essai_cercle)
    pcall(ecrire_journal)
    pcall(mettre_a_jour)
    local okE, appui, tenu, appui2, tenu2 = pcall(lire_entrees)
    if okE then pcall(suivre_declencheur, appui, tenu, appui2, tenu2) end
    if R.final_a and os.clock() >= R.final_a then
        R.final_a = nil
        pcall(lancer_effets, "final", 0)
    end
    do
        local okP, errP = pcall(R.suivre_post)
        if not okP and not R.post_err then
            R.post_err = true
            evenement("ERREUR séquence de relevé : " .. tostring(errP))
        end
    end
    pcall(R.suivre_reessais)
    pcall(R.suivre_geste)
    pcall(R.suivre_vol)
    pcall(R.suivre_atterrissage)
    pcall(R.suivre_tuer)
    if not R.deco_par_hook then pcall(R.suivre_deco) end
    pcall(R.suivre_deblocage_differe)
    pcall(suivre_ralenti)
    pcall(R.suivre_temps)
    pcall(R.dessiner_barre)
    pcall(R.suivre_pv_verifs)
    joueur_cache_fermer()                                 -- v0.2
end)

if re.on_script_reset then re.on_script_reset(function() pcall(R.vit_tout); vitesse_globale(1.0) end) end

-- ----------------------------------------------------------------------------
-- Menu REFramework : un tiroir principal, des sous-tiroirs
-- ----------------------------------------------------------------------------
local function case(lib, cle)
    local ch, v = imgui.checkbox(lib, cfg[cle])
    if ch then cfg[cle] = v; sauver() end
end
local function curseur_f(lib, cle, mn, mx, f)
    local ch, v = imgui.slider_float(lib, cfg[cle], mn, mx, f or "%.2f")
    if ch then cfg[cle] = v; sauver() end
end
local function curseur_i(lib, cle, mn, mx)
    local ch, v = imgui.slider_int(lib, cfg[cle], mn, mx)
    if ch then cfg[cle] = v; sauver() end
end

function R.choisir_couleur(lib, cle)
    if not imgui.tree_node(lib) then return end
    local c = math.tointeger(cfg[cle]) or defauts[cle]
    local okp, ch, v = pcall(imgui.color_picker, "Choisir la couleur##cp_" .. cle, c)
    if okp then
        if ch and v ~= nil then cfg[cle] = (math.tointeger(v) or math.floor(v)) & 0xFFFFFFFF; sauver() end
    else
        local cr, cv, cb = c & 0xFF, (c >> 8) & 0xFF, (c >> 16) & 0xFF
        local a1, nr = imgui.slider_int("Rouge##cr_" .. cle, cr, 0, 255)
        local a2, nv = imgui.slider_int("Vert##cv_" .. cle, cv, 0, 255)
        local a3, nb = imgui.slider_int("Bleu##cb_" .. cle, cb, 0, 255)
        if a1 or a2 or a3 then
            cfg[cle] = (c & 0xFF000000) | ((a3 and nb or cb) << 16) | ((a2 and nv or cv) << 8) | (a1 and nr or cr)
            sauver()
        end
    end
    c = math.tointeger(cfg[cle]) or c
    local ach, na = imgui.slider_int("Transparence (0 = invisible, 255 = opaque)##ca_" .. cle, (c >> 24) & 0xFF, 0, 255)
    if ach then cfg[cle] = (na << 24) | (c & 0xFFFFFF); sauver() end
    imgui.tree_pop()
end

-- v0.42 : tiroir unique « Interface à l'écran (HUD) » : tous les éléments à plat (aucun sous-tiroir à ouvrir sauf les sélecteurs de couleur)
function R.hud_selecteur(lib, cle)
    if not imgui.tree_node(lib) then return end
    local c = math.tointeger(cfg[cle]) or defauts[cle]
    local okp, ch, v = pcall(imgui.color_picker, "Choisir la couleur##cp_" .. cle, c)
    if okp then
        if ch and v ~= nil then cfg[cle] = (math.tointeger(v) or math.floor(v)) & 0xFFFFFFFF; sauver() end
    else
        imgui.text("(sélecteur de couleur indisponible : curseurs Rouge / Vert / Bleu)")
        local cr, cv, cb = c & 0xFF, (c >> 8) & 0xFF, (c >> 16) & 0xFF
        local a1, nr = imgui.slider_int("Rouge##cr_" .. cle, cr, 0, 255)
        local a2, nv = imgui.slider_int("Vert##cv_" .. cle, cv, 0, 255)
        local a3, nb = imgui.slider_int("Bleu##cb_" .. cle, cb, 0, 255)
        if a1 or a2 or a3 then
            cfg[cle] = (c & 0xFF000000) | ((a3 and nb or cb) << 16) | ((a2 and nv or cv) << 8) | (a1 and nr or cr)
            sauver()
        end
    end
    c = math.tointeger(cfg[cle]) or c
    local ach, na = imgui.slider_int("Transparence (0 = invisible, 255 = opaque)##ca_" .. cle, (c >> 24) & 0xFF, 0, 255)
    if ach then cfg[cle] = (na << 24) | (c & 0xFFFFFF); sauver() end
    imgui.tree_pop()
end
function R.hud_couleur(lib, cle)
    if not imgui.tree_node(lib) then return end
    R.hud_selecteur("Couleur du haut##h_" .. cle, cle)
    R.hud_selecteur("Couleur du bas (dégradé)##b_" .. cle, cle .. "2")
    if imgui.button("Même couleur en bas (pas de dégradé)##mm_" .. cle) then cfg[cle .. "2"] = cfg[cle]; sauver() end
    imgui.same_line()
    if imgui.button("Remettre par défaut##cd_" .. cle) then cfg[cle] = defauts[cle]; cfg[cle .. "2"] = defauts[cle .. "2"]; sauver() end
    imgui.tree_pop()
end
function R.menu_hud()
    R.hud.vu = os.clock()
    local ch, v = imgui.checkbox("Aperçu en direct de tous les éléments tant que ce tiroir est ouvert", R.hud.apercu)
    if ch then R.hud.apercu = v end
    imgui.text("L'aperçu montre la barre d'incantation, la frange d'écran, l'anneau et le cercle de portée, même sans lancer de sort.")
    imgui.text("(La jauge d'éclats elle-même se règle dans BardN Shards of Life.)")
    imgui.separator()
    imgui.text("RÉGLAGE DE GROUPE (tous les éléments d'un coup)")
    curseur_f("Opacité de tous les éléments", "hud_opacite", 0.0, 1.0)
    if imgui.button("Remettre le réglage de groupe par défaut##hud_raz") then cfg.hud_opacite = defauts.hud_opacite; sauver() end
    imgui.separator()
    imgui.text("HUD CONTROLS")
    case("Utiliser les règles de HUD Controls (s'il est installé)", "use_hud_controls")
    imgui.text("  état : " .. (cfg.use_hud_controls and R.hc.statut or "désactivé"))
    case("  message « le cercle reste ouvert avec cette arme, le sort fonctionne quand même »", "message_cercle_casse")
    imgui.separator()
    imgui.text("1. BARRE D'INCANTATION (sous la jauge de Shards of Life, pour Breath of Life et Slow Time)")
    case("  texte « PRÊT — relâche pour lancer » pendant l'incantation", "barre_texte_incantation")
    curseur_i("Épaisseur de la barre (px)", "barre_epaisseur", 1, 20)
    curseur_f("Opacité de la barre", "barre_opacite", 0.05, 1.0)
    curseur_i("Décalage horizontal de la barre (px)", "barre_decalage_x", -600, 600)
    curseur_i("Décalage vertical de la barre (px)", "barre_decalage_y", -300, 300)
    R.hud_couleur("Fond de la barre##barre_c1", "barre_col_fond")
    R.hud_couleur("Progression de la barre##barre_c2", "barre_col_progres")
    R.hud_couleur("Barre prête##barre_c3", "barre_col_pret")
    if imgui.button("Remettre la barre par défaut##barre_raz") then
        for _, cle in ipairs({ "barre_epaisseur", "barre_opacite", "barre_decalage_x", "barre_decalage_y", "barre_texte_incantation",
            "barre_col_fond", "barre_col_fond2", "barre_col_progres", "barre_col_progres2", "barre_col_pret", "barre_col_pret2" }) do cfg[cle] = defauts[cle] end
        sauver()
    end
    imgui.separator()
    imgui.text("2. FRANGE D'ÉCRAN PENDANT L'INCANTATION")
    case("Afficher la frange", "frange_actif")
    curseur_f("Largeur au début de la charge (% de l'écran)", "frange_largeur_min", 0.5, 30.0, "%.1f")
    curseur_f("Largeur à la fin de la charge (%)", "frange_largeur_max", 0.5, 30.0, "%.1f")
    curseur_f("Largeur quand le sort est prêt (%)", "frange_largeur_prete", 1.0, 40.0, "%.1f")
    curseur_f("Opacité au début de la charge", "frange_opa_min", 0.0, 1.0)
    curseur_f("Opacité à la fin de la charge", "frange_opa_max", 0.0, 1.0)
    curseur_f("Opacité quand le sort est prêt", "frange_opa_prete", 0.0, 1.0)
    curseur_f("Douceur du dégradé (plus haut = plus près des bords)", "frange_douceur", 0.5, 5.0, "%.1f")
    curseur_f("Durée de la disparition (s)", "frange_fondu", 0.1, 3.0)
    R.choisir_couleur("Couleur de la frange##fr_c", "frange_col")
    if imgui.button("Essayer la frange##fr_essai") then R.frange.essai = os.clock() end
    imgui.same_line()
    if imgui.button("Remettre la frange par défaut##fr_raz") then
        for _, cle in ipairs({ "frange_actif", "frange_col", "frange_largeur_min", "frange_largeur_max", "frange_largeur_prete",
            "frange_opa_min", "frange_opa_max", "frange_opa_prete", "frange_douceur", "frange_fondu" }) do cfg[cle] = defauts[cle] end
        sauver()
    end
    imgui.separator()
    imgui.text("3. CERCLES AU SOL")
    imgui.text("Cercle de portée de Breath of Life (rayon réglé aussi dans Breath of Life > Portée) :")
    case("  pendant l'incantation", "zone_pendant_canalisation")
    case("  aperçu quand le sort est utilisable", "zone_quand_prete")
    case("  toujours (pour régler le rayon)", "zone_toujours")
    curseur_f("Épaisseur du trait du cercle de portée", "zone_epaisseur", 1.0, 8.0, "%.1f")
    curseur_f("Rayon à plat (m)", "rayon", 1.0, 50.0, "%.1f")
    imgui.text("Cercle d'incantation dessiné (anneau qui se resserre autour du personnage) :")
    if not cfg.cercle_mage then imgui.text("  (cercle du jeu décoché : l'anneau suit la durée d'incantation réglée dans la Chorégraphie)") end
    for i, lib in ipairs({ "toujours", "jamais", "sauf Guerrier et Mage (leur cercle du jeu se resserre déjà)" }) do
        if imgui.button((cfg.anneau_affichage == i and "[x] " or "[ ] ") .. lib .. "##am" .. i) then cfg.anneau_affichage = i; sauver() end
    end
    curseur_f("Rayon au début de l'incantation (m)", "anneau_rayon_debut", 0.5, 5.0, "%.2f")
    curseur_f("Rayon quand le sort est prêt (m)", "anneau_rayon_fin", 0.1, 3.0, "%.2f")
    curseur_f("Épaisseur du trait de l'anneau (px)", "anneau_epaisseur", 1.0, 8.0, "%.1f")
    R.choisir_couleur("Couleur de l'anneau##an1", "anneau_col")
    R.choisir_couleur("Couleur des détails (anneau intérieur, onde finale)##an2", "anneau_col2")
    if imgui.button("Essayer l'anneau (sans lancer de sort)##an_essai") then R.anneau_essai = os.clock() end
    imgui.same_line()
    if imgui.button("Remettre les cercles par défaut##an_raz") then
        for _, cle in ipairs({ "anneau_affichage", "anneau_rayon_debut", "anneau_rayon_fin", "anneau_epaisseur", "anneau_col", "anneau_col2",
            "zone_pendant_canalisation", "zone_quand_prete", "zone_toujours", "zone_epaisseur" }) do cfg[cle] = defauts[cle] end
        sauver()
    end
end


-- v0.2 : titres de section en orange (clarté) ; nouveautés de la version en cours en cyan clair (repérage de test)
local ORANGE, CYAN = 0xFF00A5FF, 0xFFFFE65A
local function titre(txt) imgui.text_colored(txt, ORANGE) end
local nouveau_ok = false
local function debut_nouveau() nouveau_ok = pcall(imgui.push_style_color, 0, CYAN) end
local function fin_nouveau() if nouveau_ok then pcall(imgui.pop_style_color, 1) end; nouveau_ok = false end

re.on_draw_ui(function()
    if not imgui.tree_node(NOM) then return end
    imgui.text("Langue / Language :")
    for _, o in ipairs({ { "fr", "Français" }, { "en", "English" }, { "auto", "Auto" } }) do
        imgui.same_line()
        if imgui.button((cfg.langue == o[1] and "[x] " or "[ ] ") .. o[2] .. "##lg" .. o[1]) then R.changer_langue(o[1]) end
    end
    if cfg.langue == "auto" then
        imgui.same_line()
        imgui.text("(" .. (R.langue_jeu == "fr" and "jeu : français" or (R.langue_jeu == "en" and "game: English" or "?")) .. ")")
    end
    case("Mod actif", "actif")
    imgui.same_line()
    debut_nouveau(); imgui.text("  (en cyan : ce qui a changé en v0.5 — compatibilité Shards of Life v0.48)"); fin_nouveau()
    if R.sol then
        imgui.text(R.fmt("Shards of Life détecté (v%s) : %d éclat(s)", tostring(R.sol.version), unites))
        imgui.text(R.fmt("Éclats de vie : %d   |   %s%s", unites, en_combat and "en combat" or "hors combat", canal and "   |   INCANTATION" or ""))
        imgui.text("Les éclats de vie se règlent dans le mod BardN Shards of Life.")
        if R.post then imgui.text(R.fmt("Séquence de relevé en cours : phase %s", tostring(R.post.phase))) end
    else
        imgui.text("BardN Shards of Life est REQUIS : installe-le et active-le (ce mod reste inactif sans lui).")
    end

    -- 1. PRESETS ---------------------------------------------------------------
    if imgui.tree_node("Presets") then
        imgui.text("Default = « Réglages par défaut… » (configuration recommandée) ; Custom = tes 3 emplacements ci-dessous.")
        for i = 1, 3 do
            local info = R.preset_info("preset_" .. i)
            imgui.text(R.fmt("Preset %d : %s", i, info or "vide"))
            imgui.same_line()
            if imgui.button("Sauver##ps" .. i) then R.preset_sauver("preset_" .. i, "Preset " .. i) end
            if info then
                imgui.same_line()
                if imgui.button("Charger##pc" .. i) then R.preset_charger("preset_" .. i) end
            end
        end
        local av = R.preset_info("avant_reset")
        if av then
            imgui.text("Avant la dernière remise par défaut : " .. av)
            imgui.same_line()
            if imgui.button("Restaurer##pr") then R.preset_charger("avant_reset") end
        end
        if R.reset_arme and os.clock() - R.reset_arme < 3 then
            if imgui.button(">>> CONFIRMER : tout remettre par défaut (réglages actuels sauvés avant) <<<") then
                R.reset_arme = nil
                R.preset_sauver("avant_reset", "Avant remise par défaut")
                local langue_gardee = cfg.langue
                for k, v in pairs(defauts) do cfg[k] = v end
                cfg.final_choix = copie_profonde(BASE.final_choix)   -- v0.14
                cfg.langue = langue_gardee
                completer_effets()
                R.imposer()
                sauver()
                evenement("réglages remis par défaut (anciens réglages sauvés)")
            end
        elseif imgui.button("Réglages par défaut…") then
            R.reset_arme = os.clock()
        end
        imgui.tree_pop()
    end

    -- 2. BREATH OF LIFE ----------------------------------------------------------
    if imgui.tree_node("Breath of Life (résurrection des pions)") then
        case("Capacité active", "capacite_active")
        curseur_i("Coût (éclats de vie)", "cout", 1, 10)
        imgui.text("Utilisable :")
        for i, lib in ipairs({ "toujours", "si au moins un pion est à terre", "si tous les pions sont à terre" }) do
            imgui.same_line()
            if imgui.button((cfg.condition_lancement == i and "[x] " or "[ ] ") .. lib .. "##cl") then cfg.condition_lancement = i; sauver() end
        end
        imgui.text("Les éclats ne sont pris que si le sort part (jamais en cas d'interruption).")
        imgui.separator()
        titre("PORTÉE")
        curseur_f("Rayon à plat (m)", "rayon", 1.0, 50.0, "%.1f")
        case("Portée en hauteur séparée (cylindre, mesurée depuis le sol)", "portee_cylindre")
        if cfg.portee_cylindre then
            curseur_f("  vers le haut (m)", "portee_haut", 0.0, 60.0, "%.0f")
            curseur_f("  vers le bas (m)", "portee_bas", 0.0, 60.0, "%.0f")
        else
            imgui.text("  (sinon : sphère de ce rayon autour de l'Insurgé)")
        end
        imgui.text("(le cercle de portée dessiné au sol se règle dans « Interface à l'écran (HUD) »)")
        imgui.separator()
        titre("COMMANDES")
        imgui.text(R.fmt("Combinaison manette : 0x%X (défaut 0x40084 = croix gauche + B) — boutons enfoncés : 0x%X", cfg.combo_manette, boutons()))
        if capture then
            imgui.text(">>> Maintiens la nouvelle combinaison, puis relâche tout…")
            if imgui.button("Annuler la capture") then capture = nil end
        else
            if imgui.button("Capturer une combinaison") then capture = { masque = 0, cle = "combo_manette" } end
            imgui.same_line()
            if imgui.button("Par défaut##cm") then cfg.combo_manette = defauts.combo_manette; sauver() end
        end
        imgui.text("Touche clavier : " .. (cfg.touche_clavier > 0 and tostring(cfg.touche_clavier) or "aucune"))
        imgui.same_line()
        if capture_clavier then imgui.text(">>> appuie sur la touche…")
        else
            if imgui.button("Capturer##tc") then capture_clavier = true end
            imgui.same_line()
            if imgui.button("Aucune##tc") then cfg.touche_clavier = 0; sauver() end
        end
        curseur_f("Temps de maintien pour démarrer (s)", "maintien", 0.0, 2.0)
        case("Lancer au relâchement de B (comme les sorts de Mage)", "lancer_au_relachement")
        if cfg.lancer_au_relachement then
            curseur_f("  maintien maximal une fois prêt (s, 0 = illimité)", "maintien_max", 0.0, 30.0, "%.1f")
        end
        case("Annuler avec un bouton", "annulation_active")
        if cfg.annulation_active then
            imgui.text(R.fmt("  bouton : 0x%X (défaut 0x200 = LT)", cfg.annulation_bouton))
            imgui.same_line()
            if not capture and imgui.button("Capturer##ca") then capture = { masque = 0, cle = "annulation_bouton" } end
        end
        case("Interrompre si la combinaison est relâchée avant la fin", "interrompre_si_relache")
        case("Interrompre si l'Insurgé est touché", "interrompre_si_touche")
        imgui.tree_pop()
    end

    -- 3. SLOW TIME ---------------------------------------------------------------
    if imgui.tree_node("Slow Time (ralentissement du temps)") then
        case("Capacité active", "temps_actif")
        curseur_i("Coût (éclats de vie)", "temps_cout", 1, 10)
        curseur_f("Durée du ralentissement (s réelles)", "temps_duree", 1.0, 30.0, "%.1f")
        curseur_f("Vitesse du monde (0,2 = -80 %)", "temps_vitesse", 0.05, 0.95, "%.2f")
        curseur_f("Incantation avant l'effet (s)", "temps_canal", 0.0, 3.0, "%.1f")
        case("L'Insurgé garde sa vitesse normale (compensation)", "temps_compenser")
        case("Animation de sauvetage pendant l'incantation", "temps_animation")
        imgui.text(R.fmt("Combinaison manette : 0x%X (défaut 0x40088 = croix droite + B) — boutons enfoncés : 0x%X", cfg.temps_combo, boutons()))
        if capture then
            imgui.text(">>> Maintiens la nouvelle combinaison, puis relâche tout…")
        else
            if imgui.button("Capturer une combinaison##tcb") then capture = { masque = 0, cle = "temps_combo" } end
            imgui.same_line()
            if imgui.button("Par défaut##tcb2") then cfg.temps_combo = defauts.temps_combo; sauver() end
        end
        imgui.text("Touche clavier : " .. (cfg.temps_touche_clavier > 0 and tostring(cfg.temps_touche_clavier) or "aucune"))
        imgui.same_line()
        if capture_clavier then imgui.text(">>> appuie sur la touche…")
        else
            if imgui.button("Capturer##ttc") then capture_clavier = "temps_touche_clavier" end
            imgui.same_line()
            if imgui.button("Aucune##ttc") then cfg.temps_touche_clavier = 0; sauver() end
        end
        imgui.text("Jamais en même temps que Breath of Life ou un autre ralenti.")
        if R.temps then
            imgui.text(R.fmt("EN COURS : encore %.1f s", math.max(0, R.temps.fin - os.clock())))
            if imgui.button("Arrêter maintenant##tstop") then R.temps_arreter("arrêt manuel") end
        else
            if imgui.button("Lancer Slow Time (test, gratuit)##tgo") then
                if not R.vit_actif() then R.temps_demarrer() end
            end
        end
        imgui.tree_pop()
    end

    -- 4. CHORÉGRAPHIE -----------------------------------------------------------
    if imgui.tree_node("Chorégraphie") then
        local avant = (cfg.rengainer and cfg.delai_rengainer or 0) + (cfg.saut_avant_elevation and cfg.saut_delai or 0)
        local d_cercle = cfg.cercle_duree_mesuree > 0.3 and cfg.cercle_duree_mesuree or 5.5
        imgui.text(R.fmt("Avant le cercle ≈ %.2f s (+ %.2f s max si l'arme n'est pas rangée), puis cercle ≈ %.1f s",
            avant, cfg.rengainer and cfg.cercle_attente_max or 0, cfg.cercle_mage and d_cercle or cfg.duree_incantation))
        imgui.text("Déroulé : début → incantation → lumière finale → pions relevés un par un → atterrissage.")
        imgui.separator()
        titre("1. DÉBUT")
        case("Rengainer avant d'incanter", "rengainer")
        if cfg.rengainer then
            curseur_f("  délai pour rengainer (s)", "delai_rengainer", 0.0, 2.0, "%.2f")
            curseur_f("  attente maximale de la fin du rengainage (s)", "cercle_attente_max", 0.0, 2.0, "%.2f")
        end
        case("Sauter avant l'élévation", "saut_avant_elevation")
        if cfg.saut_avant_elevation then curseur_f("  délai entre le saut et l'élévation (s)", "saut_delai", 0.0, 1.5, "%.2f") end
        case("L'endurance ne baisse pas pendant la lévitation", "levitation_endurance")
        imgui.separator()
        titre("2. INCANTATION")
        imgui.text("Cercle d'incantation (Éclat sacré du Mage, ≈ 5,5 s natif) : toujours actif")
        imgui.same_line()
        if imgui.button((R.essai_cercle_fin and "Arrêter l'essai" or "Essayer") .. "##cercle") then
            if R.essai_cercle_fin then
                R.essai_cercle_fin = nil; R.anneau_essai = nil
                debloquer(joueur(), "arrêt de l'essai du cercle")
            elseif canal == nil then
                local d = cfg.cercle_duree_mesuree > 0.3 and cfg.cercle_duree_mesuree or 5.5
                lancer_cercle(joueur(), "essai")
                R.essai_cercle_fin = os.clock() + d + 0.5
                R.anneau_essai = os.clock()
            end
        end
        imgui.text("  Il fixe la durée (≈ 5,5 s) et garde la lévitation pilotable. Avec un bâton de mage il se resserre ;")
        imgui.text("  avec une autre arme (ex. lance du Chevalier mage) il reste ouvert : la frange d'écran donne alors la progression,")
        imgui.text("  un message l'indique à l'écran, et le sort fonctionne quand même.")
        imgui.text("  (La frange d'écran se règle dans le tiroir « Interface à l'écran (HUD) ».)")
        imgui.separator()
        titre("3. APRÈS L'INCANTATION")
        case("Rester en lévitation", "vol_maintien")
        if cfg.vol_maintien then
            for i, lib in ipairs({ "pendant une durée fixe", "jusqu'au dernier pion relevé" }) do
                imgui.same_line()
                if imgui.button((cfg.vol_fin == i and "[x] " or "[ ] ") .. lib .. "##vf") then cfg.vol_fin = i; sauver() end
            end
            if cfg.vol_fin == 1 then curseur_f("  durée en l'air (s)", "vol_duree", 0.2, 10.0, "%.1f")
            else curseur_f("  reste en l'air après le dernier pion (s)", "vol_apres", 0.0, 3.0, "%.1f") end
        end
        imgui.text("Moment du sort (effet de fin d'incantation, puis pions relevés) :")
        for i, lib in ipairs({ "à la fin du ralenti", "au retour au sol", "au relâchement, en plein vol",
                               "après un délai", "sur le geste du sort (essai)" }) do
            if i ~= 1 then imgui.same_line() end
            if imgui.button((cfg.final_apres == i and "[x] " or "[ ] ") .. lib .. "##fa") then cfg.final_apres = i; sauver() end
        end
        if cfg.final_apres == 4 then curseur_f("  délai après le relâchement (s)", "final_delai_relache", 0.0, 3.0, "%.2f") end
        if cfg.final_apres == 5 then
            curseur_f("  frappe après le début du geste (s, 0 = à la fin)", "geste_delai", 0.0, 2.0, "%.2f")
            imgui.text("  geste trouvé : " .. (cfg.geste_nom ~= "" and cfg.geste_nom or "pas encore"))
        end
        imgui.separator()
        titre("4. PIONS RELEVÉS")
        case("Un par un (sinon : tous d'un coup au lancement)", "focus_actif")
        if cfg.focus_actif then
            curseur_f("  délai avant le 1er pion (s)", "focus_delai", 0.0, 3.0, "%.2f")
            curseur_f("  pion relevé après (s, caméra déjà sur lui)", "focus_reveil", 0.0, 3.0, "%.2f")
            curseur_f("  durée par pion (s)", "focus_duree", 0.5, 5.0, "%.2f")
            if cfg.final_apres == 2 then curseur_f("  attente maximale du retour au sol (s)", "chute_max", 0.3, 5.0, "%.1f") end
            imgui.text("Dernier pion (quand il y en a plusieurs) :")
            case("  mis en valeur : temps plus long, ralenti approfondi relâché à son réveil", "dernier_pion_special")
            if cfg.dernier_pion_special then
                curseur_f("    durée multipliée par", "dernier_pion_duree_mult", 1.0, 4.0, "x %.2f")
                case("    ralenti approfondi tant que la caméra est sur lui", "dernier_pion_ralenti")
                if cfg.dernier_pion_ralenti then curseur_f("      vitesse du jeu pendant ce ralenti", "dernier_pion_ralenti_vitesse", 0.05, 1.0, "%.2f") end
            end
        end
        imgui.separator()
        titre("5. RALENTI")
        case("Ralenti", "ralenti_actif")
        if cfg.ralenti_actif then
            for i, lib in ipairs({ "au lancement", "quand le premier pion revient à la vie" }) do
                imgui.same_line()
                if imgui.button((cfg.ralenti_moment == i and "[x] " or "[ ] ") .. lib .. "##rm") then cfg.ralenti_moment = i; sauver() end
            end
            if cfg.ralenti_moment == 1 then curseur_f("  délai (s après le lancement)", "ralenti_delai", 0.0, 5.0, "%.2f") end
            curseur_f("  vitesse du jeu", "ralenti_vitesse", 0.05, 1.0)
            curseur_f("  durée (s réelles)", "ralenti_duree", 0.1, 5.0, "%.1f")
            if imgui.button("Tester le ralenti") then lancer_ralenti(true) end
        end
        imgui.separator()
        titre("6. ATTERRISSAGE")
        case("Reprendre le contrôle dès que l'Insurgé touche le sol", "controle_atterrissage")
        imgui.tree_pop()
    end

    -- 5. CAMÉRA ----------------------------------------------------------------
    if imgui.tree_node("Caméra") then
        titre("PENDANT L'INCANTATION")
        case("Dézoomer", "camera_actif")
        if cfg.camera_actif then
            case("  recul réel (distance native du jeu)", "camera_distance_on")
            if cfg.camera_distance_on then curseur_f("    recul maximal (≈ m)", "camera_distance_ajout", 0.0, 15.0, "%.1f") end
            curseur_f("  champ de vision ajouté (degrés, 0 = aucun)", "camera_fov", 0.0, 40.0, "%.0f")
            curseur_f("  délai avant que la caméra bouge (s)", "camera_delai", 0.0, 10.0, "%.1f")
            curseur_f("  durée pour atteindre le dézoom maximal (s)", "camera_duree_zoom", 0.2, 10.0, "%.1f")
            curseur_f("  durée du retour (s)", "camera_retour", 0.05, 3.0, "%.2f")
            if imgui.button("Essayer le dézoom (3 s)") then C.essai_fin = os.clock() + 3.0 end
        end
        imgui.separator()
        titre("SUR LES PIONS RELEVÉS (relevé un par un)")
        case("Tourner la caméra vers chaque pion", "focus_camera")
        if cfg.focus_camera then
            curseur_f("  zoom sur le pion (degrés en moins)", "focus_zoom", 0.0, 30.0, "%.1f")
            curseur_f("  vitesse de rotation (s, plus = plus doux)", "focus_transition", 0.05, 2.0, "%.2f")
            curseur_f("  souplesse (s, plus = plus fluide)", "focus_douceur", 0.0, 1.5, "%.2f")
            curseur_f("  hauteur visée sur le pion (m)", "focus_hauteur", 0.0, 2.0, "%.2f")
            curseur_f("  intensité (1 = pion au centre, 0,5 = à mi-chemin)", "focus_force", 0.1, 1.0, "%.2f")
            case("  orbite : la caméra glisse lentement autour du pion visé", "focus_orbite")
            if cfg.focus_orbite then
                debut_nouveau()
                curseur_f("    vitesse (degrés par seconde)", "focus_orbite_vitesse", 1.0, 30.0, "%.0f")
                curseur_f("    angle maximal (degrés)", "focus_orbite_max", 2.0, 60.0, "%.0f")
                fin_nouveau()
            end
            case("  coup de zoom au réveil de chaque pion", "focus_punch")
            if cfg.focus_punch then
                curseur_f("    intensité (degrés en moins)", "focus_punch_fov", 1.0, 25.0, "%.1f")
                debut_nouveau()
                curseur_f("    durée (s)", "focus_punch_duree", 0.1, 1.0, "%.2f")
                fin_nouveau()
                if imgui.button("Essayer le coup de zoom##punch_essai") then C.punch_t = os.clock() end
            end
        end
        imgui.tree_pop()
    end
    -- 6. EFFETS VISUELS ----------------------------------------------------------
    if imgui.tree_node("Effets visuels") then
        case("  lumière finale de Breath of Life jouée sur l'Insurgé quand Shards of Life le relève (seconde vie)", "seconde_vie_effet")
        local e = R.effet_final()
        local r = e and cfg.effets[e.cle]
        if r then
            case("Garder la lumière sacrée du jeu à la fin de l'incantation (Éclat sacré natif)", "natif_fin")
            if not cfg.natif_fin then imgui.text("  (essai : le mod bloque l'effet du jeu ; le journal dit ce qu'il a bloqué)") end
            local function liste(titre, qui)
                imgui.text(titre)
                for k, src in ipairs(R.SOURCES_FINAL) do
                    local c = R.choix_final(src.cle)
                    local moi, pion = R.cible_de(c)
                    local actif = (qui == 1 and moi) or (qui == 2 and pion)
                    local ch, v = imgui.checkbox(src.nom .. "##l" .. qui .. "_" .. k, actif)
                    if ch then
                        if qui == 1 then moi = v else pion = v end
                        R.cible_fixer(c, moi, pion); sauver()
                    end
                    if actif then
                        imgui.same_line()
                        if imgui.button("essayer##e" .. qui .. "_" .. k) then R.essayer_source(e, r, k, qui) end
                        local c1, v1 = imgui.slider_float("    taille##t" .. qui .. "_" .. k, c.taille or 1, 0.05, 20.0, "x %.2f")
                        if c1 then c.taille = v1; sauver() end
                        local c2, v2 = imgui.slider_float("    hauteur (m)##h" .. qui .. "_" .. k, c.hauteur or 0, -15.0, 20.0, "%.1f")
                        if c2 then c.hauteur = v2; sauver() end
                        local c3, v3 = imgui.slider_float("    durée de vie (s, 0 = native)##d" .. qui .. "_" .. k, c.duree_vie or 0, 0.0, 15.0, "%.1f")
                        if c3 then c.duree_vie = v3; sauver() end
                    end
                end
            end
            if imgui.tree_node("À la fin de l'incantation, sur l'Insurgé") then liste("Coche un ou plusieurs effets (ils se cumulent) :", 1); imgui.tree_pop() end
            if imgui.tree_node("Sur chaque pion quand il revient à la vie") then
                liste("Coche un ou plusieurs effets (ils se cumulent) :", 2)
                if imgui.button("Essayer sur mes pions") then pcall(R.essai_sur_pions) end
                imgui.tree_pop()
            end
            imgui.text("Réglage commun :")
            local c4, v4 = imgui.slider_float("  taille générale de tous les effets##tg", r.taille, 0.01, 5.0, "x %.2f")
            if c4 then r.taille = v4; sauver() end
            local c5, v5 = imgui.slider_float("  hauteur générale (m)##hg", r.hauteur or 0, -5.0, 10.0, "%.1f")
            if c5 then r.hauteur = v5; sauver() end
        end
        imgui.tree_pop()
    end


    -- 7. INTERFACE À L'ÉCRAN (HUD) -----------------------------------------------
    if imgui.tree_node("Interface à l'écran (HUD)") then
        R.menu_hud()
        imgui.tree_pop()
    end


    -- 8. OUTILS DE TEST ----------------------------------------------------------
    if imgui.tree_node("Outils de test") then
        if imgui.button("Lancer Breath of Life (comme la combinaison)") then lancer() end
        imgui.same_line()
        if imgui.button("Débloquer l'Insurgé") then debloquer(joueur(), "bouton") end
        if imgui.button("Essayer le coup de zoom##punch_essai2") then C.punch_t = os.clock() end
        imgui.same_line()
        if imgui.button("Tout remettre à la vitesse normale##vit_raz") then R.vit_tout(); vitesse_globale(1.0) end
        local morts, total = pions_morts()
        imgui.text(R.fmt("Pions suivis : %d   |   à terre : %d", total, #morts))
        imgui.separator()
        debut_nouveau()
        titre("RETIRER DES PV À UN PION (v0.3 — branchement incertain)")
        imgui.text("Le journal dit quelle méthode a fait baisser les PV, et si le pion est à terre 0,5 s après.")
        curseur_i("  pourcentage des PV max retiré (100 = à terre)", "test_pv_pct", 1, 100)
        imgui.text("  Méthode :")
        for i, lib in ipairs({ "auto (cascade)", "1 set_Hp", "2 setHp", "3 recoverHp(−)", "4 coup factice" }) do
            imgui.same_line()
            if imgui.button((cfg.test_pv_methode == i - 1 and "[x] " or "[ ] ") .. lib .. "##pvm") then cfg.test_pv_methode = i - 1; sauver() end
        end
        case("  autoriser la méthode 4 « coup factice » (damageProc) — peut faire planter le jeu", "test_pv_risque")
        local lp = R.pions_ordonnes()
        for i = 1, 3 do
            local m = lp[i]
            if m then
                local _, pv, max = lire_pv(m.chr)
                local mort = appeler(m.chr, "get_IsDead") == true
                if imgui.button(R.fmt("Retirer %d %% à %s##pv%d", cfg.test_pv_pct, m.nom, i)) then R.retirer_pv(i, cfg.test_pv_pct) end
                imgui.same_line()
                imgui.text(R.fmt("PV %s / %s%s", pv and R.fmt("%.0f", pv) or "?", max and R.fmt("%.0f", max) or "?", mort and "  — À TERRE" or ""))
            else
                imgui.text(R.fmt("Pion %d : absent du groupe", i))
            end
        end
        if imgui.button(R.fmt("Retirer %d %% aux trois##pvtous", cfg.test_pv_pct)) then for i = 1, math.min(3, #lp) do R.retirer_pv(i, cfg.test_pv_pct) end end
        if R.pv_methode_ok then imgui.text("  dernière méthode qui a marché : " .. R.pv_methode_ok) end
        fin_nouveau()
        imgui.separator()
        imgui.text("(Pour gagner ou perdre des éclats : tiroir « Outils de test » de BardN Shards of Life.)")
        imgui.text("(Cercle de portée et cercle d'incantation : tiroir « Interface à l'écran (HUD) ».)")
        if imgui.tree_node("Journal") then
            for _, ev in ipairs(evenements) do imgui.text(ev) end
            imgui.tree_pop()
        end
        imgui.tree_pop()
    end
    imgui.tree_pop()
end)
