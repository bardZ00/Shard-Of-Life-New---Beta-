-- ============================================================================
-- BardN_RiftSpawn v0.01 — Rift Spawn (Dragon's Dogma 2)
-- Module indépendant qui se branche sur BardN Shards of Life.
-- À la mort : au lieu de revenir à la dernière auberge, le joueur se réveille
-- à la pierre de faille qu'il a choisie, avec perte d'or et sauvegarde forcée.
-- REQUIERT : BardN Shards of Life (≥ v0.47, cfg.respawn_compat activé).
-- ============================================================================
local NOM = "BardN Rift Spawn v0.01"
local VER = "0.01"
local CONFIG = "BardN_RiftSpawn/config.json"
local DOSSIER_IMG = "BardN_RiftSpawn/"
local CARTE_GUID = "b4d1e35f-0000-0000-0000-726966747370"   -- guid unique pour l'icône de carte

-- ============================================================================
-- Réglages
-- ============================================================================
local defauts = {
    actif = true,
    langue = "auto",
    -- mort
    heures_saut = 8,                   -- heures de jeu à faire passer au réveil
    mort_or = 20,                      -- perte d'or en % (0 = désactivée)
    duree_noir = 8,                    -- durée minimale de l'écran noir (s)
    save_auto = true,                  -- sauvegarde automatique (emplacement 0) après le réveil
    save_menu = true,                  -- sauvegarde menu (emplacement 4) après le réveil
    -- pierre de faille
    pf_choix = true,                   -- activer la sélection par appui court
    pf_appui = 0.5,                    -- durée max d'un appui « court » (s)
    pf_distance = 4,                   -- distance max pour détecter une pierre (m)
    -- carte
    carte_actif = true,
    carte_taille = 44,
    carte_opacite = 1.0,
}
local cfg = {}
for k, v in pairs(defauts) do cfg[k] = v end

local function charger()
    local ok, data = pcall(json.load_file, CONFIG)
    if ok and type(data) == "table" then
        for k, v in pairs(data) do
            if defauts[k] ~= nil and type(v) == type(defauts[k]) then
                if math.type(defauts[k]) == "integer" then v = math.tointeger(v) or defauts[k] end
                cfg[k] = v
            end
        end
        if type(data.pierre) == "table" then cfg.pierre = data.pierre end
    end
end
local function sauver()
    local d = {}
    for k, v in pairs(cfg) do d[k] = v end
    d.pierre = cfg.pierre
    pcall(json.dump_file, CONFIG, d)
end
pcall(charger)

-- ============================================================================
-- Utilitaires
-- ============================================================================
local function borne(v, mn, mx)
    v = tonumber(v) or mn
    if v < mn then return mn elseif v > mx then return mx end
    return v
end

-- i18n minimal
local EN = {
    ["Mod actif"] = "Mod active",
    ["Heures de jeu au réveil"] = "In-game hours at wake-up",
    ["Perte d'or (%)"] = "Gold loss (%)",
    ["Durée minimale de l'écran noir (s)"] = "Minimum black screen duration (s)",
    ["Sauvegarde automatique après le réveil"] = "Auto-save after wake-up",
    ["Sauvegarde du menu après le réveil"] = "Menu save after wake-up",
    ["Choix de la pierre par appui court"] = "Stone selection by short press",
    ["Durée max d'un appui court (s)"] = "Max short press duration (s)",
    ["Distance de détection (m)"] = "Detection distance (m)",
    ["Marqueur sur la carte"] = "Map marker",
    ["Taille du marqueur (px)"] = "Marker size (px)",
    ["Opacité du marqueur"] = "Marker opacity",
    ["Pierre actuelle :"] = "Current stone:",
    ["aucune (par défaut : Avant-poste des gardes frontières)"] = "none (default: Borderwatch Outpost)",
    ["choisie"] = "selected",
    ["par défaut"] = "default",
    ["Effacer (revenir à la pierre par défaut)"] = "Clear (back to default stone)",
    ["Faire de cette pierre de faille ton point de résurrection ?"] = "Make this rift stone your respawn point?",
    ["Cette pierre de faille est déjà ton point de résurrection."] = "This rift stone is already your respawn point.",
    ["Point de résurrection enregistré"] = "Respawn point saved",
    ["Si tu tombes, tu te réveilleras à cette pierre de faille."] = "If you fall, you'll wake up at this rift stone.",
    ["Vous vous réveillez près de la pierre de faille."] = "You wake up near the rift stone.",
    ["Vous avez perdu %d or."] = "You lost %d gold.",
    ["%d heures ont passé."] = "%d hours have passed.",
    ["Monde déchaîné : mort native laissée au jeu"] = "Unmoored World: native death left to the game",
    ["Point de résurrection"] = "Respawn point",
    ["Rift Spawn désactivé"] = "Rift Spawn disabled",
    ["Forcer un réveil à la pierre (test)"] = "Force a wake-up at the stone (test)",
    ["Outils de test"] = "Test tools",
}

local lang_cache = {}
local lang_jeu = nil
local function detecter_langue()
    if cfg.langue == "fr" or cfg.langue == "en" then return cfg.langue end
    if lang_jeu then return lang_jeu end
    lang_jeu = "en"
    pcall(function()
        local gui = sdk.get_managed_singleton("app.GuiManager")
        if gui then
            local ok, v = pcall(function() return gui:call("get_MessageLanguage") end)
            if ok and v == 0 then lang_jeu = "fr" end   -- 0 = Japanese, essayer les getters de langue
        end
        for _, g in ipairs({ "get_GameLanguage", "get_VoiceLanguage" }) do
            pcall(function()
                local v = sdk.get_managed_singleton("app.SystemSaveDataManager"):call(g)
                if v == 1 then lang_jeu = "fr" end   -- 1 = French
            end)
        end
    end)
    return lang_jeu
end
local function T(t)
    if detecter_langue() ~= "en" then return t end
    if lang_cache[t] then return lang_cache[t] end
    if EN[t] then lang_cache[t] = EN[t]; return EN[t] end
    return t
end
local function TF(f, ...) return string.format(T(f), ...) end

-- Journal
local journal = {}
local function noter(cat, t)
    journal[#journal + 1] = string.format("[%s] %s : %s", os.date("%H:%M:%S"), cat, type(t) == "table" and string.format(table.unpack(t)) or t)
    if #journal > 500 then table.remove(journal, 1) end
end

-- Accès au joueur
local function joueur()
    local ok, p = pcall(function() return sdk.get_managed_singleton("app.CharacterManager"):call("get_ManualPlayer()") end)
    if ok and p then
        local okv, v = pcall(function() return p:get_Valid() end)
        if okv and v then return p end
    end
    return nil
end
local function vers_table(v) return v and { x = v.x, y = v.y, z = v.z } or nil end
local function position(ch)
    local ok, v = pcall(function() return ch["<Transform>k__BackingField"]:get_UniversalPosition() end)
    return ok and vers_table(v) or nil
end
local function monde_dechaine()
    local ok, v = pcall(function() return sdk.get_managed_singleton("app.WeatherManager"):get_field("_IsBackWorld") end)
    return ok and v == true
end
local function or_actuel()
    local ok, v = pcall(function() return sdk.get_managed_singleton("app.ItemManager"):get_Version() end)
    return ok and type(v) == "number" and math.floor(v) or nil
end
local function retirer_or(n)
    return pcall(function() sdk.get_managed_singleton("app.ItemManager"):addVersion(-n, true, true) end)
end
local function fondu_natif_actif()
    local gui = sdk.get_managed_singleton("app.GuiManager")
    if not gui then return false end
    local a, b = false, false
    pcall(function() a = gui:call("isFadeDispAny") == true end)
    pcall(function() b = gui:call("isFadeMoveAny") == true end)
    return a or b
end
local function soigner_pions_vivants()
    local n, m = 0, 0
    pcall(function()
        local l = sdk.get_managed_singleton("app.PawnManager"):get_PawnCharacterList()
        local items = {}
        pcall(function() items = l:get_elements() end)
        if #items == 0 then
            pcall(function()
                local c = l:call("get_Count")
                for i = 0, (c or 0) - 1 do local ok2, ch = pcall(function() return l:call("get_Item", i) end); if ok2 and ch then items[#items + 1] = ch end end
            end)
        end
        for _, pw in ipairs(items) do
            local mortp = false
            pcall(function() mortp = pw:get_IsDead() == true end)
            if mortp then m = m + 1
            else
                pcall(function() pw:get_Hit():recoverHpAndMaxHpCompletely(true) end)
                n = n + 1
            end
        end
    end)
    return n, m
end

-- ============================================================================
-- Purge du combat (par réflexion, identique à Death System v1.24)
-- ============================================================================
local bm_plan = nil
local function contient(n, mots) for _, m in ipairs(mots) do if n:find(m, 1, true) then return true end end return false end
local function plan_combat()
    if bm_plan then return bm_plan end
    local p = { bools = {}, compteurs = {}, minuteurs = {}, setters = {}, vider = {} }
    pcall(function()
        local td = sdk.find_type_definition("app.BattleManager")
        local prof = 0
        while td and prof < 3 do
            for _, f in ipairs(td:get_fields() or {}) do
                pcall(function()
                    if f:is_static() then return end
                    local n, ty = f:get_name(), f:get_type():get_full_name()
                    if ty == "System.Boolean" and n:sub(1, 3) == "_Is" and not n:find("Prev", 1, true)
                        and not contient(n, { "Enable", "Disable", "Valid", "Can", "Ignore" })
                        and contient(n, { "Detect", "Sensed", "Recognize", "Notice", "Attacked", "Damaged", "ForceCombat", "Hostile" }) then
                        p.bools[#p.bools + 1] = n
                    elseif (ty == "System.Int32" or ty == "System.UInt32") and n:find("Combat", 1, true) and n:find("Count", 1, true) then
                        p.compteurs[#p.compteurs + 1] = n
                    elseif ty == "app.Timer" and contient(n, { "Combat", "Die" }) then
                        p.minuteurs[#p.minuteurs + 1] = n
                    end
                end)
            end
            for _, m in ipairs(td:get_methods() or {}) do
                pcall(function()
                    if m:is_static() then return end
                    local n, pt = m:get_name(), m:get_param_types() or {}
                    if #pt == 1 and pt[1]:get_full_name() == "System.Boolean" and n:sub(1, 6) == "set_Is"
                        and not n:find("BattleMode", 1, true) and contient(n, { "Combat", "Surprise", "Keep" }) then
                        p.setters[#p.setters + 1] = n .. "(System.Boolean)"
                    elseif #pt == 0 and n:sub(1, 5) == "clear" and contient(n, { "Detect", "Notice" }) then
                        p.vider[#p.vider + 1] = n
                    end
                end)
            end
            td = td:get_parent_type(); prof = prof + 1
            if td and td:get_full_name():find("^via%.") then break end
        end
    end)
    table.sort(p.bools); table.sort(p.compteurs); table.sort(p.minuteurs); table.sort(p.setters); table.sort(p.vider)
    bm_plan = p
    noter("PURGE", TF("purge du combat : %d drapeaux, %d compteurs, %d minuteurs, %d états, %d listes",
        #p.bools, #p.compteurs, #p.minuteurs, #p.setters, #p.vider))
    return p
end
local function humain_joueur()
    local ok, h = pcall(function() return sdk.get_managed_singleton("app.CharacterManager"):call("get_ManualPlayerHuman") end)
    return ok and h or nil
end
local function purger_combat()
    local combat = sdk.get_managed_singleton("app.BattleManager")
    if combat then
        local p = plan_combat()
        pcall(function() combat:call("requestForceNormal", false) end)
        for _, n in ipairs(p.minuteurs) do pcall(function() local t = combat:get_field(n); if t then t:call("finish") end end) end
        for _, n in ipairs(p.vider) do pcall(function() combat:call(n) end) end
        for _, n in ipairs(p.bools) do pcall(function() combat:set_field(n, false) end) end
        for _, n in ipairs(p.compteurs) do pcall(function() combat:set_field(n, 0) end) end
        for _, n in ipairs(p.setters) do pcall(function() combat:call(n, false) end) end
        pcall(function() combat:call("requestForceUpdate") end)
    end
    local h = humain_joueur()
    if h then pcall(function() h:set_field("TimerBattleMode", 0.0) end) end
end
local function combat_fini()
    local bm = sdk.get_managed_singleton("app.BattleManager")
    local en = false
    if bm then
        for _, g in ipairs({ "get_IsBattleMode", "get_IsReadyMode", "get_IsInNPCCombat", "get_IsInBigEnemyOrBossEnemyCombat", "get_IsInFollowerNPCCombat" }) do
            pcall(function() if bm:call(g) == true then en = true end end)
        end
    end
    local h = humain_joueur()
    if h then pcall(function() if h:call("get_IsBattleMode") == true then en = true end end) end
    return not en
end

-- ============================================================================
-- Sauvegardes
-- ============================================================================
local INTERDITS = { [20] = true, [40] = true }
for i = 44, 57 do INTERDITS[i] = true end
local function sauvegarde_type(t, arg)
    if INTERDITS[t] then return false end
    local flux = sdk.get_managed_singleton("app.MainFlowManager")
    if not flux then return false end
    for _, sd in ipairs({ "setSaveDisableByPlayer", "setSaveDisableByGimmick", "setSaveDisableByNPC" }) do
        pcall(function() flux:call(sd .. "(System.Boolean)", false) end)
    end
    return pcall(function()
        flux:call("requestDataSaveAuto(app.MainFlowManager.AutoSaveRequestType, System.Int32, System.Action, System.Action)", t, arg or 0, nil, nil)
    end)
end
local saves_file = {}
local function sauvegarde_libre()
    local ok, v = pcall(function() return sdk.get_managed_singleton("app.SaveDataManager"):call("isExecutableSaveLoadProcess()") end)
    if not ok or v == nil then return true end
    return v == true
end
local function saves_tick()
    local f = saves_file[1]
    if not f then return end
    local now = os.clock()
    if now < f.t then return end
    if not sauvegarde_libre() and now - f.t < 15 then return end
    table.remove(saves_file, 1)
    sauvegarde_type(f.type, f.arg)
    if saves_file[1] then saves_file[1].t = math.max(saves_file[1].t, now + 1.5) end
end

-- ============================================================================
-- Pierre de faille par défaut : Avant-poste des gardes frontières (Borderwatch Outpost)
-- ============================================================================
local PIERRE_DEFAUT = { x = 373.1324510574341, y = 205.83460998535156, z = -2534.2296600341797, defaut = true,
                         nom = "Pierre de faille de l'Avant-poste des gardes frontières" }
local function pierre() return cfg.pierre or PIERRE_DEFAUT end

-- ============================================================================
-- Téléportation à la pierre
-- ============================================================================
local function teleporter_pierre(heures)
    local pz = pierre()
    if not pz then return false end
    local ok, motif = pcall(function()
        local tsm = sdk.get_managed_singleton("app.TimeSkipManager")
        local tm = sdk.get_managed_singleton("app.TimeManager")
        local pos = ValueType.new(sdk.find_type_definition("via.Position"))
        pos.x, pos.y, pos.z = pz.x, pz.y, pz.z
        local q = ValueType.new(sdk.find_type_definition("via.Quaternion"))
        q.x, q.y, q.z, q.w = 0, 0, 0, 1
        local hr, day = tm:get_InGameHour(), tm:get_InGameDay()
        local total = hr * 60 + math.floor(heures) * 60
        local nday, nhr = day + math.floor(total / 1440), math.floor((total % 1440) / 60)
        tsm:call("requestPlayerWarp", nhr, 0, nday, pos, q, nil, true, true)
    end)
    noter("MORT", ok and TF("téléportation vers la pierre (+%d h)", math.floor(heures)) or ("téléportation : ÉCHEC " .. tostring(motif)))
    return ok
end

-- ============================================================================
-- Séquence de mort : noir → voyage → réveil → pénalités → sauvegardes
-- ============================================================================
local K = {
    DELAI_RELAIS = 0.3,
    GARDE = 60,
    POSE = "DmgDownLoop",
    RELEVE = "DmgStandup",
    DELAI_POSE = 2,
    ARRIVEE_M = 15,
    VOYAGE_MAX = 25,
    COMBAT_MAX = 6,
    SELECT_APRES = 3,
    SAVE_ECART = 1.5,
}
local mort_seq = nil      -- nil = pas de séquence en cours
local select_jusqua = 0
local recap = nil
local anim = nil
local message = ""

local function jouer_action(nom)
    local p = joueur()
    if not p then return false end
    return pcall(function() p["<ActionManager>k__BackingField"]:call("requestActionCore", 0, nom, 0) end)
end
local function anim_demarrer()
    jouer_action(K.POSE)
    anim = { t = os.clock() + K.DELAI_POSE, action = K.RELEVE }
end
local function anim_tick()
    if anim and os.clock() >= anim.t then
        local a = anim.action
        anim = nil
        jouer_action(a)
    end
end

local function arrive()
    local pos, pz = position(joueur()), pierre()
    if not (pos and pz) then return false end
    local dx, dy, dz = pos.x - pz.x, pos.y - pz.y, pos.z - pz.z
    return dx * dx + dy * dy + dz * dz <= K.ARRIVEE_M * K.ARRIVEE_M
end

local function mort_demarrer(origine, delai)
    if mort_seq then return false end
    if monde_dechaine() then noter("MORT", T("Monde déchaîné : mort native laissée au jeu")); return false end
    local t = os.clock() + (tonumber(delai) or 1.5)
    mort_seq = { etape = "noir", t0 = t - 0.6, t = t, origine = origine }
    noter("MORT", TF("séquence démarrée (%s)", T(origine)))
    return true
end
local function mort_arreter(raison) noter("MORT", raison or "arrêtée"); mort_seq = nil end

local function mort_tick()
    if recap and os.clock() >= recap.fin then recap = nil end
    pcall(saves_tick)
    pcall(anim_tick)
    local m = mort_seq
    if not m then return end
    local now = os.clock()
    if now - m.t0 > K.GARDE then mort_arreter("garde-fou : séquence trop longue"); return end
    if m.etape == "noir" and now >= m.t then
        pcall(function() sdk.get_managed_singleton("app.CharacterManager"):call("revivePlayerIfDeadBeforeSave") end)
        pcall(function() joueur():get_Hit():recoverHpAndMaxHpCompletely(true) end)
        purger_combat()
        teleporter_pierre(cfg.heures_saut)
        m.etape, m.t = "voyage", now
        m.fin_noir = m.t0 + (tonumber(cfg.duree_noir) or 8)
        return
    end
    if m.etape == "voyage" then
        purger_combat()
        local ok_arr = arrive()
        local pret = now >= m.fin_noir and ok_arr and not fondu_natif_actif()
        if pret or now - m.t > K.VOYAGE_MAX then
            m.etape = "reveil"
            m.fin_fondu = now + 1.0
            anim_demarrer()
            local n, d = soigner_pions_vivants()
            m.pions = TF("%d pion(s) soigné(s), %d laissé(s) mort(s)", n, d)
            m.t = now + K.DELAI_POSE + 2.5
        end
        return
    end
    if m.etape == "reveil" and now >= m.t then
        purger_combat()
        m.combat_t = m.combat_t or now
        if not combat_fini() and now - m.combat_t < K.COMBAT_MAX then return end
        local perte = 0
        local avant = or_actuel()
        if avant and avant > 0 and (tonumber(cfg.mort_or) or 0) > 0 then
            perte = math.floor(avant * (tonumber(cfg.mort_or) or 20) / 100)
            if perte > 0 and not retirer_or(perte) then perte = 0 end
        end
        select_jusqua = now + K.SELECT_APRES
        -- Sauvegardes
        if cfg.save_auto then
            noter("SAUVE", "emplacement 0 (type 21) " .. (sauvegarde_type(21, 0) and "demandée" or "ÉCHEC"))
        end
        saves_file = {}
        if cfg.save_menu then saves_file[1] = { t = now + K.SAVE_ECART, type = 43, arg = 10, slot = 4 } end
        local txt = T("Vous vous réveillez près de la pierre de faille.")
            .. " " .. TF("%d heures ont passé.", math.floor(cfg.heures_saut))
            .. (perte > 0 and (" " .. TF("Vous avez perdu %d or.", perte)) or "")
        recap = { texte = txt, fin = now + 6 }
        noter("MORT", TF("terminée en %.1f s — or −%d ; %s", now - m.t0, perte, m.pions or ""))
        mort_seq = nil
    end
end

-- ============================================================================
-- Écran noir + message de réveil
-- ============================================================================
local function noir_alpha()
    local m = mort_seq
    if not m then return 0 end
    local now = os.clock()
    if m.etape == "noir" then return math.min(1, math.max(0, (now - m.t0) / 0.6)) end
    if m.etape == "voyage" then return 1 end
    if m.etape == "reveil" and m.fin_fondu then return math.max(0, (m.fin_fondu - now) / 1.0) end
    return 0
end
re.on_frame(function()
    pcall(mort_tick)
    pcall(function()
        local a = noir_alpha()
        if a <= 0 and not recap then return end
        local ok_sz, sz = pcall(imgui.get_display_size)
        local sw = (ok_sz and sz) and sz.x or 1920
        local sh = (ok_sz and sz) and sz.y or 1080
        if a > 0 then draw.filled_rect(0, 0, sw, sh, (math.floor(a * 255) << 24)) end
        local txt = recap and recap.texte or nil
        if txt then
            local fade = recap and recap.fin and math.min(1, (recap.fin - os.clock()) / 1.0) or 1
            if fade > 0 then draw.text(txt, sw * 0.1, sh * 0.9, (math.floor(fade * 200) << 24) | 0x00E8DCC8) end
        end
    end)
end)

-- ============================================================================
-- Blocage des phases du jeu pendant la séquence
-- ============================================================================
pcall(function()
    local mf = sdk.find_type_definition("app.MainFlowManager")
    local m3 = mf and mf:get_method("changeFlowPhase(app.MainFlowManager.Phase)")
    if m3 then
        sdk.hook(m3, function(args)
            if mort_seq then
                local ok, ph = pcall(function() return sdk.to_int64(args[3]) & 0xFFFFFFFF end)
                if ok and (ph == 28 or (ph >= 40 and ph <= 43)) then return sdk.PreHookResult.SKIP_ORIGINAL end
            end
            if os.clock() < select_jusqua then
                local ok, ph = pcall(function() return sdk.to_int64(args[3]) & 0xFFFFFFFF end)
                if ok and (ph == 28 or (ph >= 40 and ph <= 43)) then return sdk.PreHookResult.SKIP_ORIGINAL end
            end
        end, function(r) return r end)
    end
end)
-- Pierre éternelle et pause : bloquées aussi
pcall(function()
    local td = sdk.find_type_definition("app.SpecialWakestoneFlowController")
    local m = td and td:get_method("activateFlow()")
    if m then sdk.hook(m, function() if mort_seq then return sdk.PreHookResult.SKIP_ORIGINAL end end, nil) end
end)
pcall(function()
    local mf = sdk.find_type_definition("app.MainFlowManager")
    local m = mf and mf:get_method("executePause(System.Boolean)")
    if m then sdk.hook(m, function() if mort_seq then return sdk.PreHookResult.SKIP_ORIGINAL end end, nil) end
end)

-- ============================================================================
-- Choix de la pierre de faille (appui court sur Interagir)
-- ============================================================================
local pf = { flag = nil, bas = false, t0 = nil, dlg = nil, liste = nil, liste_t = -100, jobs = {}, info = "" }
local pf_touche_t = nil

local function pf_flag()
    if pf.flag ~= nil then return pf.flag or nil end
    pf.flag = false
    pcall(function()
        local act = nil
        for _, fd in ipairs(sdk.find_type_definition("app.CharacterInput.Action"):get_fields()) do
            if fd:is_static() and fd:get_name() == "Interact" then act = fd:get_data(nil) end
        end
        if act == nil then return end
        local fl = sdk.find_type_definition("app.CharacterInput"):get_method("getInputFlag(app.CharacterInput.Action)"):call(nil, act)
        if tonumber(fl) and tonumber(fl) ~= 0 then pf.flag = fl end
    end)
    return pf.flag or nil
end
local function pos_monde(ch)
    local ok, v = pcall(function() return ch["<Transform>k__BackingField"]:get_Position() end)
    return ok and vers_table(v) or nil
end
local function pf_pierres()
    local now = os.clock()
    if pf.liste and #pf.liste > 0 and now - pf.liste_t < 30 then return pf.liste end
    pf.liste_t = now
    local l = {}
    local function ajouter(g)
        local ok, v = pcall(function() return g:call("get_GameObject"):call("get_Transform"):call("get_Position") end)
        if ok and v then l[#l + 1] = vers_table(v) end
    end
    pcall(function()
        local c = sdk.get_managed_singleton("app.GimmickManager"):call("get_RimStoneGimmicks()")
        if c == nil then return end
        local okn, n = pcall(function() return c:call("get_Count") end)
        if okn and tonumber(n) then
            for i = 0, n - 1 do local okg, g = pcall(function() return c:call("get_Item", i) end); if okg and g then ajouter(g) end end
        else
            local oke, el = pcall(function() return c:get_elements() end)
            if oke and el then for _, g in ipairs(el) do ajouter(g) end end
        end
    end)
    pf.liste = l
    return l
end
local function pf_plus_proche()
    local p = joueur()
    local pp = p and pos_monde(p)
    if not pp then return nil end
    local best = nil
    for _, q in ipairs(pf_pierres()) do
        local d = math.sqrt((q.x - pp.x) ^ 2 + (q.y - pp.y) ^ 2 + (q.z - pp.z) ^ 2)
        if not best or d < best then best = d end
    end
    return best, #(pf.liste or {})
end

-- Boîte de dialogue (BardN_Menu si disponible, sinon direct)
local talk_api = nil
local function talk_brancher()
    if talk_api then return end
    pcall(function()
        local m = require("BardN_Menu")
        if type(m) == "table" and m.request_dialog then talk_api = m; noter("PF", "BardN_Menu connecté") end
    end)
    if not talk_api then
        pcall(function()
            local m = require("IGO/GuildTalk")
            if type(m) == "table" then talk_api = m; noter("PF", "IGO/GuildTalk connecté") end
        end)
    end
end

local function pf_boite(texte, info)
    pf.jobs[#pf.jobs + 1] = function()
        local ok = false
        if talk_api and type(talk_api.request_dialog) == "function" then ok = pcall(talk_api.request_dialog, texte, info) end
        if not ok then
            ok = pcall(function()
                local function chaine(x) local m = sdk.create_managed_string(x); m:add_ref(); return m end
                local e = chaine("")
                sdk.get_managed_singleton("app.GuiManager"):call("requestDialog(System.String, System.String, System.String, System.String, System.String, System.Boolean, System.Int32, System.Boolean, System.UInt32, System.Int32, System.Int32, via.render.TextureResourceHolder, System.Boolean, System.Boolean, System.Boolean, System.Boolean, System.Boolean, System.Single, System.Boolean, System.Boolean, System.Boolean)",
                    chaine(texte), info and chaine("OK") or e, e, e, e, false, 0, false, 40, 0, 0xFFFFFFFF, nil,
                    true, false, false, false, true, 0.0, false, false, false)
            end)
        end
        if ok then pf.dlg = { t = os.clock(), vu = false, info = info } end
    end
end
if re.on_pre_application_entry then
    re.on_pre_application_entry("UpdateBehavior", function()
        while #pf.jobs > 0 do pcall(table.remove(pf.jobs, 1)) end
    end)
end
local function dialogue_affiche()
    local ok, v = pcall(function() return sdk.get_managed_singleton("app.GuiManager"):call("IsDispDialogGui()") end)
    return ok and v == true
end
local function pf_memoriser()
    local pos = position(joueur())
    if not pos then return false end
    cfg.pierre = { x = pos.x, y = pos.y, z = pos.z, choisie = true, quand = os.date("%H:%M:%S") }
    sauver()
    noter("PF", string.format("pierre CHOISIE (%.1f, %.1f, %.1f)", pos.x, pos.y, pos.z))
    pf.confirmer = os.clock() + 0.4
    return true
end
local function pf_tick()
    local now = os.clock()
    pcall(talk_brancher)
    if pf.confirmer and now >= pf.confirmer and not pf.dlg and not dialogue_affiche() then
        pf.confirmer = nil
        pf_boite(T("Point de résurrection enregistré") .. "\n" .. T("Si tu tombes, tu te réveilleras à cette pierre de faille."), true)
    end
    local dl = pf.dlg
    if dl then
        local aff = dialogue_affiche()
        if aff then dl.vu = true end
        if (dl.vu and not aff) or (not dl.vu and now - dl.t > 3) or now - dl.t > 300 then
            local etat = nil
            if dl.vu and not aff then pcall(function() etat = sdk.get_managed_singleton("app.GuiManager"):call("getDialogState()") end) end
            pf.dlg = nil
            if etat == 1 and not dl.info then pf_memoriser() end
        end
        pf.bas = true
        return
    end
    if not (cfg.actif and cfg.pf_choix) then return end
    local fl = pf_flag()
    local p = joueur()
    if not (fl and p) then return end
    local bas = false
    pcall(function() bas = p:call("get_Input()"):call("isButtonOn(System.UInt64)", fl) == true end)
    if bas and not pf.bas then pf.t0 = now end
    if not bas and pf.bas and pf.t0 and now - pf.t0 <= borne(cfg.pf_appui, 0.1, 2) then
        local t0 = pf.t0
        pf.t0 = nil
        if not mort_seq and not dialogue_affiche()
           and not (pf_touche_t and pf_touche_t >= t0) then
            local d, n = pf_plus_proche()
            if d and d <= borne(cfg.pf_distance, 1, 15) then
                local pz, pp = pierre(), position(p)
                if pz and pp and math.sqrt((pz.x - pp.x) ^ 2 + (pz.y - pp.y) ^ 2 + (pz.z - pp.z) ^ 2) <= borne(cfg.pf_distance, 1, 15) + 3 then
                    pf_boite(T("Cette pierre de faille est déjà ton point de résurrection."), true)
                else
                    pf_boite(T("Faire de cette pierre de faille ton point de résurrection ?"), false)
                end
            end
        end
    end
    pf.bas = bas
end
-- Détection d'InteractRimStone (un maintien ouvre la Faille, pas un appui court)
pcall(function()
    local td = sdk.find_type_definition("app.InteractManager")
    local m = td and td:get_method("executeInteract(app.InteractManager.InteractInfo)")
    if m then
        sdk.hook(m, function(args)
            pcall(function()
                local info = sdk.to_managed_object(args[3])
                local nom = info:get_field("ActionName")
                if nom == "InteractRimStone" then pf_touche_t = os.clock() end
            end)
        end, function(r) return r end)
    end
end)
re.on_frame(function() pcall(pf_tick) end)

-- ============================================================================
-- Marqueur sur la carte (d2d) — même méthode que Death System
-- ============================================================================
local carte = { icone = nil, sprite = nil, fond = nil, ui = nil, toile = nil, type_icone = nil, pre_ui = nil, statut = "", err = false, vue_t = -100, vue = false }
do
    local int_t = sdk.find_type_definition("System.Int32")
    local info_t = sdk.find_type_definition("app.GuiManager.MapIconInfo")
    local guid_t = sdk.find_type_definition("System.Guid")
    local int_off = nil
    pcall(function() int_off = int_t:get_field("m_value"):get_offset_from_base() end)
    local function guid(txt)
        local h = txt:gsub("-", "")
        local g = ValueType.new(guid_t)
        g:set_field("mData1", tonumber(h:sub(1, 8), 16))
        g:set_field("mData2", tonumber(h:sub(9, 12), 16))
        g:set_field("mData3", tonumber(h:sub(13, 16), 16))
        for i = 0, 7 do g:set_field("mData4_" .. i, tonumber(h:sub(17 + 2 * i, 18 + 2 * i), 16)) end
        return g
    end
    local function type_icone()
        if carte.type_icone then return carte.type_icone end
        local v = nil
        pcall(function()
            for _, fd in ipairs(sdk.find_type_definition("app.MapIconType"):get_fields()) do
                if fd:is_static() and v == nil and fd:get_name():find("RimStone") then v = fd:get_data(nil) end
            end
        end)
        carte.type_icone = tonumber(v) or 31
        return carte.type_icone
    end
    local function vue_monde(ui)
        local w, dt = nil, nil
        pcall(function() w = ui:get_field("IsWorldMap"); dt = ui:get_field("IsDetailMap") end)
        return w == true and dt ~= true
    end
    local function retirer(ui)
        local ic = carte.icone
        carte.icone, carte.sprite, carte.fond = nil, nil, nil
        if not ic then return end
        pcall(function()
            local infos = ui:get_field("MapIconInfoList")
            local a = ic:get_address()
            for i = infos:call("get_Count") - 1, 0, -1 do
                local w = infos:call("get_Item", i)
                if w and w:get_address() == a then infos:call("RemoveAt", i) end
            end
        end)
    end
    local function slot_libre(ui, arr, limite)
        local pris = {}
        local infos = ui:get_field("MapIconInfoList")
        for i = 0, infos:call("get_Count") - 1 do
            pcall(function()
                local r = infos:call("get_Item", i):get_field("IconSprite")
                if r ~= nil then pris[r:get_address()] = true end
            end)
        end
        local premier = 0
        for i = 0, limite - 1 do
            local r = nil
            pcall(function() r = arr:get_element(i) end)
            if r ~= nil and pris[r:get_address()] then premier = i + 1 end
        end
        return premier
    end
    local function ajouter(ui)
        local pz = pierre()
        if not (cfg.carte_actif and pz and tonumber(pz.x)) then return end
        if not (int_off and info_t and guid_t) then return end
        local arr = ui:get_field("MapIconSprite")
        local limite = arr and arr:get_size() or 0
        if limite < 256 then return end
        local libre = slot_libre(ui, arr, limite)
        local info = info_t:create_instance():add_ref()
        info:set_field("IsEnable", true)
        info:set_field("IsNavi", false)
        info:set_field("IconId", 0)
        info:set_field("SortNo", 0)
        info:set_field("IconType", type_icone())
        info:set_field("Timing", 0)
        info:set_field("Pos", Vector3f.new(pz.x, pz.y, pz.z))
        info:set_field("Area", -1)
        info:set_field("LocalArea", 0)
        info:set_field("IsDispAllArea", true)
        local ref, essais = nil, 0
        while libre < limite and essais < 16 do
            ref = nil
            pcall(function() ref = arr:get_element(libre) end)
            if ref ~= nil then
                local sp, bg = nil, nil
                pcall(function() sp = ref:get_field("Sprite"); bg = ref:get_field("TexBG") end)
                if sp == nil or bg == nil then ref = nil end
            end
            if ref ~= nil then break end
            libre, essais = libre + 1, essais + 1
        end
        if ref == nil then return end
        local boite = int_t:create_instance():add_ref()
        boite:write_dword(int_off, libre)
        local ok, ic = pcall(function()
            return ui:call("addMapIconSpriteInfoList", info, 0, boite:get_address() + int_off, -1, guid(CARTE_GUID), false)
        end)
        if not ok or ic == nil then carte.err = true; return end
        carte.icone = ic
        pcall(function() local r = ic:get_field("IconSprite"); carte.sprite = r:get_field("Sprite"); carte.fond = r:get_field("TexBG") end)
        pcall(function() ui:call("updateMapIcon") end)
        noter("CARTE", TF("marqueur posé (case %d)", libre))
    end
    local td = sdk.find_type_definition("app.ui040205")
    local m_setup = td and td:get_method("setupMapIcon()")
    local m_detr = td and td:get_method("onDestroy()")
    local m_nom = td and td:get_method("setupIconName()")
    if m_setup then
        pcall(sdk.hook, m_setup, function(args)
            local ui = nil
            pcall(function() ui = sdk.to_managed_object(args[2]) end)
            carte.pre_ui = ui
            if ui then pcall(retirer, ui) end
        end, function(r)
            local ui = carte.pre_ui; carte.pre_ui = nil
            if ui and not carte.err then
                carte.ui, carte.toile = ui, nil
                if vue_monde(ui) then pcall(ajouter, ui) end
            end
            return r
        end)
    end
    if m_detr then
        pcall(sdk.hook, m_detr, function(args)
            local o = nil
            pcall(function() o = sdk.to_managed_object(args[2]) end)
            if o and carte.ui and o:get_address() == carte.ui:get_address() then
                carte.ui, carte.icone, carte.sprite, carte.fond = nil, nil, nil, nil
            end
        end, function(r) return r end)
    end
    if m_nom then
        pcall(sdk.hook, m_nom, function(args)
            pcall(function() carte.nom_ui = sdk.to_managed_object(args[2]) end)
        end, function(r)
            local ui, ic = carte.nom_ui, carte.icone
            carte.nom_ui = nil
            if ui and ic then
                pcall(function()
                    local sel = ui:get_field("SelectedIcon")
                    if sel and sel:get_address() == ic:get_address() then
                        ui:get_field("TxtName"):call("set_Message", T("Point de résurrection"))
                    end
                end)
            end
            return r
        end)
    end
end

-- ============================================================================
-- API publique : Shards of Life appelle trigger_death / is_active
-- ============================================================================
_G.BardN_DeathSystem = _G.BardN_DeathSystem or {}
_G.BardN_NewDeathSystem = _G.BardN_DeathSystem
_G.BardN_DeathSystem.api_version = 1
_G.BardN_DeathSystem.version = VER
_G.BardN_DeathSystem.is_active = function() return mort_seq ~= nil end
_G.BardN_DeathSystem.trigger_death = function(origine)
    if not cfg.actif then return false, T("Rift Spawn désactivé") end
    if mort_seq then return false, "sequence already running" end
    if not joueur() then return false, "pas d'Insurgé" end
    if mort_demarrer(tostring(origine or "Shards of Life"), K.DELAI_RELAIS) then return true end
    return false, monde_dechaine() and "Monde déchaîné" or "refusé"
end

-- ============================================================================
-- Menu REFramework
-- ============================================================================
re.on_draw_ui(function()
    if not imgui.tree_node(NOM) then return end

    local function case(lib, cle)
        local ch, v = imgui.checkbox(T(lib), cfg[cle])
        if ch then cfg[cle] = v; sauver() end
    end
    local function curseur_i(lib, cle, mn, mx)
        local c, v = imgui.slider_int(T(lib), cfg[cle], mn, mx)
        if c then cfg[cle] = v; sauver() end
    end
    local function curseur_f(lib, cle, mn, mx, f)
        local c, v = imgui.slider_float(T(lib), cfg[cle], mn, mx, f or "%.2f")
        if c then cfg[cle] = v; sauver() end
    end

    case("Mod actif", "actif")
    if not cfg.actif then imgui.push_style_color(0, 1, 0.3, 0.3, 1) end
    imgui.separator()

    -- Pierre actuelle
    local pz = pierre()
    local lib_pz = pz.choisie and T("choisie") or T("par défaut")
    imgui.text(T("Pierre actuelle :") .. " " .. string.format("(%.0f, %.0f, %.0f) [%s]", pz.x, pz.y, pz.z, lib_pz))
    if pz.choisie and imgui.button(T("Effacer (revenir à la pierre par défaut)")) then cfg.pierre = nil; sauver() end
    imgui.separator()

    curseur_i("Heures de jeu au réveil", "heures_saut", 0, 24)
    curseur_i("Perte d'or (%)", "mort_or", 0, 100)
    curseur_i("Durée minimale de l'écran noir (s)", "duree_noir", 3, 20)
    case("Sauvegarde automatique après le réveil", "save_auto")
    case("Sauvegarde du menu après le réveil", "save_menu")
    imgui.separator()
    case("Choix de la pierre par appui court", "pf_choix")
    if cfg.pf_choix then
        curseur_f("Durée max d'un appui court (s)", "pf_appui", 0.1, 2.0, "%.1f")
        curseur_i("Distance de détection (m)", "pf_distance", 1, 15)
    end
    imgui.separator()
    case("Marqueur sur la carte", "carte_actif")
    if cfg.carte_actif then
        curseur_i("Taille du marqueur (px)", "carte_taille", 8, 200)
        curseur_f("Opacité du marqueur", "carte_opacite", 0.0, 1.0, "%.2f")
    end

    imgui.separator()
    if imgui.tree_node(T("Outils de test") .. "##rs_outils") then
        if imgui.button(T("Forcer un réveil à la pierre (test)")) then
            mort_demarrer("test manuel", 0.3)
        end
        imgui.text("état : " .. (mort_seq and mort_seq.etape or "aucune séquence"))
        imgui.text("message : " .. tostring(message))
        if imgui.tree_node("Journal##rs_j") then
            for i = math.max(1, #journal - 30), #journal do
                imgui.text(journal[i] or "")
            end
            imgui.tree_pop()
        end
        imgui.tree_pop()
    end

    if not cfg.actif then imgui.pop_style_color() end
    imgui.tree_pop()
end)

noter("INIT", NOM .. " chargé")
